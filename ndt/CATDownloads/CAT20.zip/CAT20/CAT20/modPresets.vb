﻿Module modPresets
    Dim sArray(600, 20) As Integer 'this is the array the module needs to receive
    Dim nPresets As Integer
    Dim seedingArray(600, 20)
    Dim wNumberOfPresets As Integer
    Dim wSeedingArray(600, 20) As Integer
    Dim numSort, numsort1, numsort2, numsort3, numsort4, numsort5, numsort6 As Integer
    Dim order(600), order1(600), order2(600), order3(600), order4(600), order5(600), order6(600) As String
    Dim teamHad(600, 9) As Integer
    Dim side(600, 6) As Integer
    Dim byemark(600, 9) As Integer
    Dim aTeamRating(600) As Integer
    Dim wTopTeam, topCounter As Integer
    Dim teamSchool(600) As Integer
    Dim theBracket(300, 9) As Integer
    Dim wCurrentRound As Integer
    Dim wFromJon As Integer
    Dim whichBracket(600, 9), useBracket(600, 9) As Integer
    Dim aRd1Rating(600), aRd2Rating(600) As Integer 'this will be constructed and stored when round 1 is paired;stored in MatchWith field
    'Notes about this preset module
    'The assumption here is that CAT20 will trigger the Sub doPresets in module with two items defined:
    '  First the number of rounds the user wishes to preset (from 1 to 6) will be read here into the windows global
    '      array called wNumberofPresets (this will be called nPresets -- passed to the module)
    '  Second an array seedingArray(600,20) should be sent where Jon's team number is stored at seedingArray(x,0)
    '      At seedingArray(x,1) will be held an integer based school number for each team (to prevent same school)
    '      At seedingArray(x,2) will be held the seeding number for the team (an integer -- can be duplicates)
    'When seedingArray(600,200) returns from the module, it will have unchanged the information listed above
    '  But the seedingArray will now have the following information:
    '  seedingArray(600,3) = the array number of the team met in Rd 1
    '  seedingArray(600,4)=side for Rd 1 (1Aff, 2Neg, 3Bye)
    '  seedingArray(600,5) = the array number of the team met in Rd 2
    '  seedingArray(600,6)=side for Rd 2 (1Aff, 2Neg, 3Bye)
    '  seedingArray(600,7) = the array number of the team met in Rd 3
    '  seedingArray(600,8)=side for Rd 3 (1Aff, 2Neg, 3Bye)
    '  seedingArray(600,9) = the array number of the team met in Rd 4
    '  seedingArray(600,10)=side for Rd 4 (1Aff, 2Neg, 3Bye)
    '  seedingArray(600,11) = the array number of the team met in Rd 5
    '  seedingArray(600,12)=side for Rd 5 (1Aff, 2Neg, 3Bye)
    '  seedingArray(600,13) = the array number of the team met in Rd 6
    '  seedingArray(600,14)=side for Rd 6 (1Aff, 2Neg, 3Bye)

    Sub doPresets(ByRef sArray(,), ByVal dummy)
        'NOTE: Set the wFromJOn indidator to 1 rather than zero if you are passing seedingArray information to this module
        For x As Integer = 1 To 600
            For y As Integer = 0 To 2
                wSeedingArray(x, y) = sArray(x, y)
            Next
        Next x
        nPresets = dummy

        'If wFromJon = 0 Then createSimulationSet()
        normalizeRatings()
        For x As Integer = 1 To 600
            If wSeedingArray(x, 0) > 0 Then wTopTeam = x
            teamSchool(x) = wSeedingArray(x, 1)
            aTeamRating(x) = wSeedingArray(x, 2)
        Next
        wNumberOfPresets = nPresets
        wFromJon = 1
        For y As Integer = 1 To wNumberOfPresets
            For i As Integer = 0 To 600
                For ii As Integer = 0 To 9
                    whichBracket(i, ii) = 0
                    useBracket(i, ii) = 0
                Next
            Next
            wCurrentRound = y
            If wCurrentRound = 1 Then presetOne()
            If wCurrentRound = 2 And wNumberOfPresets > 1 Then presetEven()
            If wCurrentRound = 3 And wNumberOfPresets > 2 Then presetOdd()
            If wCurrentRound = 4 And wNumberOfPresets > 3 Then presetEven()
            If wCurrentRound = 5 And wNumberOfPresets > 4 Then presetOdd()
            If wCurrentRound = 6 And wNumberOfPresets > 5 Then presetEven()
        Next
        For x As Integer = 1 To 600
            For y As Integer = 0 To 20
                sArray(x, y) = wSeedingArray(x, y)
            Next
        Next x
    End Sub
    Private Sub normalizeRatings()
        'Task here is to take the ratings in whatever form and order them straight down from 1 to whatever
        Dim aaa, aaa20 As String
        Dim myLength, theTeam As Integer
        

        numsort6 = 0
        For x As Integer = 0 To 600
            order(x) = ""
        Next
        Randomize()

        For x As Integer = 1 To 600
            If wSeedingArray(x, 0) > 0 Then
                aaa20 = (Int((999 - 111 + 1) * Rnd() + 111)).ToString
                aaa = (10000 + wSeedingArray(x, 2)).ToString & Space(10) & aaa20 & Space(10) & x.ToString
                numsort6 = numsort6 + 1
                order6(numsort6) = aaa
            End If
        Next
        insertionSort6()
        'Now the original team seed is converted to an ordinal marker (this will not overwrite seedingArray(x,2)
        For x As Integer = 1 To numsort6
            myLength = Len(order6(x))
            theTeam = Val(Mid(order6(x), myLength - 2, 3))
            wSeedingArray(theTeam, 2) = x
        Next x
        
    End Sub

    Private Sub presetOne()
        'this preset will use the Harvard method for pairing the first round if seeding is desired.
        'if random is desired, the same system will be used, except that seeding is made entirely random
        'first construct the list of competing teams
        Dim aaa20, myRating, fff As String
        Dim myTop(200), myBottom(200), theTeam As Integer
        Dim myTopNumber, myBottomNumber, iOK As Integer
        Dim myHalfPoint As Integer
        Dim sideSwitcher As Integer
        Dim iCanMeet(400, 400) As Integer
        Dim hasBeenUsed(400) As Integer
        Dim myBracketCounter As Integer
        Dim byeTeam As Integer
        Dim scheduleProblemFoundT, scheduleProblemFoundB As Integer
        Dim iOne, iTwo As Integer
        Dim iCanSwitch, teamSwitch1, teamSwitch2, teamSwitch3, teamSwitch4 As Integer
        Dim problemT, problemB As Integer

        For i As Integer = 0 To 200
            For ii As Integer = 0 To 6
                theBracket(i, ii) = 0
            Next
        Next

        Dim myLength As Integer
        Randomize()
        numsort1 = 0
        For i As Integer = 0 To 600
            order1(i) = ""
        Next
        For myTeam As Integer = 1 To wTopTeam
            aaa20 = (Int((999 - 111 + 1) * Rnd() + 111)).ToString
            If myTeam = 1 Then
                sideSwitcher = 2
                If Val(aaa20) > 500 Then sideSwitcher = 1
            End If
            myRating = (1000 + aTeamRating(myTeam)).ToString 'higher is better in team rating
            numsort1 = numsort1 + 1
            order1(numsort1) = myRating & " " & aaa20 & Space(20) & myTeam.ToString

        Next
        insertionSort1()
        myHalfPoint = Int(numsort1 * 0.5)

        If numsort1 / 2 <> Int(numsort1 / 2) Then
            'bye is necessary
            'assign a bye to the team at the end of the seed list
            myLength = Len(order1(numsort1))
            theTeam = Val(Mid(order1(numsort1), myLength - 2, 3))
            myBracketCounter = myBracketCounter + 1
            theBracket(myBracketCounter, 0) = theTeam
            byeTeam = theTeam
            byemark(theTeam, wCurrentRound) = 1
            wSeedingArray(theTeam, 4) = 3
            hasBeenUsed(byeTeam) = 1
            numsort1 = numsort1 - 1
        End If

        For i As Integer = 1 To numsort1
            myLength = Len(order1(i))
            theTeam = Val(Mid(order1(i), myLength - 2, 3))
            aRd1Rating(theTeam) = 999 - i 'this will be what is stored in the MatchWith Field (higher is better)
            If i <= myHalfPoint Then
                myTopNumber = myTopNumber + 1
                myTop(myTopNumber) = theTeam
            Else
                myBottomNumber = myBottomNumber + 1
                myBottom(myBottomNumber) = theTeam
            End If
        Next

        If myTopNumber / 2 <> Int(myTopNumber / 2) Then
            myTopNumber = myTopNumber + 1
            myBottomNumber = myBottomNumber - 1
        End If

        For iCounter As Integer = 1 To wTopTeam
            iOne = iCounter
            For iCounter1 As Integer = 1 To wTopTeam
                iTwo = iCounter1
                iOK = 0
                'are the two teams from same school
                If wSeedingArray(iOne, 1) = wSeedingArray(iTwo, 1) Then iOK = 1
                If iOK = 1 Then
                    iCanMeet(iOne, iTwo) = 1
                    iCanMeet(iTwo, iOne) = 1
                End If
            Next iCounter1
        Next iCounter
        'ready now to pair this round
        For i As Integer = 1 To myTopNumber
            iOne = myTop(i)
            'find an opponent for iOne
            For ii As Integer = 1 To myBottomNumber
                iTwo = myBottom(ii)
                'Determine whether this pairing is possible
                iOK = 1
                If iCanMeet(iOne, iTwo) = 1 Or iCanMeet(iTwo, iOne) = 1 Then iOK = 0
                If hasBeenUsed(iTwo) > 0 Then iOK = 0
                If iOK = 1 Then
                    'Create this pairing
                    hasBeenUsed(iOne) = 1 : hasBeenUsed(iTwo) = 1
                    myBracketCounter = myBracketCounter + 1
                    If sideSwitcher = 1 Then
                        sideSwitcher = 2
                        theBracket(myBracketCounter, 0) = iOne
                        theBracket(myBracketCounter, 1) = iTwo
                    Else
                        sideSwitcher = 1
                        theBracket(myBracketCounter, 0) = iTwo
                        theBracket(myBracketCounter, 1) = iOne
                    End If
                    ii = myBottomNumber
                End If
            Next
        Next
        'Now must determine if any team remains unscheduled
        For i As Integer = 1 To myTopNumber
            If myTop(i) > 0 And hasBeenUsed(myTop(i)) = 0 Then
                'there is a team here not scheduled
                scheduleProblemFoundT = scheduleProblemFoundT + 1
                problemT = myTop(i)
            End If
        Next
        For i As Integer = 1 To myBottomNumber
            If myBottom(i) > 0 And hasBeenUsed(myBottom(i)) = 0 Then
                'there is a team here not scheduled
                scheduleProblemFoundB = scheduleProblemFoundB + 1
                problemB = myBottom(i)
                fff = problemB
            End If
        Next

        If scheduleProblemFoundT = 1 And scheduleProblemFoundB = 1 Then
            'must repair the schedule

            iCanSwitch = 1
            teamSwitch1 = problemT
            teamSwitch2 = problemB
            teamSwitch3 = theBracket(myBracketCounter, 0)
            teamSwitch4 = theBracket(myBracketCounter, 1)
            'Now the question is: 
            'Can teamSwitch1 meet teamSwitch4 and can teamSwitch3 meet teamSwitch2?
            If iCanMeet(teamSwitch1, teamSwitch4) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch4, teamSwitch1) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch3, teamSwitch2) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch2, teamSwitch3) > 0 Then iCanSwitch = 0
            If iCanSwitch = 1 Then
                theBracket(myBracketCounter, 0) = teamSwitch1
                theBracket(myBracketCounter, 1) = teamSwitch4
                myBracketCounter = myBracketCounter + 1
                theBracket(myBracketCounter, 0) = teamSwitch3
                theBracket(myBracketCounter, 1) = teamSwitch2
                hasBeenUsed(teamSwitch1) = 1 : hasBeenUsed(teamSwitch2) = 1
                hasBeenUsed(teamSwitch3) = 1 : hasBeenUsed(teamSwitch4) = 1
            Else
                'well this switch didn't work so try another since this is not side constrained
                'Can teamSwitch1 meet teamSwitch3 and can teamSwitch4 meet teamSwitch2?
                If iCanMeet(teamSwitch1, teamSwitch3) > 0 Then iCanSwitch = 0
                If iCanMeet(teamSwitch3, teamSwitch1) > 0 Then iCanSwitch = 0
                If iCanMeet(teamSwitch4, teamSwitch2) > 0 Then iCanSwitch = 0
                If iCanMeet(teamSwitch2, teamSwitch4) > 0 Then iCanSwitch = 0
                If iCanSwitch = 1 Then
                    theBracket(myBracketCounter, 0) = teamSwitch1
                    theBracket(myBracketCounter, 1) = teamSwitch3
                    myBracketCounter = myBracketCounter + 1
                    theBracket(myBracketCounter, 0) = teamSwitch4
                    theBracket(myBracketCounter, 1) = teamSwitch2
                    hasBeenUsed(teamSwitch1) = 1 : hasBeenUsed(teamSwitch2) = 1
                    hasBeenUsed(teamSwitch3) = 1 : hasBeenUsed(teamSwitch4) = 1
                End If
            End If
        End If
        'Second loop to check for unscheduled
        For i As Integer = 1 To myTopNumber
            If myTop(i) > 0 And hasBeenUsed(myTop(i)) = 0 Then
                'there is a team here not scheduled
                scheduleProblemFoundT = scheduleProblemFoundT + 1
                problemT = myTop(i)
            End If
        Next
        For i As Integer = 1 To myBottomNumber
            If myBottom(i) > 0 And hasBeenUsed(myBottom(i)) = 0 Then
                'there is a team here not scheduled
                scheduleProblemFoundB = scheduleProblemFoundB + 1
                problemB = myBottom(i)
                fff = problemB
            End If
        Next

        If scheduleProblemFoundT = 1 And scheduleProblemFoundB = 1 Then
            'must repair the schedule

            iCanSwitch = 1
            teamSwitch1 = problemT
            teamSwitch2 = problemB
            teamSwitch3 = theBracket(myBracketCounter, 0)
            teamSwitch4 = theBracket(myBracketCounter, 1)
            'Now the question is: 
            'Can teamSwitch1 meet teamSwitch4 and can teamSwitch3 meet teamSwitch2?
            If iCanMeet(teamSwitch1, teamSwitch4) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch4, teamSwitch1) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch3, teamSwitch2) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch2, teamSwitch3) > 0 Then iCanSwitch = 0
            If iCanSwitch = 1 Then
                theBracket(myBracketCounter, 0) = teamSwitch1
                theBracket(myBracketCounter, 1) = teamSwitch4
                myBracketCounter = myBracketCounter + 1
                theBracket(myBracketCounter, 0) = teamSwitch3
                theBracket(myBracketCounter, 1) = teamSwitch2
                hasBeenUsed(teamSwitch1) = 1 : hasBeenUsed(teamSwitch2) = 1
                hasBeenUsed(teamSwitch3) = 1 : hasBeenUsed(teamSwitch4) = 1
            Else
                'well this switch didn't work so try another since this is not side constrained
                'Can teamSwitch1 meet teamSwitch3 and can teamSwitch4 meet teamSwitch2?
                If iCanMeet(teamSwitch1, teamSwitch3) > 0 Then iCanSwitch = 0
                If iCanMeet(teamSwitch3, teamSwitch1) > 0 Then iCanSwitch = 0
                If iCanMeet(teamSwitch4, teamSwitch2) > 0 Then iCanSwitch = 0
                If iCanMeet(teamSwitch2, teamSwitch4) > 0 Then iCanSwitch = 0
                If iCanSwitch = 1 Then
                    theBracket(myBracketCounter, 0) = teamSwitch1
                    theBracket(myBracketCounter, 1) = teamSwitch3
                    myBracketCounter = myBracketCounter + 1
                    theBracket(myBracketCounter, 0) = teamSwitch4
                    theBracket(myBracketCounter, 1) = teamSwitch2
                    hasBeenUsed(teamSwitch1) = 1 : hasBeenUsed(teamSwitch2) = 1
                    hasBeenUsed(teamSwitch3) = 1 : hasBeenUsed(teamSwitch4) = 1
                End If
            End If
        End If

        topCounter = myBracketCounter
        saveSchedule()

    End Sub
    Private Sub presetOdd()
        Dim aaa20, myRating As String
        Dim myTop(300), myBottom(300), theTeam As Integer
        Dim myTopNumber, myBottomNumber, iOK As Integer
        Dim myHalfPoint As Integer
        Dim sideSwitcher As Integer
        Dim iCanMeet(600, 600) As Integer
        Dim hasBeenUsed(600) As Integer
        Dim myBracketCounter As Integer
        Dim byeTeam As Integer
        Dim scheduleProblemFoundT, scheduleProblemFoundB As Integer
        Dim iOne, iTwo As Integer
        Dim problemT, problemB As Integer
        Dim hasHadBye(600) As Integer
        Dim iCanSwitch, teamSwitch1, teamSwitch2, teamSwitch3, teamSwitch4 As Integer
        For i As Integer = 0 To 300
            For ii As Integer = 0 To 9
                theBracket(i, ii) = 0
            Next
        Next

        Dim myLength As Integer
        Randomize()
        numsort1 = 0 : numsort2 = 0 : numsort3 = 0
        For i As Integer = 0 To 600
            order1(i) = ""
            order2(i) = ""
            order3(i) = ""
        Next
        For myTeam As Integer = 1 To wTopTeam
            For iRd As Integer = 1 To 9
                If byemark(myTeam, iRd) = 1 Then
                    hasHadBye(myTeam) = 1
                End If

            Next
            If myTeam = 1 Then
                aaa20 = (Int((999 - 111 + 1) * Rnd() + 111)).ToString
                sideSwitcher = 2
                If Val(aaa20) > 500 Then sideSwitcher = 1
            End If
            aaa20 = (Int((999 - 111 + 1) * Rnd() + 111)).ToString
            myRating = (1000 + aTeamRating(myTeam)).ToString 'higher is better in team rating
            numsort1 = numsort1 + 1
            order1(numsort1) = myRating & " " & aaa20 & Space(20) & myTeam.ToString

        Next
        insertionSort1()
        myHalfPoint = numsort1 / 2

        If numsort1 / 2 <> Int(numsort1 / 2) Then
            'bye is necessary
            'assign a bye to the team at the end of the seed list
            For i As Integer = numsort1 To 1 Step -1
                myLength = Len(order1(i))
                theTeam = Val(Mid(order1(i), myLength - 2, 3))
                If hasHadBye(theTeam) = 0 Then
                    myBracketCounter = myBracketCounter + 1
                    theBracket(myBracketCounter, 0) = theTeam
                    byeTeam = theTeam
                    byemark(byeTeam, wCurrentRound) = 1
                    hasBeenUsed(byeTeam) = 1
                    If wCurrentRound = 3 Then
                        wSeedingArray(byeTeam, 8) = 3
                    End If
                    If wCurrentRound = 5 Then
                        wSeedingArray(byeTeam, 12) = 3
                    End If
                    Exit For
                End If
            Next
        End If
        'reorder the list without the bye
        numsort1 = 0 : numsort2 = 0 : numsort3 = 0
        For i As Integer = 0 To 600
            order1(i) = ""
            order2(i) = ""
            order3(i) = ""
        Next
        For myTeam As Integer = 1 To wTopTeam
            If hasBeenUsed(myTeam) <> 1 Then
                aaa20 = (Int((999 - 111 + 1) * Rnd() + 111)).ToString
                myRating = (1000 + aTeamRating(myTeam)).ToString
                numsort1 = numsort1 + 1
                order1(numsort1) = myRating & " " & aaa20 & Space(20) & myTeam.ToString
            End If
        Next
        insertionSort1()
        myHalfPoint = numsort1 / 2

        For i As Integer = 1 To numsort1
            myLength = Len(order1(i))
            theTeam = Val(Mid(order1(i), myLength - 2, 3))
            If theTeam <> byeTeam Then
                aRd1Rating(theTeam) = 999 - i 'this will be what is stored in the MatchWith Field (higher is better)
                If i <= myHalfPoint Then
                    myTopNumber = myTopNumber + 1
                    myTop(myTopNumber) = theTeam
                Else
                    myBottomNumber = myBottomNumber + 1
                    myBottom(myBottomNumber) = theTeam
                End If
            End If
        Next

        If myTopNumber / 2 <> Int(myTopNumber / 2) Then
            myTopNumber = myTopNumber + 1
            myBottomNumber = myBottomNumber - 1
        End If

        For iCounter As Integer = 1 To wTopTeam
            iOne = iCounter
            For iCounter1 As Integer = 1 To wTopTeam
                iTwo = iCounter1
                'have the two teams met before?
                iOK = 0
                For iRd As Integer = 1 To 9
                    If iRd <> wCurrentRound Then
                        If teamHad(iOne, iRd) = iTwo Then iOK = 1 : iRd = 9
                    End If
                Next iRd
                'are the two teams from same school
                If wSeedingArray(iOne, 1) = wSeedingArray(iTwo, 1) Then iOK = 1
                If iOK = 1 Then
                    iCanMeet(iOne, iTwo) = 1
                    iCanMeet(iTwo, iOne) = 1
                End If
            Next iCounter1
        Next iCounter
        'ready now to pair this round
        For i As Integer = 1 To myTopNumber
            iOne = myTop(i)
            'find an opponent for iOne
            If hasBeenUsed(iOne) = 0 Then
                For ii As Integer = 1 To myBottomNumber
                    iTwo = myBottom(ii)
                    'Determine whether this pairing is possible
                    iOK = 1
                    If iCanMeet(iOne, iTwo) = 1 Or iCanMeet(iTwo, iOne) = 1 Then iOK = 0
                    If hasBeenUsed(iTwo) > 0 Then iOK = 0
                    If iOK = 1 Then
                        'Create this pairing
                        hasBeenUsed(iOne) = 1 : hasBeenUsed(iTwo) = 1
                        myBracketCounter = myBracketCounter + 1
                        If sideSwitcher = 1 Then
                            sideSwitcher = 2
                            theBracket(myBracketCounter, 0) = iOne
                            theBracket(myBracketCounter, 1) = iTwo
                        Else
                            sideSwitcher = 1
                            theBracket(myBracketCounter, 0) = iTwo
                            theBracket(myBracketCounter, 1) = iOne
                        End If
                        ii = myBottomNumber
                    End If
                Next
            End If

        Next
        'Now must determine if any team remains unscheduled
        For i As Integer = 1 To myTopNumber
            If myTop(i) > 0 And hasBeenUsed(myTop(i)) = 0 Then
                'there is a team here not scheduled
                scheduleProblemFoundT = scheduleProblemFoundT + 1
                problemT = myTop(i)
            End If
        Next
        For i As Integer = 1 To myBottomNumber
            If myBottom(i) > 0 And hasBeenUsed(myBottom(i)) = 0 Then
                'there is a team here not scheduled
                scheduleProblemFoundB = scheduleProblemFoundB + 1
                problemB = myBottom(i)
            End If
        Next
        If scheduleProblemFoundT = 1 And scheduleProblemFoundB = 1 Then
            'must repair the schedule
            iCanSwitch = 1
            teamSwitch1 = problemT
            teamSwitch2 = problemB
            teamSwitch3 = theBracket(myBracketCounter, 0)
            teamSwitch4 = theBracket(myBracketCounter, 1)
            'Now the question is: 
            'Can teamSwitch1 meet teamSwitch4 and can teamSwitch3 meet teamSwitch2?
            If iCanMeet(teamSwitch1, teamSwitch4) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch4, teamSwitch1) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch3, teamSwitch2) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch2, teamSwitch3) > 0 Then iCanSwitch = 0
            If iCanSwitch = 1 Then
                theBracket(myBracketCounter, 0) = teamSwitch1
                theBracket(myBracketCounter, 1) = teamSwitch4
                myBracketCounter = myBracketCounter + 1
                theBracket(myBracketCounter, 0) = teamSwitch3
                theBracket(myBracketCounter, 1) = teamSwitch2
                hasBeenUsed(teamSwitch1) = 1 : hasBeenUsed(teamSwitch2) = 1
                hasBeenUsed(teamSwitch3) = 1 : hasBeenUsed(teamSwitch4) = 1
            Else
                'well this switch didn't work so try another since this is not side constrained
                'Can teamSwitch1 meet teamSwitch3 and can teamSwitch4 meet teamSwitch2?
                If iCanMeet(teamSwitch1, teamSwitch3) > 0 Then iCanSwitch = 0
                If iCanMeet(teamSwitch3, teamSwitch1) > 0 Then iCanSwitch = 0
                If iCanMeet(teamSwitch4, teamSwitch2) > 0 Then iCanSwitch = 0
                If iCanMeet(teamSwitch2, teamSwitch4) > 0 Then iCanSwitch = 0
                If iCanSwitch = 1 Then
                    theBracket(myBracketCounter, 0) = teamSwitch1
                    theBracket(myBracketCounter, 1) = teamSwitch3
                    myBracketCounter = myBracketCounter + 1
                    theBracket(myBracketCounter, 0) = teamSwitch4
                    theBracket(myBracketCounter, 1) = teamSwitch2
                    hasBeenUsed(teamSwitch1) = 1 : hasBeenUsed(teamSwitch2) = 1
                    hasBeenUsed(teamSwitch3) = 1 : hasBeenUsed(teamSwitch4) = 1
                End If
            End If
        End If
        'Second Loop: Check for Unscheduled
        problemT = 0 : problemB = 0 : scheduleProblemFoundB = 0 : scheduleProblemFoundT = 0

        For i As Integer = 1 To myTopNumber
            If myTop(i) > 0 And hasBeenUsed(myTop(i)) = 0 Then
                'there is a team here not scheduled
                scheduleProblemFoundT = scheduleProblemFoundT + 1
                problemT = myTop(i)
            End If
        Next
        For i As Integer = 1 To myBottomNumber
            If myBottom(i) > 0 And hasBeenUsed(myBottom(i)) = 0 Then
                'there is a team here not scheduled
                scheduleProblemFoundB = scheduleProblemFoundB + 1
                problemB = myBottom(i)
            End If
        Next
        If scheduleProblemFoundT = 1 And scheduleProblemFoundB = 1 Then
            'must repair the schedule
            iCanSwitch = 1
            teamSwitch1 = problemT
            teamSwitch2 = problemB
            teamSwitch3 = theBracket(myBracketCounter, 0)
            teamSwitch4 = theBracket(myBracketCounter, 1)
            'Now the question is: 
            'Can teamSwitch1 meet teamSwitch4 and can teamSwitch3 meet teamSwitch2?
            If iCanMeet(teamSwitch1, teamSwitch4) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch4, teamSwitch1) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch3, teamSwitch2) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch2, teamSwitch3) > 0 Then iCanSwitch = 0
            If iCanSwitch = 1 Then
                theBracket(myBracketCounter, 0) = teamSwitch1
                theBracket(myBracketCounter, 1) = teamSwitch4
                myBracketCounter = myBracketCounter + 1
                theBracket(myBracketCounter, 0) = teamSwitch3
                theBracket(myBracketCounter, 1) = teamSwitch2
                hasBeenUsed(teamSwitch1) = 1 : hasBeenUsed(teamSwitch2) = 1
                hasBeenUsed(teamSwitch3) = 1 : hasBeenUsed(teamSwitch4) = 1
            Else
                'well this switch didn't work so try another since this is not side constrained
                'Can teamSwitch1 meet teamSwitch3 and can teamSwitch4 meet teamSwitch2?
                If iCanMeet(teamSwitch1, teamSwitch3) > 0 Then iCanSwitch = 0
                If iCanMeet(teamSwitch3, teamSwitch1) > 0 Then iCanSwitch = 0
                If iCanMeet(teamSwitch4, teamSwitch2) > 0 Then iCanSwitch = 0
                If iCanMeet(teamSwitch2, teamSwitch4) > 0 Then iCanSwitch = 0
                If iCanSwitch = 1 Then
                    theBracket(myBracketCounter, 0) = teamSwitch1
                    theBracket(myBracketCounter, 1) = teamSwitch3
                    myBracketCounter = myBracketCounter + 1
                    theBracket(myBracketCounter, 0) = teamSwitch4
                    theBracket(myBracketCounter, 1) = teamSwitch2
                    hasBeenUsed(teamSwitch1) = 1 : hasBeenUsed(teamSwitch2) = 1
                    hasBeenUsed(teamSwitch3) = 1 : hasBeenUsed(teamSwitch4) = 1
                End If
            End If
        End If
        'Third Loop: Check for Unscheduled
        problemT = 0 : problemB = 0 : scheduleProblemFoundB = 0 : scheduleProblemFoundT = 0

        For i As Integer = 1 To myTopNumber
            If myTop(i) > 0 And hasBeenUsed(myTop(i)) = 0 Then
                'there is a team here not scheduled
                scheduleProblemFoundT = scheduleProblemFoundT + 1
                problemT = myTop(i)
            End If
        Next
        For i As Integer = 1 To myBottomNumber
            If myBottom(i) > 0 And hasBeenUsed(myBottom(i)) = 0 Then
                'there is a team here not scheduled
                scheduleProblemFoundB = scheduleProblemFoundB + 1
                problemB = myBottom(i)
            End If
        Next
        If scheduleProblemFoundT = 1 And scheduleProblemFoundB = 1 Then
            'must repair the schedule
            iCanSwitch = 1
            teamSwitch1 = problemT
            teamSwitch2 = problemB
            teamSwitch3 = theBracket(myBracketCounter, 0)
            teamSwitch4 = theBracket(myBracketCounter, 1)
            'Now the question is: 
            'Can teamSwitch1 meet teamSwitch4 and can teamSwitch3 meet teamSwitch2?
            If iCanMeet(teamSwitch1, teamSwitch4) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch4, teamSwitch1) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch3, teamSwitch2) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch2, teamSwitch3) > 0 Then iCanSwitch = 0
            If iCanSwitch = 1 Then
                theBracket(myBracketCounter, 0) = teamSwitch1
                theBracket(myBracketCounter, 1) = teamSwitch4
                myBracketCounter = myBracketCounter + 1
                theBracket(myBracketCounter, 0) = teamSwitch3
                theBracket(myBracketCounter, 1) = teamSwitch2
                hasBeenUsed(teamSwitch1) = 1 : hasBeenUsed(teamSwitch2) = 1
                hasBeenUsed(teamSwitch3) = 1 : hasBeenUsed(teamSwitch4) = 1
            Else
                'well this switch didn't work so try another since this is not side constrained
                'Can teamSwitch1 meet teamSwitch3 and can teamSwitch4 meet teamSwitch2?
                If iCanMeet(teamSwitch1, teamSwitch3) > 0 Then iCanSwitch = 0
                If iCanMeet(teamSwitch3, teamSwitch1) > 0 Then iCanSwitch = 0
                If iCanMeet(teamSwitch4, teamSwitch2) > 0 Then iCanSwitch = 0
                If iCanMeet(teamSwitch2, teamSwitch4) > 0 Then iCanSwitch = 0
                If iCanSwitch = 1 Then
                    theBracket(myBracketCounter, 0) = teamSwitch1
                    theBracket(myBracketCounter, 1) = teamSwitch3
                    myBracketCounter = myBracketCounter + 1
                    theBracket(myBracketCounter, 0) = teamSwitch4
                    theBracket(myBracketCounter, 1) = teamSwitch2
                    hasBeenUsed(teamSwitch1) = 1 : hasBeenUsed(teamSwitch2) = 1
                    hasBeenUsed(teamSwitch3) = 1 : hasBeenUsed(teamSwitch4) = 1
                End If
            End If
        End If
        topCounter = myBracketCounter
        saveSchedule()

    End Sub

    Private Sub presetEven()
        'for any even presets, the program will load up order1(teams must be aff) and order2(teams must be neg
        'Then each of the arrays will be ordered by the strength of competition they have met so far
        'Aff side will be ordered from 
        'if random is desired, the same system will be used, except that seeding is made entirely random
        'first construct the list of competing teams
        Dim myTop(300), myBottom(300), theTeam, aaa20 As Integer
        Dim iOK As Integer
        Dim myHalfPoint As Integer
        Dim myByeCount As Integer
        Dim myByes(20) As Integer
        Dim sideMarker(600), countAff, countNeg As Integer
        Dim sideSwitcher As Integer
        Dim iCanMeet(600, 600) As Integer
        Dim hasBeenUsed(600) As Integer
        Dim myBracketCounter, myQuarterPoint As Integer
        Dim aaa As String
        Dim byeTeam As Integer
        Dim hasHadBye(600) As Integer
        Dim scheduleProblemFoundT, scheduleProblemFoundB As Integer
        Dim iOne, iTwo As Integer
        Dim excessSide As Integer
        Dim problemT, problemB, myRating As Integer
        Dim removedFromOrder1(600) As Integer
        Dim teamSwitch1, teamSwitch2, teamSwitch3, teamSwitch4, iCanSwitch As Integer
        For i As Integer = 0 To 300
            For ii As Integer = 0 To 9
                theBracket(i, ii) = 0
            Next
        Next
        For iCounter As Integer = 1 To wTopTeam
            iOne = iCounter
            For iCounter1 As Integer = 1 To wTopTeam
                iTwo = iCounter1
                'have the two teams met before?
                iOK = 0
                For iRd As Integer = 1 To 9
                    If iRd <> wCurrentRound Then
                        If teamHad(iOne, iRd) = iTwo Then iOK = 1 : iRd = 9
                    End If
                Next iRd
                'are the two teams from same school
                If wSeedingArray(iOne, 1) = wSeedingArray(iTwo, 1) Then iOK = 1
                If iOK = 1 Then
                    iCanMeet(iOne, iTwo) = 1
                    iCanMeet(iTwo, iOne) = 1
                End If
            Next iCounter1
        Next iCounter

        Dim myLength As Integer
        Randomize()
        numsort1 = 0 : numsort2 = 0 : numsort3 = 0
        For i As Integer = 0 To 600
            order1(i) = ""
            order2(i) = ""
            order3(i) = ""
        Next
        For myTeam As Integer = 1 To wTopTeam
            For iRd As Integer = 1 To 9
                If byemark(myTeam, iRd) = 1 Then hasHadBye(myTeam) = 1
            Next
            'determine whether the team must be aff or neg
            If side(myTeam, wCurrentRound - 1) = 1 Then
                sideMarker(myTeam) = 2
                countNeg = countNeg + 1
            End If
            If side(myTeam, wCurrentRound - 1) = 2 Then
                sideMarker(myTeam) = 1
                countAff = countAff + 1
            End If
            If side(myTeam, wCurrentRound - 1) = 0 Then
                If byemark(myTeam, wCurrentRound - 1) = 1 Then
                    myByeCount = myByeCount + 1
                    myByes(myByeCount) = myTeam
                End If
            End If
            aaa20 = (Int((999 - 111 + 1) * Rnd() + 111)).ToString
            myRating = (1000 + aTeamRating(myTeam)).ToString 'higher is better in team rating
            numsort1 = numsort1 + 1
            order1(numsort1) = myRating & " " & aaa20 & Space(20) & myTeam.ToString
        Next
        insertionSort1()
        myHalfPoint = Int(numsort1 * 0.5)
        If countAff > countNeg Then sideSwitcher = 2
        If countAff > countNeg Then sideSwitcher = 1
        If countAff = countNeg Then sideSwitcher = 1

        For i As Integer = 1 To myByeCount
            If sideSwitcher = 1 Then
                sideMarker(myByes(i)) = 2
                countNeg = countNeg + 1
                sideSwitcher = 2
            Else
                sideMarker(myByes(i)) = 1
                countAff = countAff + 1
                sideSwitcher = 1
            End If
        Next
        excessSide = 2
        If countAff > countNeg Then excessSide = 1
        'if excessside=1 then the bye must come from a team coming up aff
        If numsort1 / 2 <> Int(numsort1 / 2) Then
            'bye is necessary

            For i As Integer = numsort1 To 1 Step -1
                myLength = Len(order1(i))
                theTeam = Val(Mid(order1(i), myLength - 2, 3))
                If hasHadBye(theTeam) = 0 Then
                    If excessSide = 1 Then
                        If sideMarker(theTeam) = 1 Then
                            byemark(theTeam, wCurrentRound) = 1
                            hasBeenUsed(theTeam) = 1
                            countAff = countAff - 1
                            removedFromOrder1(theTeam) = 1
                            byeTeam = theTeam
                            byemark(byeTeam, wCurrentRound) = 1

                            myBracketCounter = myBracketCounter + 1
                            theBracket(myBracketCounter, 0) = byeTeam
                            If wCurrentRound = 2 Then
                                wSeedingArray(byeTeam, 6) = 3
                            End If
                            If wCurrentRound = 4 Then
                                wSeedingArray(byeTeam, 10) = 3
                            End If
                            If wCurrentRound = 6 Then
                                wSeedingArray(byeTeam, 14) = 3
                            End If
                            i = 1
                        End If
                    Else
                        If sideMarker(theTeam) = 2 Then
                            byemark(theTeam, wCurrentRound) = 1
                            hasBeenUsed(theTeam) = 1
                            countNeg = countNeg - 1
                            removedFromOrder1(theTeam) = 1
                            byeTeam = theTeam
                            byemark(byeTeam, wCurrentRound) = 1
                            myBracketCounter = myBracketCounter + 1
                            theBracket(myBracketCounter, 0) = byeTeam
                            If wCurrentRound = 2 Then
                                wSeedingArray(byeTeam, 6) = 3
                            End If
                            If wCurrentRound = 4 Then
                                wSeedingArray(byeTeam, 10) = 3
                            End If
                            If wCurrentRound = 6 Then
                                wSeedingArray(byeTeam, 14) = 3
                            End If

                            i = 1
                        End If
                    End If
                End If
            Next
        End If
        myQuarterPoint = myHalfPoint / 2
        If myHalfPoint / 2 <> Int(myHalfPoint / 2) Then
            myQuarterPoint = myQuarterPoint - 1
        End If
        'Do the top of the bracket first
        'Load order2 from the top with those who must be aff
        'Load order3 from the top with those who must be neg

        For i As Integer = 1 To numsort1
            myLength = Len(order1(i))
            theTeam = Val(Mid(order1(i), myLength - 2, 3))
            If hasBeenUsed(theTeam) = 0 And removedFromOrder1(theTeam) = 0 Then
                If sideMarker(theTeam) = 1 And numsort2 < myQuarterPoint Then
                    'This team must be aff
                    removedFromOrder1(theTeam) = 1
                    numsort2 = numsort2 + 1
                    order2(numsort2) = order1(i)
                End If
                If sideMarker(theTeam) = 2 And numsort3 < myQuarterPoint Then
                    'This team must be neg
                    removedFromOrder1(theTeam) = 1
                    numsort3 = numsort3 + 1
                    order3(numsort3) = order1(i)
                End If
            End If
        Next
        'Now pair the top half of the bracket top of aff, bottom of neg


        'ready now to pair this round
        For i As Integer = 1 To numsort2
            myLength = Len(order2(i))
            iOne = Val(Mid(order2(i), myLength - 2, 3))
            'find an opponent for iOne
            If hasBeenUsed(iOne) = 0 Then
                For ii As Integer = numsort3 To 1 Step -1
                    myLength = Len(order3(ii))
                    iTwo = Val(Mid(order3(ii), myLength - 2, 3))
                    'Determine whether this pairing is possible
                    iOK = 1
                    If iCanMeet(iOne, iTwo) = 1 Or iCanMeet(iTwo, iOne) = 1 Then iOK = 0
                    If hasBeenUsed(iTwo) > 0 Then iOK = 0
                    If iOK = 1 Then
                        'Create this pairing
                        hasBeenUsed(iOne) = 1 : hasBeenUsed(iTwo) = 1
                        myBracketCounter = myBracketCounter + 1
                        theBracket(myBracketCounter, 0) = iOne
                        theBracket(myBracketCounter, 1) = iTwo
                        ii = 1
                    End If
                Next
            End If

        Next
        'Now must determine if any team remains unscheduled
        For i As Integer = 1 To numsort2
            myLength = Len(order2(i))
            iOne = Val(Mid(order2(i), myLength - 2, 3))
            If iOne > 0 And hasBeenUsed(iOne) = 0 Then
                'there is a team here not scheduled
                scheduleProblemFoundT = scheduleProblemFoundT + 1
                problemT = iOne
            End If
        Next
        For i As Integer = 1 To numsort3
            myLength = Len(order3(i))
            iTwo = Val(Mid(order3(i), myLength - 2, 3))
            If iTwo > 0 And hasBeenUsed(iTwo) = 0 Then
                'there is a team here not scheduled
                scheduleProblemFoundB = scheduleProblemFoundB + 1
                problemB = iTwo
            End If
        Next

        'Now must pair all remaining teams
        numsort2 = 0 : numsort3 = 0
        For i As Integer = 0 To 600
            order2(i) = ""
            order3(i) = ""
        Next
        For i As Integer = 1 To numsort1
            myLength = Len(order1(i))
            theTeam = Val(Mid(order1(i), myLength - 2, 3))
            If hasBeenUsed(theTeam) = 0 Then
                If sideMarker(theTeam) = 1 Then
                    'This team must be aff
                    removedFromOrder1(theTeam) = 1
                    numsort2 = numsort2 + 1
                    order2(numsort2) = order1(i)
                End If
                If sideMarker(theTeam) = 2 Then
                    'This team must be neg
                    removedFromOrder1(theTeam) = 1
                    numsort3 = numsort3 + 1
                    order3(numsort3) = order1(i)
                End If
            End If
        Next
        'Now pair the bottom half of the bracket top of aff, bottom of neg
        'ready now to pair this round
        For i As Integer = 1 To numsort2
            myLength = Len(order2(i))
            iOne = Val(Mid(order2(i), myLength - 2, 3))
            'find an opponent for iOne
            For ii As Integer = numsort3 To 1 Step -1
                myLength = Len(order3(ii))
                iTwo = Val(Mid(order3(ii), myLength - 2, 3))
                'Determine whether this pairing is possible
                iOK = 1
                If iCanMeet(iOne, iTwo) = 1 Or iCanMeet(iTwo, iOne) = 1 Then iOK = 0
                If hasBeenUsed(iTwo) > 0 Then iOK = 0
                If iOK = 1 Then
                    'Create this pairing
                    hasBeenUsed(iOne) = 1 : hasBeenUsed(iTwo) = 1
                    myBracketCounter = myBracketCounter + 1
                    theBracket(myBracketCounter, 0) = iOne
                    theBracket(myBracketCounter, 1) = iTwo
                    ii = 1
                End If
            Next
        Next
        'Now must determine if any team remains unscheduled
        For i As Integer = 1 To numsort2
            myLength = Len(order2(i))
            iOne = Val(Mid(order2(i), myLength - 2, 3))
            If iOne > 0 And hasBeenUsed(iOne) = 0 Then
                'there is a team here not scheduled
                scheduleProblemFoundT = scheduleProblemFoundT + 1
                problemT = iOne
            End If
        Next
        For i As Integer = 1 To numsort3
            myLength = Len(order3(i))
            iTwo = Val(Mid(order3(i), myLength - 2, 3))
            If iTwo > 0 And hasBeenUsed(iTwo) = 0 Then
                'there is a team here not scheduled
                scheduleProblemFoundB = scheduleProblemFoundB + 1
                problemB = iTwo
            End If
        Next

        If scheduleProblemFoundT = 1 And scheduleProblemFoundB = 1 Then
            'must repair the schedule

            iCanSwitch = 1
            teamSwitch1 = problemT
            teamSwitch2 = problemB
            teamSwitch3 = theBracket(myBracketCounter, 0)
            teamSwitch4 = theBracket(myBracketCounter, 1)
            'Now the question is: 
            'Can teamSwitch1 meet teamSwitch4 and can teamSwitch3 meet teamSwitch2?
            If iCanMeet(teamSwitch1, teamSwitch4) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch4, teamSwitch1) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch3, teamSwitch2) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch2, teamSwitch3) > 0 Then iCanSwitch = 0
            If iCanSwitch = 1 Then
                theBracket(myBracketCounter, 0) = teamSwitch1
                theBracket(myBracketCounter, 1) = teamSwitch4
                myBracketCounter = myBracketCounter + 1
                theBracket(myBracketCounter, 0) = teamSwitch3
                theBracket(myBracketCounter, 1) = teamSwitch2
                hasBeenUsed(teamSwitch1) = 1 : hasBeenUsed(teamSwitch2) = 1
                hasBeenUsed(teamSwitch3) = 1 : hasBeenUsed(teamSwitch4) = 1
            End If
        End If
        'Second Loop: Check for Unscheduled
        problemT = 0 : problemB = 0 : scheduleProblemFoundB = 0 : scheduleProblemFoundT = 0
        For i As Integer = 1 To numsort2
            myLength = Len(order2(i))
            iOne = Val(Mid(order2(i), myLength - 2, 3))
            If iOne > 0 And hasBeenUsed(iOne) = 0 Then
                'there is a team here not scheduled
                scheduleProblemFoundT = scheduleProblemFoundT + 1
                problemT = iOne
            End If
        Next
        For i As Integer = 1 To numsort3
            myLength = Len(order3(i))
            iTwo = Val(Mid(order3(i), myLength - 2, 3))
            If iTwo > 0 And hasBeenUsed(iTwo) = 0 Then
                'there is a team here not scheduled
                scheduleProblemFoundB = scheduleProblemFoundB + 1
                problemB = iTwo
            End If
        Next

        If scheduleProblemFoundT = 1 And scheduleProblemFoundB = 1 Then
            'must repair the schedule

            iCanSwitch = 1
            teamSwitch1 = problemT
            teamSwitch2 = problemB
            teamSwitch3 = theBracket(myBracketCounter, 0)
            teamSwitch4 = theBracket(myBracketCounter, 1)
            'Now the question is: 
            'Can teamSwitch1 meet teamSwitch4 and can teamSwitch3 meet teamSwitch2?
            If iCanMeet(teamSwitch1, teamSwitch4) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch4, teamSwitch1) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch3, teamSwitch2) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch2, teamSwitch3) > 0 Then iCanSwitch = 0
            If iCanSwitch = 1 Then
                theBracket(myBracketCounter, 0) = teamSwitch1
                theBracket(myBracketCounter, 1) = teamSwitch4
                myBracketCounter = myBracketCounter + 1
                theBracket(myBracketCounter, 0) = teamSwitch3
                theBracket(myBracketCounter, 1) = teamSwitch2
                hasBeenUsed(teamSwitch1) = 1 : hasBeenUsed(teamSwitch2) = 1
                hasBeenUsed(teamSwitch3) = 1 : hasBeenUsed(teamSwitch4) = 1
            End If
        End If
        'Third Loop: Check for Unscheduled
        problemT = 0 : problemB = 0 : scheduleProblemFoundB = 0 : scheduleProblemFoundT = 0
        For i As Integer = 1 To numsort2
            myLength = Len(order2(i))
            iOne = Val(Mid(order2(i), myLength - 2, 3))
            If iOne > 0 And hasBeenUsed(iOne) = 0 Then
                'there is a team here not scheduled
                scheduleProblemFoundT = scheduleProblemFoundT + 1
                problemT = iOne
            End If
        Next
        For i As Integer = 1 To numsort3
            myLength = Len(order3(i))
            iTwo = Val(Mid(order3(i), myLength - 2, 3))
            If iTwo > 0 And hasBeenUsed(iTwo) = 0 Then
                'there is a team here not scheduled
                scheduleProblemFoundB = scheduleProblemFoundB + 1
                problemB = iTwo
            End If
        Next

        If scheduleProblemFoundT = 1 And scheduleProblemFoundB = 1 Then
            'must repair the schedule

            iCanSwitch = 1
            teamSwitch1 = problemT
            teamSwitch2 = problemB
            teamSwitch3 = theBracket(myBracketCounter, 0)
            teamSwitch4 = theBracket(myBracketCounter, 1)
            'Now the question is: 
            'Can teamSwitch1 meet teamSwitch4 and can teamSwitch3 meet teamSwitch2?
            If iCanMeet(teamSwitch1, teamSwitch4) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch4, teamSwitch1) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch3, teamSwitch2) > 0 Then iCanSwitch = 0
            If iCanMeet(teamSwitch2, teamSwitch3) > 0 Then iCanSwitch = 0
            If iCanSwitch = 1 Then
                theBracket(myBracketCounter, 0) = teamSwitch1
                theBracket(myBracketCounter, 1) = teamSwitch4
                myBracketCounter = myBracketCounter + 1
                theBracket(myBracketCounter, 0) = teamSwitch3
                theBracket(myBracketCounter, 1) = teamSwitch2
                hasBeenUsed(teamSwitch1) = 1 : hasBeenUsed(teamSwitch2) = 1
                hasBeenUsed(teamSwitch3) = 1 : hasBeenUsed(teamSwitch4) = 1
            End If
        End If

        topCounter = myBracketCounter
        saveSchedule()

    End Sub
    Private Sub saveSchedule()
        'Put the information back in the wSeedingArray for return
        'topCounter is set to the highest bracket number in theBracket(600,2) array
        'set teamHad(600, 6) As Integer
        'set side(600, 6) As Integer
        'set byemark(600, 6) As Integer
        Dim myAff, myNeg As Integer

        For x As Integer = 1 To topCounter
            myAff = theBracket(x, 0) : myNeg = theBracket(x, 1)
            If myAff > 0 And myNeg > 0 Then

                teamHad(myAff, wCurrentRound) = myNeg
                teamHad(myNeg, wCurrentRound) = myAff
                side(myAff, wCurrentRound) = 1
                side(myNeg, wCurrentRound) = 2
                Select Case wCurrentRound
                    Case 1
                        wSeedingArray(myAff, 3) = myNeg : wSeedingArray(myNeg, 3) = myAff
                        wSeedingArray(myAff, 4) = 1 : wSeedingArray(myNeg, 4) = 2
                    Case 2
                        wSeedingArray(myAff, 5) = myNeg : wSeedingArray(myNeg, 5) = myAff
                        wSeedingArray(myAff, 6) = 1 : wSeedingArray(myNeg, 6) = 2
                    Case 3
                        wSeedingArray(myAff, 7) = myNeg : wSeedingArray(myNeg, 7) = myAff
                        wSeedingArray(myAff, 8) = 1 : wSeedingArray(myNeg, 8) = 2
                    Case 4
                        wSeedingArray(myAff, 9) = myNeg : wSeedingArray(myNeg, 9) = myAff
                        wSeedingArray(myAff, 10) = 1 : wSeedingArray(myNeg, 10) = 2
                    Case 5
                        wSeedingArray(myAff, 11) = myNeg : wSeedingArray(myNeg, 11) = myAff
                        wSeedingArray(myAff, 12) = 1 : wSeedingArray(myNeg, 12) = 2
                    Case 6
                        wSeedingArray(myAff, 13) = myNeg : wSeedingArray(myNeg, 13) = myAff
                        wSeedingArray(myAff, 14) = 1 : wSeedingArray(myNeg, 14) = 2
                End Select
            End If
        Next
        

    End Sub
    Private Sub orderSort()
        'testDivision = currentDivisionName
        Dim preset As Integer
        Dim myRating As Integer
        Dim aaa20 As String
        Randomize()
        numSort = 0
        preset = 4
        For i As Integer = 0 To 600
            order(i) = ""
        Next
        For myTeam As Integer = 1 To wTopTeam
            myRating = (99999 - aTeamRating(myTeam)).ToString 'higher is better in team rating
            aaa20 = (Int((999 - 111 + 1) * Rnd() + 111)).ToString
            numSort = numSort + 1
            order(numSort) = myRating & " " & aaa20 & Space(20) & myTeam.ToString
        Next
        insertionSort()
    End Sub
    Public Sub insertionSort()
        Dim bar, j As Integer
        Dim tempVal As String
        For bar = 1 To numsort
            tempVal = order(bar)
            For j = bar To 2 Step -1
                If order(j - 1) > tempVal Then
                    order(j) = order(j - 1)
                Else
                    GoTo exitFor
                End If
            Next j
exitFor:
            order(j) = tempVal
        Next bar
    End Sub
    Public Sub insertionSort1()
        Dim bar, j As Integer
        Dim tempVal As String
        For bar = 1 To numsort1
            tempVal = order1(bar)
            For j = bar To 2 Step -1
                If order1(j - 1) > tempVal Then
                    order1(j) = order1(j - 1)
                Else
                    GoTo exitFor
                End If
            Next j
exitFor:
            order1(j) = tempVal
        Next bar
    End Sub
    Public Sub insertionSort2()
        Dim bar, j As Integer
        Dim tempVal As String
        For bar = 1 To numsort2
            tempVal = order2(bar)
            For j = bar To 2 Step -1
                If order2(j - 1) > tempVal Then
                    order2(j) = order2(j - 1)
                Else
                    GoTo exitFor
                End If
            Next j
exitFor:
            order2(j) = tempVal
        Next bar
    End Sub
    Public Sub insertionSort3()
        Dim bar, j As Integer
        Dim tempVal As String
        For bar = 1 To numsort3
            tempVal = order3(bar)
            For j = bar To 2 Step -1
                If order3(j - 1) > tempVal Then
                    order3(j) = order3(j - 1)
                Else
                    GoTo exitFor
                End If
            Next j
exitFor:
            order3(j) = tempVal
        Next bar
    End Sub
    Private Sub insertionSort5()
        Dim bar As Integer
        Dim tempVal As String
        Dim j As Integer

        For bar = 1 To numsort5
            tempVal = order5(bar)
            For j = bar To 2 Step -1
                If order5(j - 1) > tempVal Then
                    order5(j) = order5(j - 1)
                Else
                    GoTo exitFor
                End If
            Next j
exitFor:
            order5(j) = tempVal
        Next bar
    End Sub

    Public Sub insertionSort4()
        Dim bar As Integer
        Dim tempVal As String
        Dim j As Integer

        For bar = 1 To numsort4
            tempVal = order4(bar)
            For j = bar To 2 Step -1
                If order4(j - 1) > tempVal Then
                    order4(j) = order4(j - 1)
                Else
                    GoTo exitFor
                End If
            Next j
exitFor:
            order4(j) = tempVal
        Next bar
    End Sub
    Public Sub insertionSort6()
        Dim bar As Integer
        Dim tempVal As String
        Dim j As Integer

        For bar = 1 To numsort6
            tempVal = order6(bar)
            For j = bar To 2 Step -1
                If order6(j - 1) > tempVal Then
                    order6(j) = order6(j - 1)
                Else
                    GoTo exitFor
                End If
            Next j
exitFor:
            order6(j) = tempVal
        Next bar
    End Sub

End Module
