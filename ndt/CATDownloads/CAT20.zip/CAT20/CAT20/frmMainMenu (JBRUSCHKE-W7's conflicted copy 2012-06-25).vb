﻿'TO DO LIST
'Reset dates and tournament name after you change it on the tournament settings page

Imports System.IO
Imports System.Net
Imports System.Xml


Public Class frmMainMenu
    Dim DS As New DataSet

    Private Sub butBasicInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butBasicInfo.Click
        Dim strInfo As String
        strInfo = "FRIENDLY ADVICE:" & Chr(10) & Chr(10)
        strInfo &= "On most pages, there will be a button like this one that will have some tips for navigating the page.  The first time you use a page, it's probably a good idea to click on it to get oriented and figure out how to get around on the form." & Chr(10) & Chr(10)
        strInfo &= "UNDERSTANDING WHEN DATA SAVES AND FORM NAVIGATION:" & Chr(10) & Chr(10)
        strInfo &= "The buttons on this page will take you to other forms to complete your tabulation tasks." & Chr(10) & Chr(10)
        strInfo &= "You can only have ONE form open at a time; this will make sure all the information is saved correctly." & Chr(10) & Chr(10)
        strInfo &= "All data saves when you close the form you are working on and return to the main menu.  It will not save to the disk until you close the page." & Chr(10) & Chr(10)
        strInfo &= "DATA FILE LOCATION:" & Chr(10) & Chr(10)
        strInfo &= "The CAT will create a folder in your documents folder very cleverly called 'CAT.'  There is only one data file the CAT will use and it will be stored the CAT folder in your documents." & Chr(10) & Chr(10)
        strInfo &= "The file is called 'TourneyData.xml,' it is a text file, and .xml files are supposed to be human-readable, but be aware that any change you make might make the file unusable by the program." & Chr(10) & Chr(10)
        strInfo &= "You can copy and rename the file to back it up, naming it something like 'TourneyDataAfterRd1.'" & Chr(10) & Chr(10)
        strInfo &= "NOTES ON DATA GRIDS:" & Chr(10) & Chr(10)
        strInfo &= "Almost all the data will be displayed in data grids.  Generally, you select an entire row by clicking in the gray box to the far left of the row." & Chr(10) & Chr(10)
        strInfo &= "You can select an individual cell by clicking on it, and you can sort the columns by clicking on them.  The delete button will delete an entire row if the row has been selected." & Chr(10) & Chr(10)
        strInfo &= "You can add a row to a datagrid by clicking on the little asterisk to the far left of the last row on the grid and then entering the appropriate values." & Chr(10) & Chr(10)
        strInfo &= "There will be times, however, when specific circumstances mean these general rules won't apply (some grids won't allow adding rows, or some columns can't be sorted, etc.)" & Chr(10) & Chr(10)
        MsgBox(strInfo, , "Basic CAT 2.0 Information")
    End Sub
    Private Sub frmMainMenu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Check that the data directory exists the documents folder; if not, create it
        Call checkDirectory()
        'Check that the data file is in the documents folder; if not, get user to identify location
        If CheckFile() = False Then
            MsgBox("Can't find an existing data file in the right directory!  Use the buttons below to either download one from the internet or provide the location of the file on your computer.  NO OTHER function will work until you identify the data file.", MsgBoxStyle.OkOnly)
        Else
            OpenDataFile()
        End If
        'show the setup status
        If Not DS Is Nothing Then Call CheckSetupStatus()

    End Sub
    Sub CheckSetupStatus()
        lblSetupStatus.Text = SetupCompletionStatus(DS)
        lblSetupStatus.Font = New Font(lblSetupStatus.Font, FontStyle.Regular)
        If lblSetupStatus.Text <> "Setup complete!  Ready to start pairing." Then
            lblSetupStatus.ForeColor = Color.Red
            lblSetupStatus.Font = New Font(lblSetupStatus.Font, FontStyle.Bold)
        End If
        lblSetupStatus.Refresh()
    End Sub
    Sub checkDirectory()
        Dim j As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        Dim dDir As New DirectoryInfo(j & "\CAT")
        If dDir.Exists = False Then
            Directory.CreateDirectory(j & "\CAT")
        End If
    End Sub
    Function CheckFile() As Boolean
        'See if the data file exists.  If so, set the global variable strFilePath to its value.  If not, look for a 
        'user-defined location and repeat.  If it is in neither location, return a value of false.
        CheckFile = True
        'First, check for default location of file.  If it's there, exit
        Dim j As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\CAT\TourneyData.xml"
        Dim fFile As New FileInfo(j)
        If fFile.Exists Then
            CheckFile = True : strFilePath = j
            lblFileLocation.Text = "Current data file is located at " & strFilePath
            Exit Function
        End If
        'If not, see if the user has defined another location.  If so, try to open it.
        j = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\CAT\FileLocation.txt"
        fFile = New FileInfo(j)
        'exit if no user-specified location
        If Not fFile.Exists Then
            CheckFile = False
            lblFileLocation.Text = "NO CURRENT DATA FILE!!!! Identify one using the buttons below."
            Exit Function
        End If
        'There is a user-specified location, so check to see if the file exists
        Dim strFileLoc As String
        Dim reader As StreamReader = File.OpenText(j)
        strFileLoc = reader.ReadLine()
        reader.Close()
        fFile = New FileInfo(strFileLoc)
        If Not fFile.Exists Then
            CheckFile = False
            lblFileLocation.Text = "NO CURRENT DATA FILE!!!! Identify one using the buttons below."
        Else
            strFilePath = strFileLoc
            lblFileLocation.Text = "Current data file is located at " & strFilePath
        End If
    End Function

    Private Sub butTourneySetup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butTourneySetup.Click
        Call FormsOpen(frmTourneySettings)
    End Sub

    Private Sub butDivisionSetup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butDivisionSetup.Click
        Call FormsOpen(frmEnterDivisions)
    End Sub
    Sub FormsOpen(ByVal frmName As Form)
        Dim frm As Form : Dim ctr As Integer
        For Each frm In My.Application.OpenForms
            ctr += 1
        Next
        If ctr > 1 Then
            MsgBox("There is already one form open; you can only have one form open at a time.  Please check the systray at the bottom of the page and try again.")
            Exit Sub
        End If
        frmName.Show()
    End Sub
    

    Private Sub butDownload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butDownload.Click
        'define default location
        Dim j As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\CAT\TourneyData.xml"
        'check for existing file
        If CheckFile() = True Then
            Dim q As Integer = MsgBox("An exisiting data file has been identified!  If you continue the CAT will save the data file to " & j & ", delete any existing information there, and set it as the datafile location.  Click 'YES' to perform the download and 'NO' to exit without any changes.", MsgBoxStyle.YesNo)
            If q = vbNo Then Exit Sub
        End If
        'First the xsd file
        Try
            Dim URL As String
            URL = "http://www.tabroom.com/jbruschke/TourneyData.xsd"
            Dim request As HttpWebRequest = WebRequest.Create(URL)
            Dim response As HttpWebResponse = request.GetResponse()
            Dim reader As StreamReader = New StreamReader(response.GetResponseStream())
            Dim stw As StreamWriter = File.CreateText(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) & "\CAT\TourneyData.xsd")
            lblFileLocation.Text = "Download in progress...." : lblFileLocation.Refresh()
            stw.WriteLine(reader.ReadToEnd())
            reader.Close()
            stw.Close()
        Catch
            MsgBox("Formatting file faile to download , either because the computer is not connected to the internt or the tournament to download was identified incorrectly.  If the file is especially large, you may simply want to try the download again.  Please correct the problem and try again.")
            Exit Sub
        End Try

        'Download the data file
        Try
            Dim URL As String
            URL = "http://www.tabroom.com/jbruschke/TourneyData.xml"
            Dim request As HttpWebRequest = WebRequest.Create(URL)
            Dim response As HttpWebResponse = request.GetResponse()
            Dim reader As StreamReader = New StreamReader(response.GetResponseStream())
            Dim stw As StreamWriter = File.CreateText(j)
            lblFileLocation.Text = "Download in progress...." : lblFileLocation.Refresh()
            stw.WriteLine(reader.ReadToEnd())
            reader.Close()
            stw.Close()
            MsgBox("Download complete!  The CAT will now attempt to open the file; if the file location appears above the Tournament Setup column the download was successful.")
            strFilePath = j
            lblFileLocation.Text = "Current data file is located at " & strFilePath
        Catch
            MsgBox("The download failed, either because the computer is not connected to the internt or the tournament to download was identified incorrectly.  If the file is especially large, you may simply want to try the download again.  Please correct the problem and try again.")
            Exit Sub
        End Try
        
        OpenDataFile()
    End Sub
    Private Sub butFindFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butFindFile.Click
        'If file exists inform the user
        If CheckFile() = True Then
            Dim q As Integer = MsgBox("An existing data file has already been identified at " & strFilePath & ".  Click OK to continue or CANCEL to keep the current location and exit.", MsgBoxStyle.OkCancel)
            If q = vbCancel Then Exit Sub
        End If
        'User should identify the location
        OpenFileDialog1.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        If OpenFileDialog1.ShowDialog() = DialogResult.Cancel Then Exit Sub
        strFilePath = OpenFileDialog1.FileName
        'Check that there really is a file where the user entered it
        Dim fFile As New FileInfo(strFilePath)
        If Not fFile.Exists Then
            MsgBox("That doesn't appear to be a valid location.  Click the button to try again, or download the file from the internet.")
            lblFileLocation.Text = "NO CURRENT DATA FILE!!!! Identify one using the buttons below."
            Exit Sub
        End If
        lblFileLocation.Text = "Current data file is located at " & strFilePath
        OpenDataFile()
    End Sub
    Sub OpenDataFile()
        'Try
        Call LoadFile(DS, "TourneyData")
        lblTourneyName.Text = DS.Tables("Tourn").Rows(0).Item("TournName").trim & " -- " & DS.Tables("Tourn").Rows(0).Item("StartDate").trim & " through " & DS.Tables("Tourn").Rows(0).Item("EndDate").trim
        'Catch
        'MsgBox("The file failed to open.  Check the format of the .xml file.")
        'Exit Sub
        'End Try
    End Sub
    Private Sub butEnterTeams_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butEnterTeams.Click
        Call FormsOpen(frmTeamEntry)
    End Sub
    Private Sub butUtilities_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butUtilities.Click
        DS.Tables("Judge").Columns("First").SetOrdinal(6)
        'Call InitializeScores(DS)
        'Call InitializeTieBreakers(DS)
        'Call SaveFile(DS)
        MsgBox("Done")
    End Sub

    Private Sub butSetUpRounds_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butSetUpRounds.Click
        Call FormsOpen(frmRounds)
    End Sub

    Private Sub butManualChange_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butManualChange.Click
        Call FormsOpen(frmShowPairings)
    End Sub

    Private Sub butTieBreakers_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butTieBreakers.Click
        Call FormsOpen(frmTieBreakers)
    End Sub

    Private Sub butResults_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butResults.Click
        Call FormsOpen(frmResults)
    End Sub

    Private Sub butPairRound_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butPairRound.Click
        Call FormsOpen(frmPair)
    End Sub

    Private Sub butElims_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butElims.Click
        Call FormsOpen(frmElims)
    End Sub

    Private Sub butCards_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butCards.Click
        Call FormsOpen(frmCards)
    End Sub

    Private Sub butManualPair_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butManualPair.Click
        Call FormsOpen(frmManualPair)
    End Sub

    Private Sub butTRPCPair_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butTRPCPair.Click
        Call FormsOpen(frmTRPCPair)
    End Sub

    Private Sub butSetupUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butSetupUpdate.Click
        Call CheckSetupStatus()
    End Sub

    Private Sub butSchoolEntry_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butSchoolEntry.Click
        Call FormsOpen(frmSchoolEntry)
    End Sub

    Private Sub butEnterJudges_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butEnterJudges.Click
        Call FormsOpen(frmJudgeEntry)
    End Sub

    Private Sub butJudgePref_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butJudgePref.Click
        Call FormsOpen(frmJudgePref)
    End Sub

    Private Sub butEnterRooms_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butEnterRooms.Click
        Call FormsOpen(frmRoomEntry)
    End Sub
End Class
