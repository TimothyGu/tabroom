﻿
Public Class frmJudgePref

    Dim ds As New DataSet
    Private Sub frmJudgePref_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        LoadFile(ds, "TourneyData")

        ds.Tables("Entry").DefaultView.Sort = "FullName"
        cboTeam.DataSource = ds.Tables("Entry").DefaultView
        cboTeam.ValueMember = "ID"
        cboTeam.DisplayMember = "FullName"

        Dim dt As New DataTable
        dt = ds.Tables("Entry")
        cboCopyTo.DataSource = dt
        cboCopyTo.ValueMember = "ID"
        cboCopyTo.DisplayMember = "FullName"

        'add and populate name column
        lblMessage.Text = "Loading judge names..." : lblMessage.Refresh()
        ds.Tables("JudgePref").Columns.Add(("JudgeName"), System.Type.GetType("System.String"))
        Dim dr As DataRow
        For x = 0 To ds.Tables("JudgePref").Rows.Count - 1
            dr = ds.Tables("Judge").Rows.Find(ds.Tables("JudgePref").Rows(x).Item("Judge"))
            ds.Tables("JudgePref").Rows(x).Item("JudgeName") = dr.Item("Last").trim & ", " & dr.Item("First").trim
        Next x
        'display whether any division is using prefs
        Dim dummy As String = PrefsInUse()
        If dummy <> "" Then lblMessage.Text &= dummy
        'change the message
        lblMessage.Text = "Select a team above; prefs status will appear here." & Chr(10) & Chr(10)
        lblMessage.Text &= "If you have not yet done so, make sure you click the HELP button in the top-right and use the 2 buttons to the right BEFORE you first begin placing judges." : lblMessage.Refresh()
    End Sub
    Private Sub frmJudgePref_Unload(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Disposed
        ds.Tables("JudgePref").Columns.Remove("JudgeName")
        Call SaveFile(ds)
        ds.Dispose()
    End Sub
    Sub ShowPrefs() Handles cboTeam.SelectedIndexChanged
        If cboTeam.SelectedValue.ToString = "System.Data.DataRowView" Then Exit Sub
        ds.Tables("JudgePref").DefaultView.RowFilter = "Team=" & cboTeam.SelectedValue
        ds.Tables("JudgePref").DefaultView.Sort = "Rating ASC"
        DataGridView1.AutoGenerateColumns = False
        DataGridView1.DataSource = ds.Tables("JudgePref").DefaultView
        lblMessage.Text = CheckPrefs(cboTeam.SelectedValue)
    End Sub
    Function CheckPrefs(ByVal Team As Integer) As String
        Dim fdPrefs, fdJudges, drPref As DataRow() : Dim drTeam As DataRow
        fdPrefs = ds.Tables("JudgePref").Select("Team=" & Team)
        CheckPrefs = ""
        'Look for unrated judges
        Dim ctr As Integer
        For x = 0 To fdPrefs.Length - 1
            If fdPrefs(x).Item("Rating") Is System.DBNull.Value Then ctr += 1
            If fdPrefs(x).Item("Rating") = 0 Then ctr += 1
            If fdPrefs(x).Item("Rating") = 333 Then ctr += 1
        Next
        If ctr > 0 Then
            CheckPrefs = ctr & " judges appear to be unrated." & Chr(10) & Chr(10)
        End If
        'Look for missing judges
        drTeam = ds.Tables("Entry").Rows.Find(Team)
        fdJudges = ds.Tables("Judge").Select("Event" & drTeam.Item("Event") & "=true")
        ctr = 0
        For x = 0 To fdJudges.Length - 1
            drPref = ds.Tables("JudgePref").Select("Team=" & Team & " and Judge=" & fdJudges(x).Item("ID"))
            If drPref.Length = 0 Then ctr += 1
            If drPref.Length > 1 Then CheckPrefs &= drTeam.Item("FullName") & " has too many rating fields for judge " & fdJudges(x).Item("First").trim & " " & fdJudges(x).Item("Last").trim & Chr(10) & Chr(10)
        Next x
        If ctr > 0 Then
            CheckPrefs &= ctr & " judges have no records in the datafile for this team." & Chr(10) & Chr(10)
        End If
        If CheckPrefs = "" Then CheckPrefs = "Ratings appear to be OK"
    End Function
    Private Sub butChangeFont_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butChangeFont.Click
        Dim x = InputBox("Enter font size:")
        If x < 6 Then x = 6
        If x > 14 Then x = 14
        DataGridView1.Font = New Font("Franklin Gothic Medium", x)
        DataGridView1.AutoResizeRows()
    End Sub
    Sub MadeChange() Handles DataGridView1.CellEndEdit
        'AutoCalc does it from the datagrid; this is necessary because the changes to the dataset don't occur on cellendedit
        Call AutoCalc()
        'Call DSAutoCalc(cboTeam.SelectedValue)
    End Sub
    Sub AutoCalc()
        Dim ctr As Integer
        For x = 0 To DataGridView1.RowCount - 1
            If x = 0 Then ctr = 1
            If x > 0 Then
                If DataGridView1.Rows(x).Cells("Rating").Value <> DataGridView1.Rows(x - 1).Cells("Rating").Value Then
                    ctr += 1
                End If
            End If
            DataGridView1.Rows(x).Cells("OrdPct").Value = FormatNumber((ctr / DataGridView1.RowCount) * 100, 2)
        Next x
    End Sub
    Function PrefsInUse() As String
        PrefsInUse = ""
        Dim fdRd As DataRow()
        For x = 0 To ds.Tables("Event").Rows.Count - 1
            fdRd = ds.Tables("Round").Select("Event=" & ds.Tables("Event").Rows(x).Item("ID"))
            For y = 0 To fdRd.Length - 1
                If fdRd(y).Item("JudgePlaceScheme") = "TeamRating" Then
                    If PrefsInUse <> "" Then PrefsInUse &= " Or "" Then"
                    PrefsInUse &= "Event=" & ds.Tables("Event").Rows(x).Item("ID")
                    Exit For
                End If
            Next y
        Next x
    End Function
    Private Sub butTestAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butTestAll.Click
        lblMessage.Text = "Finding divisions using team ratings of judges..." : lblMessage.Refresh()
        'See if division is using prefs.
        Dim sql As String = PrefsInUse()
        Dim fdteam As DataRow()
        If sql = "" Then lblMessage.Text = "No divisions appear to be using prefs.  If you want to have a division use mutual preference judging, return to the divisions/events setup screen, change the setting for the desired division, and reutrn to this page." : Exit Sub
        'pull all teams in divisions using prefs
        Dim dt As New DataTable
        dt.Columns.Add(("Team"), System.Type.GetType("System.String"))
        dt.Columns.Add(("Division"), System.Type.GetType("System.String"))
        dt.Columns.Add(("Status"), System.Type.GetType("System.String"))
        'scroll and display
        fdteam = ds.Tables("Entry").Select(sql)
        Dim dr, drDiv As DataRow
        For x = 0 To fdteam.Length - 1
            lblMessage.Text = "Loading team info " & x & "/" & fdteam.Length - 1 : lblMessage.Refresh()
            dr = dt.NewRow
            dr.Item("Team") = fdteam(x).Item("Code")
            drDiv = ds.Tables("Event").Rows.Find(fdteam(x).Item("Event"))
            dr.Item("Division") = drDiv.Item("Abbr")
            dr.Item("Status") = CheckPrefs(fdteam(x).Item("ID"))
            dt.Rows.Add(dr)
        Next x
        dt.DefaultView.Sort = "Status asc"
        DataGridView2.DataSource = dt
        DataGridView2.Visible = True
        lblMessage.Text = "Test complete." : lblMessage.Refresh()
    End Sub

    Private Sub butFixFormat_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butFixFormat.Click
        'check that all teams have a rating field for all eligible judges
        'if no record, store a zero
        'if multiple records and identical, delete one
        'if multiple records and different, ask user

        'PUll teams in divisions that use prefs
        Dim fdteam, fdjudges, fdPrefs As DataRow() : Dim dr As DataRow
        fdteam = ds.Tables("Entry").Select(PrefsInUse)
        Dim SameScore As Boolean : Dim strRating As String = ""
        For x = 0 To fdteam.Length - 1
            lblMessage.Text = "Testing team " & x & " of " & fdteam.Length - 1 : lblMessage.Refresh()
            'PUll all judges eligible to judge in division of the team
            fdjudges = ds.Tables("Judge").Select("Event" & fdteam(x).Item("Event") & "=true")
            For y = 0 To fdjudges.Length - 1
                'Pull prefs by team and judge
                fdPrefs = ds.Tables("JudgePref").Select("team=" & fdteam(x).Item("ID") & " and judge=" & fdjudges(y).Item("ID"))
                'process if no ratings field is present
                If fdPrefs.Length = 0 Then
                    dr = ds.Tables("JudgePref").NewRow
                    dr.Item("Team") = fdteam(x).Item("ID")
                    dr.Item("Judge") = fdjudges(y).Item("ID")
                    dr.Item("Rating") = 0
                    ds.Tables("JudgePref").Rows.Add(dr)
                    'process if more than 1 rating field is present
                ElseIf fdPrefs.Length > 1 Then
                    'find out whether the multiple prefs all have the same rating
                    SameScore = True
                    For z = 1 To fdPrefs.Length - 1
                        If strRating <> "" Then strRating = ", "
                        strRating &= fdPrefs(z).Item("Rating")
                        If fdPrefs(z).Item("Rating") <> fdPrefs(z - 1).Item("Rating") Then SameScore = False
                    Next z
                    'if not, ask the user for the rating and set it to the rating for the first record found
                    If SameScore = False Then
                        fdPrefs(0).Item("Rating") = (fdteam(x).Item("Code") & " have given " & fdjudges(y).Item("First").Trim & " " & fdjudges(y).Item("Last").trim & " ratings of: " & strRating & ".  Enter the desired pref for this judge:")
                    End If
                    'delete all records after the first one
                    For z = fdPrefs.Length To 1 Step -1
                        fdPrefs(z).Delete()
                    Next
                End If
            Next
        Next x
        lblMessage.Text = "Done." : lblMessage.Refresh()
    End Sub

    Private Sub butHideGrid_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butHideGrid.Click
        DataGridView2.Visible = False
    End Sub

    Private Sub butCopy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butCopy.Click
        lblMessage.Text = "Start copying..."
        If DataGridView1.RowCount = 0 Then
            MsgBox("No prefs appear to have been selected.  Select a team from the drop-down list at the top of their page; after you do so the prefs to copy from will appear in the grid to the left.  Please select a team and try again.", MsgBoxStyle.OkOnly)
            Exit Sub
        End If
        Dim q As Integer
        Dim dr1, dr2 As DataRow
        dr1 = ds.Tables("Entry").Rows.Find(cboTeam.SelectedValue)
        dr2 = ds.Tables("Entry").Rows.Find(cboCopyTo.SelectedValue)
        q = MsgBox("If you proceed, you will DELETE all the prefs for " & dr2.Item("FullName") & " and replace the with the prefs for " & dr1.Item("FullName") & ".  Click OK to complete the copy or CANCEL to exit without changes.", MsgBoxStyle.OkCancel)
        If q = vbCancel Then Exit Sub
        'Find current prefs and delete them
        Dim fdPrefs As DataRow()
        fdPrefs = ds.Tables("JudgePref").Select("Team=" & cboCopyTo.SelectedValue)
        For x = 0 To fdPrefs.Length - 1
            fdPrefs(x).Item("Rating") = 0
        Next x
        'now copy
        For x = 0 To DataGridView1.RowCount - 1
            fdPrefs = ds.Tables("JudgePref").Select("Team=" & cboCopyTo.SelectedValue & " and Judge=" & DataGridView1.Rows(x).Cells("Judge").Value)
            If fdPrefs.Length = 0 Then
                lblMessage.Text &= "Copying of " & DataGridView1.Rows(x).Cells("JudgeName").Value & " failed; there appears to be now record for the judge on the recipient team.  If this occurs because the teams are in different divisions, this is nothing to worry about.  Click the help button for information on how to fix this problem." & Chr(10) & Chr(10)
            Else
                fdPrefs(0).Item("Rating") = DataGridView1.Rows(x).Cells("Rating").Value
                fdPrefs(0).Item("OrdPct") = DataGridView1.Rows(x).Cells("OrdPct").Value
            End If
        Next x
        lblMessage.Text &= "Copying complete."
    End Sub
    Sub DSAutoCalc(ByVal team As Integer)
        'recalculates ordinal percentiles
        Dim fdPref As DataRow()
        fdPref = ds.Tables("JudgePref").Select("Team=" & team, "Rating ASC")
        Dim ctr As Integer
        For x = 0 To fdPref.Length - 1
            If x = 0 Then ctr = 1
            If x > 0 Then
                If fdPref(x).Item("Rating") <> fdPref(x - 1).Item("Rating") Then
                    ctr += 1
                End If
            End If
            fdPref(x).Item("OrdPct") = FormatNumber((ctr / fdPref.Length) * 100, 2)
        Next x
    End Sub

    Private Sub butConvertTo333_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butConvertTo333.Click
        Call DoConvert(0, 333)
    End Sub
    Sub DoConvert(ByVal oldVal As Integer, ByVal newVal As Integer)
        nobugz.PatchMsgBox(New String() {"All", "This team only"})
        Dim q As Integer
        q = MsgBox("Convert for ALL teams or THIS TEAM ONLY?", MsgBoxStyle.YesNo)
        'q=6 means all, q=7 means this team only
        Dim fdPref As DataRow()
        fdPref = ds.Tables("JudgePref").Select("Team=" & cboTeam.SelectedValue)
        If q = 6 Then fdPref = ds.Tables("JudgePref").Select("Team<>-13")
        For x = 0 To fdPref.Length - 1
            If fdPref(x).Item("Rating") = oldVal Then fdPref(x).Item("Rating") = newVal
        Next
        Dim z = MsgBox("Re-calculate ordinal percentiles?", MsgBoxStyle.YesNo)
        If z = vbYes Then
            If q = 6 Then ReCalcAllPercentiles()
            If q = 7 Then Call DSAutoCalc(cboTeam.SelectedValue)
        End If
    End Sub

    Private Sub butConvertTo0_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butConvertTo0.Click
        Call DoConvert(333, 0)
    End Sub

    Private Sub butRecalcAllPercentiles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butRecalcAllPercentiles.Click
        Call ReCalcAllPercentiles()
    End Sub
    Sub ReCalcAllPercentiles()
        For x = 0 To ds.Tables("Entry").Rows.Count - 1
            lblMessage.Text = "Recalculating percentiles for team " & x & " of " & ds.Tables("Entry").Rows.Count - 1 : lblMessage.Refresh()
            Call DSAutoCalc(ds.Tables("Entry").Rows(x).Item("ID"))
        Next
        lblMessage.Text = "Percentile recalculation complete." : lblMessage.Refresh()
    End Sub
End Class