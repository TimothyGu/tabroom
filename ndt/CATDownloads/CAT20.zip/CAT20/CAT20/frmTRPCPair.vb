﻿Public Class frmTRPCPair
    Dim ds As New DataSet
    Private Sub frmTRPCPair_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call LoadFile(ds, "TourneyData")

        'fill the divisions cbo
        cboEvents.DataSource = ds.Tables("Event")
        cboEvents.DisplayMember = "EventName"
        cboEvents.ValueMember = "ID"
        If ds.Tables("Event").Rows.Count = 1 Then
            cboEvents.SelectedIndex = 0 : Call ShowRounds()
        End If
    End Sub
    Private Sub frmTRPCPair_Unload(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Disposed
        Call SaveFile(ds)
        ds.Tables("Round").DefaultView.RowFilter.Remove(0)
        ds.Dispose()
    End Sub

    Private Sub cboEvents_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboEvents.SelectedIndexChanged
        If cboEvents.SelectedValue.ToString = "System.Data.DataRowView" Then Exit Sub
        Call ShowRounds()
    End Sub
    Sub ShowRounds()
        ds.Tables("Round").DefaultView.RowFilter = "Event=" & cboEvents.SelectedValue & " and Rd_Name <=9"
        DataGridView1.AutoGenerateColumns = False
        Dim dt As New DataTable
        dt.Columns.Add("ID", System.Type.GetType("System.Int64"))
        dt.Columns.Add("Label", System.Type.GetType("System.String"))
        dt.Columns.Add("PairingScheme", System.Type.GetType("System.String"))
        dt.Columns.Add("Entered", System.Type.GetType("System.Int16"))
        dt.Columns.Add("Paired", System.Type.GetType("System.Int16"))
        Dim dr As DataRow
        For x = 0 To ds.Tables("Round").Rows.Count - 1
            dr = dt.NewRow
            dr.Item("ID") = ds.Tables("ROund").Rows(x).Item("ID")
            dr.Item("Label") = ds.Tables("ROund").Rows(x).Item("Label")
            dr.Item("PairingScheme") = ds.Tables("ROund").Rows(x).Item("Pairingscheme")
            dt.Rows.Add(dr)
        Next x
        Dim dt2 As DataTable
        Dim fdentries As DataRow()
        fdentries = ds.Tables("Entry").Select("Event=" & cboEvents.SelectedValue)
        Dim nPaired As Integer
        For x = 0 To dt.Rows.Count - 1
            nPaired = 0
            For y = 0 To fdentries.Length - 1
                dt2 = PullBallotsByRound(ds, "ENTRY", fdentries(y).Item("ID"), dt.Rows(x).Item("ID"))
                If dt2.Rows.Count > 0 Then nPaired += 1
            Next y
            dt.Rows(x).Item("Paired") = nPaired
            dt.Rows(x).Item("Entered") = fdentries.Length
        Next x
        DataGridView1.DataSource = dt
    End Sub

    Private Sub butAutoPairPresets_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butAutoPairPresets.Click
        lblStatus.Text = "Loading..." : lblStatus.Refresh()
        'create the array and send it to rich's module
        Dim RichArray(600, 20)
        For x = 0 To ds.Tables("Entry").Rows.Count - 1
            RichArray(x + 1, 0) = ds.Tables("Entry").Rows(x).Item("ID")
            RichArray(x + 1, 1) = ds.Tables("Entry").Rows(x).Item("School")
            RichArray(x + 1, 2) = ds.Tables("Entry").Rows(x).Item("Rating")
        Next x
        'load rounds for the event
        Dim fdrd As DataRow()
        fdrd = ds.Tables("Round").Select("Event=" & cboEvents.SelectedValue, "rd_name ASC")
        'now delete all existing pairings
        For y = 0 To fdrd.Length - 1
            DeleteAllPanelsForRound(ds, fdrd(y).Item("ID"))
        Next
        Dim nPresets As Integer
        For y = 0 To fdrd.Length - 1
            If fdrd(y).Item("PairingScheme") = "Preset" Then nPresets += 1
        Next y
        lblStatus.Text = "Pairing..." : lblStatus.Refresh()
        'convert it to pairings 
        Dim allPaired As Boolean
        For x = 1 To 10
            Call doPresets(RichArray, nPresets)
            allPaired = True
            For z = 1 To 600
                If RichArray(z, 0) > 0 Then
                    For y = 4 To 4 + nPresets Step 2
                        'If RichArray(z, y) = 0 Then allPaired = False : Exit For
                    Next y
                End If
            Next z
            If allPaired = True Then Exit For
        Next x
        If allPaired = False Then
            lblStatus.Text = "Pairing attempt failed." : lblStatus.Refresh()
            MsgBox("10 attempts to pair this event have failed; either pair the round manually or use the Preset for a Small Division screen.")
            Exit Sub
        End If
        'now save
        lblStatus.Text = "Saving..." : lblStatus.Refresh()
        Dim rd, oppn As Integer
        For x = 1 To 600
            For y = 3 To 14 Step 2
                If RichArray(x, y) > 0 Then
                    If RichArray(x, y) = 0 And RichArray(x, y + 1) <> 3 Then Exit For
                    rd = (y - 1) / 2
                    If RichArray(x, y + 1) < 3 Then
                        'create panel and save
                        Dim panel As Integer = AddPanel(ds, fdrd(rd - 1).Item("ID"), 0)
                        oppn = RichArray(x, y)
                        AddTeamToPanel(ds, panel, RichArray(x, 0), RichArray(x, y + 1))
                        AddTeamToPanel(ds, panel, RichArray(oppn, 0), RichArray(oppn, y + 1))
                        RichArray(x, y) = 0 : RichArray(oppn, y) = 0
                    End If
                ElseIf RichArray(x, y + 1) = 3 Then
                    AssignBye(ds, -1, RichArray(x, 0), fdrd(rd).Item("ID"))
                End If
            Next y
        Next x
        lblStatus.Text = "Updating Status..." : lblStatus.Refresh()
        Call ShowRounds()
        lblStatus.Text = "Done." : lblStatus.Refresh()
    End Sub
End Class