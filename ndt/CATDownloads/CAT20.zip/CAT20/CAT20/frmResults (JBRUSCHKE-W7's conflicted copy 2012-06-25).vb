﻿Imports System.IO

Public Class frmResults
    Dim ds As New DataSet
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim x As Integer = InputBox("Through which round number?")
        Dim dt As DataTable
        dt = MakeTBTable(ds, x, "TEAM", "FULL")
        DataGridView1.DataSource = dt
    End Sub

    Private Sub frmResults_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call LoadFile(ds, "TourneyData")
    End Sub

    Private Sub butMakeResults_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butMakeResults.Click
        Label1.Text = "Writing entry and settings tables..." : Label1.Refresh()
        Dim STW As New StreamWriter("C:\Users\jbruschke\Documents\CAT\TourneyDataResults.xml")
        STW.WriteLine("<?xml version=""1.0""?>")
        STW.WriteLine("<TOURNAMENTRESULTS>")
        Call WriteTable(STW, "ENTRY")
        Call WriteTable(STW, "ENTRY_STUDENT")
        Call WriteTable(STW, "EVENT")
        Call WriteTable(STW, "SCHOOL")
        Call WriteTable(STW, "TOURN")
        For x = 0 To ds.Tables("Event").Rows.Count - 1
            Label1.Text = "Writing results for " & ds.Tables("Event").Rows(x).Item("EventName") : Label1.Refresh()
            Call WriteFinalRank(STW, ds.Tables("Event").Rows(x).Item("ID"))
            Call WriteRoundByRound(STW)
        Next x
        STW.WriteLine("</TOURNAMENTRESULTS>")
        STW.Close()
        Label1.Text = "Done" : Label1.Refresh()
        MsgBox("Done")
    End Sub
    Sub WriteTable(ByVal stw As StreamWriter, ByVal strTable As String)
        'writes a flat, 2-d table from the dataset

        'strip unwanted fields
        Dim dt As New DataTable
        dt = ds.Tables(strTable)
        If strTable = "ENTRY" Then dt.Columns.Remove("ADA") : dt.Columns.Remove("NOTES") : dt.AcceptChanges()

        Dim x, y As Integer
        Dim dummy As String
        For x = 0 To ds.Tables(strTable).Rows.Count - 1
            stw.WriteLine("  <" & dt.TableName.ToUpper & ">")
            For y = 0 To ds.Tables(strTable).Columns.Count - 1
                dummy = "    <" & dt.Columns(y).ColumnName.ToUpper.Trim & ">" & dt.Rows(x).Item(y).ToString.Trim & "</" & dt.Columns(y).ColumnName.ToUpper & ">"
                stw.WriteLine(dummy)
            Next y
            stw.WriteLine("  </" & dt.TableName.ToUpper & ">")
        Next x
    End Sub
    Sub WriteFinalRank(ByVal stw As StreamWriter, ByVal EventID As Integer)
        'find the TB_SET and timeslot of the last prelim
        Dim drRound As DataRow() : Dim TBSet, timeslot As Integer
        drRound = ds.Tables("Round").Select("Event=" & EventID, "timeslot asc")
        For Each row In drRound
            If row.Item("RD_Name") <= 9 Then TBSet = row.Item("TB_SET") : timeslot = row.Item("TimeSlot")
        Next
        'load the teams in order
        Dim dt As DataTable
        MsgBox("YOU NEED TO MARK THE ROUND; LAST PRELM CURRENTLY MARKED AS 58")
        dt = MakeTBTable(ds, 58, "TEAM", "Full")

        Dim x, y As Integer
        Dim dummy, strSortDirection As String
        stw.WriteLine("  <FINALRANK EventID=""" & EventID & """>")
        For x = 0 To dt.Rows.Count - 1
            stw.WriteLine("    <ENTRY EntryID=""" & dt.Rows(x).Item(0) & """>")
            For y = 3 To dt.Columns.Count - 1
                strSortDirection = "DESC" : If dt.Rows(0).Item(y) < dt.Rows(1).Item(y) Then strSortDirection = "ASC"
                dummy = "    <TIEBREAKER TB_Name=""" & dt.Columns(y).ColumnName.ToUpper.Trim & """ Sortorder=""" & y - 2 & """ SortDirection=""" & strSortDirection & """>" & dt.Rows(x).Item(y).ToString.Trim & "</TIEBREAKER>"
                stw.WriteLine(dummy)
            Next y
            stw.WriteLine("    </ENTRY>")
        Next x
        stw.WriteLine("  </FINALRANK>")
    End Sub
    Sub WriteRoundByRound(ByVal stw As StreamWriter)
        Dim dvRound As New DataView(ds.Tables("ROUND"))
        dvRound.Sort = "event asc, timeslot ASC"
        Dim x, y, z, w As Integer : Dim dummy, rdType As String
        Dim foundBallot As DataRow()
        Dim foundPanel As DataRow()
        Dim foundResult As DataRow()
        For x = 0 To dvRound.Count - 1
            rdType = "Prelim" : If dvRound(x).Item("TimeSlot") > 9 Then rdType = "Elim"
            dummy = "  <ROUNDRESULT RoundName=""" & dvRound(x).Item("Label").trim & """ Sortorder=""" & dvRound(x).Item("TimeSlot") & """ RoundType=""" & rdType & """" & """ EventID=""" & dvRound(x).Item("Event") & """" & ">"
            stw.WriteLine(dummy)
            foundPanel = ds.Tables("Panel").Select("Round=" & dvRound(x).Item("ID"))
            For y = 0 To foundPanel.Length - 1
                foundBallot = ds.Tables("Ballot").Select("Panel=" & foundPanel(y).Item("ID"), "JUDGE ASC")
                For z = 0 To foundBallot.Length - 1
                    dummy = "    <JUDGE JudgeID=""" & foundBallot(z).Item("Judge") & """ Panel=""" & foundPanel(y).Item("ID") & """" & ">"
                    If z = 0 Then stw.WriteLine(dummy)
                    If z > 0 Then If foundBallot(z).Item("Judge") <> foundBallot(z - 1).Item("Judge") Then stw.WriteLine(dummy)
                    foundResult = ds.Tables("Ballot_Score").Select("Ballot=" & foundBallot(z).Item("ID"))
                    For w = 0 To foundResult.Length - 1
                        dummy = "      <SCORE SCORE_NAME=""" & GetRowInfo(ds, "SCORES", foundResult(w).Item("SCORE_ID"), "Score_Name") & """ ScoreFor=""" & GetRowInfo(ds, "SCORES", foundResult(w).Item("SCORE_ID"), "ScoreFor") & """ Recipient=""" & foundResult(w).Item("Recipient") & """" & ">" & foundResult(w).Item("Score")
                        stw.WriteLine(dummy & "</SCORE>")
                    Next w
                    If z = foundBallot.Length - 1 Then stw.WriteLine("    </JUDGE>")
                    If z < foundBallot.Length - 1 Then If foundBallot(z).Item("Judge") <> foundBallot(z + 1).Item("Judge") Then stw.WriteLine("    </JUDGE>")
                Next z
            Next y
            stw.WriteLine("  </ROUNDRESULT>")
        Next x
    End Sub
End Class