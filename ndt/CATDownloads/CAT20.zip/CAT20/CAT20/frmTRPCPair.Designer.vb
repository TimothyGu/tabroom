﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTRPCPair
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTRPCPair))
        Me.cboEvents = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.butAutoPairPresets = New System.Windows.Forms.Button()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PairingScheme = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Entered = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Paired = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cboEvents
        '
        Me.cboEvents.FormattingEnabled = True
        Me.cboEvents.Location = New System.Drawing.Point(13, 36)
        Me.cboEvents.Name = "cboEvents"
        Me.cboEvents.Size = New System.Drawing.Size(229, 28)
        Me.cboEvents.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(110, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Select Division:"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ID, Me.Label, Me.PairingScheme, Me.Entered, Me.Paired})
        Me.DataGridView1.Location = New System.Drawing.Point(13, 71)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(390, 250)
        Me.DataGridView1.TabIndex = 2
        '
        'butAutoPairPresets
        '
        Me.butAutoPairPresets.Location = New System.Drawing.Point(424, 170)
        Me.butAutoPairPresets.Name = "butAutoPairPresets"
        Me.butAutoPairPresets.Size = New System.Drawing.Size(138, 85)
        Me.butAutoPairPresets.TabIndex = 8
        Me.butAutoPairPresets.Text = "Pair the presets for selected division"
        Me.butAutoPairPresets.UseVisualStyleBackColor = True
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Location = New System.Drawing.Point(568, 202)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(133, 20)
        Me.lblStatus.TabIndex = 9
        Me.lblStatus.Text = "Status update here"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(424, 36)
        Me.Label2.MaximumSize = New System.Drawing.Size(500, 120)
        Me.Label2.MinimumSize = New System.Drawing.Size(400, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(493, 120)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = resources.GetString("Label2.Text")
        '
        'ID
        '
        Me.ID.DataPropertyName = "ID"
        Me.ID.HeaderText = "ID"
        Me.ID.Name = "ID"
        Me.ID.ReadOnly = True
        Me.ID.Visible = False
        '
        'Label
        '
        Me.Label.DataPropertyName = "Label"
        Me.Label.HeaderText = "Round"
        Me.Label.Name = "Label"
        Me.Label.ReadOnly = True
        '
        'PairingScheme
        '
        Me.PairingScheme.DataPropertyName = "PairingScheme"
        Me.PairingScheme.HeaderText = "PairingScheme"
        Me.PairingScheme.Name = "PairingScheme"
        Me.PairingScheme.ReadOnly = True
        '
        'Entered
        '
        Me.Entered.DataPropertyName = "Entered"
        Me.Entered.HeaderText = "Entered"
        Me.Entered.Name = "Entered"
        Me.Entered.ReadOnly = True
        '
        'Paired
        '
        Me.Paired.DataPropertyName = "Paired"
        Me.Paired.HeaderText = "Paired"
        Me.Paired.Name = "Paired"
        Me.Paired.ReadOnly = True
        '
        'frmTRPCPair
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1276, 750)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.butAutoPairPresets)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cboEvents)
        Me.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmTRPCPair"
        Me.Text = "frmTRPCPair"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cboEvents As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents butAutoPairPresets As System.Windows.Forms.Button
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PairingScheme As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Entered As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Paired As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
