﻿Public Class frmManualPair
    Dim ds As New DataSet
    Dim dtG1 As DataTable
    Dim dtG2 As DataTable
    Private Sub frmManualPair_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Call LoadFile(ds, "TourneyData")

        'Make sure view settings are in place
        Call InitializeViewSettings(ds)

        'bind round CBO
        cboRound.DataSource = ds.Tables("Round")
        cboRound.DisplayMember = "Label"
        cboRound.ValueMember = "ID"

        dgvDisplayItems.AutoGenerateColumns = False

    End Sub
    Private Sub frmManualPair_Unload(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Disposed
        Call SaveFile(ds)
        ds.Dispose()
    End Sub
    Sub EraseViewSettings()
        'erase current settings
        For x = ds.Tables("ViewSettings").Rows.Count - 1 To 0 Step -1
            If ds.Tables("ViewSettings").Rows(x).Item("Round") = cboRound.SelectedValue Then
                ds.Tables("ViewSettings").Rows(x).Delete()
            End If
        Next x

    End Sub
    Sub MakeLoadSettings()
        'Creates the table that will be used to enter the load settings

        'Load the round and check there's a TBSET attached to it
        Dim drRound As DataRow
        drRound = ds.Tables("Round").Rows.Find(cboRound.SelectedValue)
        If drRound.Item("TB_SET") Is System.DBNull.Value Then
            MsgBox("There does not appear to be a list of tiebreakers associated with this round yet.  Close this screen, go to the ROUNDS screen, and set up the tiebreakers there first.")
            Exit Sub
        End If

        Call EraseViewSettings()

        'populate with standard selections
        Dim dr As DataRow
        dr = ds.Tables("ViewSettings").NewRow : dr.Item("Tag") = "Side Counts" : dr.Item("SortOrder") = 99 : dr.Item("Round") = cboRound.SelectedValue : ds.Tables("ViewSettings").Rows.Add(dr)
        dr = ds.Tables("ViewSettings").NewRow : dr.Item("Tag") = "SOP" : dr.Item("SortOrder") = 99 : dr.Item("Round") = cboRound.SelectedValue : ds.Tables("ViewSettings").Rows.Add(dr)
        dr = ds.Tables("ViewSettings").NewRow : dr.Item("Tag") = "Times pulled up" : dr.Item("SortOrder") = 99 : dr.Item("Round") = cboRound.SelectedValue : ds.Tables("ViewSettings").Rows.Add(dr)
        dr = ds.Tables("ViewSettings").NewRow : dr.Item("Tag") = "Times pulled down" : dr.Item("SortOrder") = 99 : dr.Item("Round") = cboRound.SelectedValue : ds.Tables("ViewSettings").Rows.Add(dr)
        dr = ds.Tables("ViewSettings").NewRow : dr.Item("Tag") = "Seed" : dr.Item("SortOrder") = 1 : dr.Item("Round") = cboRound.SelectedValue : ds.Tables("ViewSettings").Rows.Add(dr)

        'populate with all tiebreakers in use for this round
        Dim fdTB As DataRow()
        fdTB = ds.Tables("TieBreak").Select("TB_SET=" & drRound.Item("TB_SET"))
        If fdTB.Length = 0 Then
            MsgBox("There does not appear to be a list of tiebreakers associated with the tiebreaker set associated with this round yet.  Close this screen, go to the ROUNDS screen, and set up the tiebreakers there first.")
            Call EraseViewSettings()
            Exit Sub
        End If
        For x = 0 To fdTB.Length - 1
            dr = ds.Tables("ViewSettings").NewRow()
            dr.Item("Round") = cboRound.SelectedValue
            dr.Item("SortOrder") = 99
            dr.Item("Tag") = fdTB(x).Item("Label")
            ds.Tables("ViewSettings").Rows.Add(dr)
        Next x

    End Sub

    Private Sub butLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butLoad.Click

        Dim strtime As String
        strtime = "Start: " & Now.Second & " " & Now.Millisecond & Chr(10) & Chr(10)
        'make it so that you can only select one team per gird
        DataGridView1.MultiSelect = False
        DataGridView2.MultiSelect = False
        If chkSideConstrained.Checked = False Then
            DataGridView1.MultiSelect = True 'allow the selection of multiple teams
            DataGridView2.Visible = False
            DataGridView1.Width = 660
            DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            LoadCompetitors(DataGridView1, 0, dtG1)
            'DataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowMode.AllCells
        Else
            DataGridView2.Visible = True
            DataGridView1.Width = 330
            DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            DataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            LoadCompetitors(DataGridView1, 1, dtG1)
            LoadCompetitors(DataGridView2, 2, dtG2)
            DataGridView1.Columns("CompetitorName").Width = 100
            DataGridView2.Columns("CompetitorName").Width = 100
        End If
        strtime &= "Load Teams End: " & Now.Second & " " & Now.Millisecond & Chr(10) & Chr(10)
        LoadPairings()
        strTime &= "Load Pairings End: " & Now.Second & " " & Now.Millisecond
        Label2.Text = strtime

        Call ClearCompetitorGrids()

    End Sub
    Sub LoadCompetitors(ByVal DGV As DataGridView, ByVal SideDue As Integer, ByRef DT As DataTable)

        'Pull the tiebreakers and put them in DGV
        DT = MakeTBTable(ds, GetPriorRound(ds, cboRound.SelectedValue), "TEAM", "Code")
        dt.Constraints.Add("PrimaryKey", dt.Columns("Competitor"), True)

        'delete due otherside if not due
        If SideDue > 0 Then
            For x = dt.Rows.Count - 1 To 0 Step -1
                If GetSideDue(ds, cboRound.SelectedValue, dt.Rows(x).Item("Competitor")) <> SideDue Then
                    dt.Rows(x).Delete()
                End If
            Next x
        End If

        'now format the datagrid to display
        Dim colIndex As Integer

        'always add side reports and in round
        dt.Columns.Add("Sides", System.Type.GetType("System.String"))
        dt.Columns.Add("InRound", System.Type.GetType("System.Boolean"))
        Call AddSideReport(DT, ds)
        Call MarkActiveTeams(dt)
        DGV.DataSource = dt.DefaultView
        If chkPairedToBottom.Checked = True Then dt.DefaultView.Sort = "InRound ASC"

        'add brackets if powered round & NEED TO ADD: Only do for divisions with 2 teams per round
        Dim drRound As DataRow : drRound = ds.Tables("Round").Rows.Find(cboRound.SelectedValue)
        If drRound.Item("PairingScheme") = "HighHigh" Or drRound.Item("PairingScheme") = "HighLow" Then
            dt.Columns.Add("Bracket", System.Type.GetType("System.Int16"))
            Call BracketMarker(dt)
        End If
        'hide all columns except for the team name column
        For x = 0 To DGV.ColumnCount - 1
            DGV.Columns(x).Visible = False
            If DGV.Columns(x).Name = "COMPETITORNAME" Or DGV.Columns(x).Name = "TEAM" Then
                DGV.Columns(x).Visible = True
                DGV.Columns(x).HeaderText = "TEAM"
                DGV.Columns(x).DisplayIndex = colIndex
                colIndex += 1
            End If
        Next x

        'add columns that need to be calculated now, or make them visible if they're on the list
        For y = 0 To dgvDisplayItems.Rows.Count - 1
            If dgvDisplayItems.Rows(y).Cells("SortOrder").Value < 99 Then
                'check columns to add
                If dgvDisplayItems.Rows(y).Cells("Tag").Value.ToString.ToUpper = "SOP" Then
                    dt.Columns.Add("SOP", System.Type.GetType("System.Single"))
                    Call AddSOPValues(dt)
                End If
                If dgvDisplayItems.Rows(y).Cells("Tag").Value.ToString.ToUpper = "TIMES PULLED UP" Or dgvDisplayItems.Rows(y).Cells("Tag").Value.ToString.ToUpper = "TIMES PULLED DOWN" Then
                    If dt.Columns.IndexOf("PulledUp") = -1 Then
                        dt.Columns.Add("PulledUp", System.Type.GetType("System.Int16"))
                        dt.Columns.Add("PulledDown", System.Type.GetType("System.Int16"))
                        Call AddPullups(dt)
                        DGV.Columns("PulledDown").Visible = False : DGV.Columns("PulledUp").Visible = False
                    End If
                End If
                If dgvDisplayItems.Rows(y).Cells("Tag").Value.ToString.ToUpper = "TIMES PULLED DOWN" Then DGV.Columns("PulledDown").Visible = True
                If dgvDisplayItems.Rows(y).Cells("Tag").Value.ToString.ToUpper = "TIMES PULLED UP" Then DGV.Columns("PulledUp").Visible = True
                If dgvDisplayItems.Rows(y).Cells("Tag").Value.ToString.ToUpper = "SIDE COUNTS" Then
                    DGV.Columns("Sides").Visible = True
                    DGV.Columns("Sides").DisplayIndex = dgvDisplayItems.Rows(y).Cells("SortOrder").Value
                    colIndex += 1
                End If
                For x = 0 To DGV.ColumnCount - 1
                    If dgvDisplayItems.Rows(y).Cells("Tag").Value.ToString.Trim.ToUpper = DGV.Columns(x).Name.Trim.ToUpper Then
                        DGV.Columns(x).Visible = True
                        DGV.Columns(x).DisplayIndex = dgvDisplayItems.Rows(y).Cells("SortOrder").Value
                        colIndex += 1
                        Exit For
                    End If
                Next x
            End If
        Next y

        'put active now in last column
        DGV.Columns("InRound").Visible = True
        DGV.Columns("InRound").DisplayIndex = colIndex
        DGV.Columns("InRound").SortMode = DataGridViewColumnSortMode.Automatic

    End Sub
    Sub BracketMarker(ByVal dt As DataTable)
        For x = 0 To dt.Rows.Count - 1
            'load current bracket
            Dim dr As DataRow() : Dim dr2 As DataRow
            dr = ds.Tables("Bracket").Select("Team=" & dt.Rows(x).Item("Competitor") & " and round=" & cboRound.SelectedValue)
            'if found, mark it; if not found, add it and set to wins
            If dr.Length = 1 Then
                dt.Rows(x).Item("Bracket") = dr(0).Item("WinBracket")
            ElseIf dr.Length = 0 Then
                dt.Rows(x).Item("Bracket") = dt.Rows(x).Item("Wins")
                dr2 = ds.Tables("Bracket").NewRow
                dr2.Item("Round") = cboRound.SelectedValue
                dr2.Item("Team") = dt.Rows(x).Item("Competitor")
                dr2.Item("WinBracket") = dt.Rows(x).Item("Wins")
                ds.Tables("Bracket").Rows.Add(dr2)
            End If
        Next x
    End Sub
    Sub LoadPairings()
        'now load any existing pairing
        Call modShowThePairing(ds, dgvPairing, cboRound.SelectedValue)
        Dim nCols As Integer
        For x = 0 To dgvPairing.ColumnCount - 1
            If Mid(dgvPairing.Columns(x).Name, 1, 5).ToUpper = "JUDGE" Then dgvPairing.Columns(x).Visible = False
            If dgvPairing.Columns(x).Visible = True Then nCols += 1
        Next x
        If nCols > 2 Then dgvPairing.Font = New Font("Franklin Gothic Medium", 9)
        'set the cursor
        For x = 0 To dgvPairing.ColumnCount - 1
            For y = 0 To dgvPairing.RowCount - 1
                If dgvPairing.Columns(x).Visible = True And Mid(dgvPairing.Rows(y).Cells(x).Value.ToString.ToUpper, 1, 4) = "NONE" Then dgvPairing.CurrentCell = dgvPairing.Rows(y).Cells(x) : Exit For
            Next y
        Next x
    End Sub
    Sub AddPullups(ByRef dt As DataTable)
        'Pull all ballots by team
        'only consider those in powered rounds prior to this one
        'Get the records of the opponents and compare
        Dim x, y, youwin, theywin, PullUps, PullDowns As Integer
        Dim fdBallots, fdTeamsOnPanel As DataRow()
        Dim drRound, drPanel As DataRow
        'scroll through the teams, pull their opponents, and compare records
        Dim ProcessBallot As Boolean
        For x = 0 To dt.Rows.Count - 1
            PullUps = 0 : PullDowns = 0
            Label2.Text = x.ToString : Label2.Refresh()
            fdBallots = ds.Tables("Ballot").Select("Entry=" & dt.Rows(x).Item("Competitor"), "Panel ASC")
            For y = 0 To fdBallots.Length - 1
                'only process 1 ballot per panel
                ProcessBallot = False
                If y = 0 Then
                    ProcessBallot = True
                ElseIf fdBallots(y).Item("Panel") <> fdBallots(y - 1).Item("Panel") Then
                    ProcessBallot = True
                End If
                'only process if it's a power-matched round
                drPanel = ds.Tables("Panel").Rows.Find(fdBallots(y).Item("Panel"))
                drRound = ds.Tables("Round").Rows.Find(drPanel.Item("Round"))
                If drRound.Item("PairingScheme") <> "HighHigh" And drRound.Item("PairingScheme") <> "HighLow" Then ProcessBallot = False
                'only process if it's an earlier timeblock than the round you're pairing now
                If drRound.Item("timeslot") >= cboRound.SelectedValue Then ProcessBallot = False
                If ProcessBallot = True Then
                    fdTeamsOnPanel = ds.Tables("Ballot").Select("Panel=" & fdBallots(y).Item("Panel") & " and Entry<>" & dt.Rows(x).Item("Competitor"))
                    youwin = GetWinsForPullUps(ds, dt.Rows(x).Item("Competitor"), drRound.Item("ID"))
                    theywin = GetWinsForPullUps(ds, fdTeamsOnPanel(0).Item("Entry"), drRound.Item("ID"))
                    If theywin > youwin Then PullUps += 1
                    If theywin < youwin Then PullDowns += 1
                End If
            Next y
            dt.Rows(x).Item("PulledUp") = PullUps : dt.Rows(x).Item("PulledDown") = PullDowns
        Next x
    End Sub
    Sub AddSOPValues(ByRef dt As DataTable)
        Dim fdBallot, fdPanel As DataRow()
        Dim drTeam As DataRow
        Dim OppCt, OppSdTot As Integer
        For x = 0 To dt.Rows.Count - 1
            fdBallot = ds.Tables("Ballot").Select("Entry=" & dt.Rows(x).Item("Competitor"))
            For y = 0 To fdBallot.Length - 1
                fdPanel = ds.Tables("Ballot").Select("Panel=" & fdBallot(y).Item("Panel"))
                For z = 0 To fdPanel.Length - 1
                    If fdPanel(z).Item("Entry") <> dt.Rows(x).Item("Competitor") Then
                        OppCt += 1
                        drTeam = dt.Rows.Find(fdPanel(z).Item("Entry"))
                        If Not drTeam Is Nothing Then OppSdTot += drTeam.Item("Seed")
                    End If
                Next
            Next y
            dt.Rows(x).Item("SOP") = FormatNumber(dt.Rows(x).Item("Seed") + (OppSdTot / OppCt), 2)
        Next x
    End Sub
    Sub LoadViewSettingsByRound() Handles cboRound.SelectedValueChanged
        'don't process if this is the first load
        If cboRound.SelectedValue.ToString = "System.Data.DataRowView" Then Exit Sub
        'Filter by round
        ds.Tables("ViewSettings").DefaultView.RowFilter = "Round=" & cboRound.SelectedValue.ToString
        'Populate if empty
        If ds.Tables("ViewSettings").DefaultView.Count = 0 Then Call MakeLoadSettings()
        'sort by order to appear
        ds.Tables("ViewSettings").DefaultView.Sort = "SortOrder ASC"
        'bind
        dgvDisplayItems.DataSource = ds.Tables("ViewSettings").DefaultView
    End Sub
    Private Sub butResetDisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butResetDisplay.Click
        Call MakeLoadSettings()
    End Sub
    Private Sub butDumpRound_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butDumpRound.Click
        Call DeleteAllPanelsForRound(ds, cboRound.SelectedValue)
        ds.AcceptChanges()
        Call LoadPairings()
        ResetActives()
        ClearCompetitorGrids()
    End Sub
    Sub FillOutRound()
        'FIGURES OUT HOW MANY DEBATES THERE SHOULD BE PER ROUND, AND ADDS EXTRA BLANK SPOTS FOR ANY MISSING OPENINGS

        'pull round info to find the event
        Dim drRound As DataRow
        drRound = ds.Tables("Round").Rows.Find(cboRound.SelectedValue)
        'pull all teams in the event
        Dim teams As DataRow()
        teams = ds.Tables("Entry").Select("Event=" & drRound.Item("Event"))
        'find number of teams per debate
        Dim TeamsPerRd As Integer = getEventSetting(ds, drRound.Item("Event"), "TeamsPerRound")
        'get the number of debates based on the number of teams per round
        Dim nDebates As Integer = Int(teams.Length / TeamsPerRd)
        'add one for a partial round
        If Int(teams.Length / TeamsPerRd) <> teams.Length / TeamsPerRd Then nDebates += 1
        'now add blank panels to fill out the rest
        For x = 0 To nDebates - dgvPairing.Rows.Count
            Call AddPanel(ds, cboRound.SelectedValue)
        Next x
    End Sub

    Private Sub butCreatePanelWithTeam_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butCreatePanelWithTeam.Click
        Dim panelID As Integer = AddPanel(ds, cboRound.SelectedValue)
        AddTeamToPanel(ds, panelID, DataGridView1.CurrentRow.Cells("Competitor").Value, 1)
        Call LoadPairings()
        Dim dr As DataRow : dr = dtG1.Rows.Find(DataGridView1.CurrentRow.Cells("Competitor").Value) : dr.Item("InRound") = True
    End Sub

    Private Sub butAddTeamToSelectedPanel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butAddTeamToSelectedPanel.Click
        'get panel and team number
        Dim panel As Integer = dgvPairing.CurrentRow.Cells("Panel").Value
        Dim team As Integer = DataGridView1.CurrentRow.Cells("Competitor").Value
        'check teams are OK to debate
        Dim drRound, drPanel As DataRow
        drPanel = ds.Tables("Panel").Rows.Find(panel)
        drRound = ds.Tables("Round").Rows.Find(drPanel.Item("Round"))
        Dim nTeams As Integer = getEventSetting(ds, drRound.Item("Event"), "TeamsPerRound")
        Dim arrTeams(nTeams) As Integer
        Call UniqueItemsOnPanel(ds, panel, "Entry", nTeams, arrTeams)
        Dim strConflicts As String = ""
        For x = 0 To nTeams
            If arrTeams(x) <> -99 Then
                strConflicts &= CanDebate(ds, arrTeams(x), team)
            End If
        Next
        'Check sides are OK
        Dim Side As Integer = GetSideNumber(dgvPairing.Columns(dgvPairing.CurrentCell.ColumnIndex).HeaderText)
        strConflicts &= SideCheck(ds, team, Side, drRound.Item("ID"), DataGridView1.CurrentRow.Cells("Sides").Value)
        Dim q As Integer
        If strConflicts.Trim <> "" Then q = MsgBox(strConflicts.Trim & ". Continue with placement?", MsgBoxStyle.YesNo)
        If q = vbNo Then Exit Sub
        AddTeamToPanel(ds, panel, team, Side)
        Call LoadPairings()
        Dim dr As DataRow : dr = dtG1.Rows.Find(DataGridView1.CurrentRow.Cells("Competitor").Value) : dr.Item("InRound") = True
    End Sub
    Sub MarkActiveTeams(ByVal DT As DataTable)
        For x = 0 To DT.Rows.Count - 1
            If ActiveInTimeSlot(ds, DT.Rows(x).Item("Competitor"), cboRound.SelectedValue, "Entry") = True Then DT.Rows(x).Item("InRound") = True
        Next x
        Exit Sub
        'mark blank entries
        For x = 0 To DataGridView1.Rows.Count - 1
            If ActiveInTimeSlot(ds, DataGridView1.Rows(x).Cells("Competitor").Value, cboRound.SelectedValue, "Entry") = True Then DataGridView1.Item(1, x).Style.BackColor = Color.Red
        Next x
    End Sub
    Private Sub butDeleteFromPairing_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butDeleteFromPairing.Click
        Dim DeleteId As Integer = dgvPairing.CurrentRow.Cells(dgvPairing.CurrentCell.ColumnIndex - 1).Value
        Dim DT As DataTable
        Dim dr As DataRow
        DT = PullBallotsByRound(ds.Copy, "ENTRY", DeleteId, cboRound.SelectedValue)
        For x = 0 To DT.Rows.Count - 1
            dr = ds.Tables("Ballot").Rows.Find(DT.Rows(x).Item("ID"))
            dr.Item("Entry") = -99
        Next x
        Call LoadPairings()
        Call ResetActives()
    End Sub

    Private Sub butDeleteOneDebate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butDeleteOneDebate.Click
        Dim panel As Integer = dgvPairing.CurrentRow.Cells("Panel").Value
        Dim drPanel As DataRow : drPanel = ds.Tables("Panel").Rows.Find(panel)
        drPanel.Delete()
        ds.AcceptChanges()
        Call LoadPairings()
        Call ResetActives()
    End Sub
    Sub ResetActives()
        'Updates which teams are and are not scheduled to debate in the current round
        Dim strActive As String : Dim ctr As Integer
        strActive = DataGridView1.RowCount & " teams in column 1, "
        Dim dr As DataRow
        For x = 0 To DataGridView1.RowCount - 1
            dr = dtG1.Rows.Find(DataGridView1.Rows(x).Cells("Competitor").Value)
            dr.Item("InRound") = False
            If ActiveInTimeSlot(ds, dr.Item("Competitor"), cboRound.SelectedValue, "Entry") = True Then
                ctr += 1
                dr.Item("InRound") = True
            End If
        Next x
        strActive &= ctr & " of which are currently paired. " : Label2.Text = strActive
        If DataGridView2.Visible = False Then Exit Sub
        For x = 0 To DataGridView2.RowCount - 1
            dr = dtG2.Rows.Find(DataGridView2.Rows(x).Cells("Competitor").Value)
            dr.Item("InRound") = False
            If ActiveInTimeSlot(ds, dr.Item("Competitor"), cboRound.SelectedValue, "Entry") = True Then
                dr.Item("InRound") = True
            End If
        Next x
        Label2.Text = strActive
    End Sub
    Sub SetSideConstrainedRD() Handles cboRound.SelectedValueChanged
        'if it's an even round, check the side constrained box
        If cboRound.SelectedValue.ToString = "System.Data.DataRowView" Then Exit Sub
        Dim drRound As DataRow : drRound = ds.Tables("Round").Rows.Find(cboRound.SelectedValue)
        Dim nTeams As Integer = getEventSetting(ds, drRound.Item("Event"), "TeamsPerRound")
        Dim debateType As String = getEventSetting(ds, drRound.Item("Event"), "Type")
        If nTeams > 2 Or (debateType = "WUDC" Or debateType = "Other") Then Exit Sub
        chkSideConstrained.Checked = False
        If cboRound.SelectedIndex / 2 <> Int(cboRound.SelectedIndex / 2) Then chkSideConstrained.Checked = True
    End Sub
    Private Sub butPairTeams_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butPairTeams.Click
        Dim drRound As DataRow : drRound = ds.Tables("Round").Rows.Find(cboRound.SelectedValue)
        Dim nTeams As Integer = getEventSetting(ds, drRound.Item("Event"), "TeamsPerRound")
        If DataGridView2.Visible = True Then
            Call DoSideConstrainedAdd(nTeams)
        Else
            Call doNoSideConstrainedAdd(nTeams)
        End If
        'reset screen
        Call PostPairScreenReset()
    End Sub
    Sub doNoSideConstrainedAdd(ByVal nteams)
        Dim teams(nteams) As Integer
        'check no more teams selected than debate in a round
        Dim ctr As Integer : Dim activeNow As Boolean
        For x = 0 To DataGridView1.RowCount - 1
            If DataGridView1.Rows(x).Selected = True Then
                ctr += 1
                If ctr > nteams Then
                    MsgBox("You have selected more teams than appear in a round for this division.  Please select only " & nteams & " teams and try again.")
                    Exit Sub
                End If
                If DataGridView1.Rows(x).Cells("InRound").Value Is System.DBNull.Value Then DataGridView1.Rows(x).Cells("InRound").Value = False
                If DataGridView1.Rows(x).Cells("InRound").Value = True Then activeNow = True
                teams(ctr) = DataGridView1.Rows(x).Cells("Competitor").Value
            End If
        Next
        'check no selected teams are debating now
        If activeNow = True Then
            MsgBox("One or more of the teams selected to debate is already scheduled for this round.  Either delete them from the debate they are currently paired in or select a different team.")
            Exit Sub
        End If
        'check all selected teams can debate
        Dim strError As String = ""
        For x = 1 To nteams - 1
            For y = x + 1 To nteams
                strError &= CanDebate(ds, teams(x), teams(y))
            Next y
        Next x
        Dim q As Integer
        If strError <> "" Then q = MsgBox(strError, MsgBoxStyle.YesNo)
        If q = vbNo Then Exit Sub
        'process pairing
        Dim panel As Integer = AddPanel(ds, cboRound.SelectedValue)
        For x = 1 To nteams
            'add code to snake sides here
            AddTeamToPanel(ds, panel, teams(x), x)
        Next
        'refresh grid
        'Call ResetActives()
        'If chkPairedToBottom.Checked = True Then
        'DataGridView1.Sort(DataGridView1.Columns("InROund"), System.ComponentModel.ListSortDirection.Ascending)
        'End If
        'Call LoadPairings()
    End Sub
    Sub DoSideConstrainedAdd(ByVal nTeams As Integer)
        'check for one and only one team on each grid

        'clean up null values
        If DataGridView1.CurrentRow.Cells("InRound").Value Is System.DBNull.Value Then DataGridView1.CurrentRow.Cells("InRound").Value = False
        If DataGridView2.CurrentRow.Cells("InRound").Value Is System.DBNull.Value Then DataGridView2.CurrentRow.Cells("InRound").Value = False

        'check teams not debating now
        If DataGridView1.CurrentRow.Cells("InRound").Value = True Then
            MsgBox("The affirmative team is already scheduled to debate.  Select another team to pair, or remove this team from the current round.")
            Exit Sub
        End If
        If DataGridView2.CurrentRow.Cells("InRound").Value = True Then
            MsgBox("The negative team is already scheduled to debate.  Select another team to pair, or remove this team from the current round.")
            Exit Sub
        End If
        Dim team1 As Integer = DataGridView1.CurrentRow.Cells("Competitor").Value
        Dim team2 As Integer = DataGridView2.CurrentRow.Cells("Competitor").Value
        'check teams are OK to debate
        Dim strConflicts As String = ""
        strConflicts &= CanDebate(ds, team1, team2)
        Dim q As Integer
        If strConflicts.Trim <> "" Then
            q = MsgBox(strConflicts.Trim & ". Continue with placement?", MsgBoxStyle.YesNo)
            If q = vbNo Then Exit Sub
        End If
        'Perform add and update screen
        Dim panel As Integer = AddPanel(ds, cboRound.SelectedValue)
        AddTeamToPanel(ds, panel, team1, 1)
        AddTeamToPanel(ds, panel, team2, 2)
        
    End Sub

    Private Sub butShowBracket_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butShowBracket.Click
        Call FilterByBracket()
        Call ClearCompetitorGrids()
    End Sub
    Sub FilterByBracket()
        Dim dtv As DataView = DataGridView1.DataSource
        If txtBracket.Text.Trim = "" Then
            dtv.RowFilter = ""
        Else
            dtv.RowFilter = "Bracket=" & txtBracket.Text
        End If
        DataGridView1.DataSource = dtv
        'If DataGridView1.RowCount > 24 Then
        'DataGridView1.Font = New Font("Franklin Gothic Medium", 8)
        'DataGridView1.RowsDefaultCellStyle.Padding = New Padding(0, -5, 0, -5)
        'DataGridView1.AutoResizeRows()
        'End If
        If DataGridView2.Visible = False Then Exit Sub
        dtv = DataGridView2.DataSource
        If txtBracket.Text.Trim = "" Then
            dtv.RowFilter = ""
        Else
            dtv.RowFilter = "Bracket=" & txtBracket.Text
        End If
        DataGridView2.DataSource = dtv
        
    End Sub

    Private Sub butClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butClear.Click
        Call ClearCompetitorGrids()
    End Sub
    Sub ClearCompetitorGrids()
        For x = 0 To DataGridView1.RowCount - 1
            DataGridView1.Item(1, x).Style.BackColor = Color.White
            If DataGridView1.Rows(x).Cells("InRound").Value Is System.DBNull.Value Then DataGridView1.Rows(x).Cells("InRound").Value = False
            If DataGridView1.Rows(x).Cells("InRound").Value = True Then DataGridView1.Item(1, x).Style.BackColor = Color.LightBlue
            DataGridView1.Rows(x).Selected = False
        Next x
        If DataGridView2.Visible = False Then Exit Sub
        For x = 0 To DataGridView2.RowCount - 1
            DataGridView2.Item(1, x).Style.BackColor = Color.White
            If DataGridView2.Rows(x).Cells("InRound").Value Is System.DBNull.Value Then DataGridView2.Rows(x).Cells("InRound").Value = False
            If DataGridView2.Rows(x).Cells("InRound").Value = True Then DataGridView2.Item(1, x).Style.BackColor = Color.LightBlue
            DataGridView2.Rows(x).Selected = False
        Next x
    End Sub

    Private Sub butMoveUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butMoveUp.Click
        Call DoMove("UP")
    End Sub
    Sub DoMove(ByVal strMoveType As String)

        'check only one row selected in both columns combined
        Dim ctr As Integer = 0
        For x = 0 To DataGridView1.RowCount - 1
            If DataGridView1.Rows(x).Selected = True Then ctr += 1
        Next
        If DataGridView2.Visible = True Then
            For x = 0 To DataGridView2.RowCount - 1
                If DataGridView2.Rows(x).Selected = True Then ctr += 1
            Next
        End If
        If ctr > 1 Then MsgBox("Please select one and only one team to be moved up", MsgBoxStyle.OkOnly) : Exit Sub

        'move down unless moveup specified
        Dim unit As Integer = -1
        If strMoveType.ToUpper = "UP" Then unit = 1

        'process the change on the underlying datatable
        Dim dr As DataRow
        For x = 0 To DataGridView1.Rows.Count - 1
            If DataGridView1.Rows(x).Selected = True Then
                dr = dtG1.Rows.Find(DataGridView1.Rows(x).Cells("Competitor").Value)
                dr.Item("Bracket") = dr.Item("Bracket") + unit
                Call UpdateTeamBracket(dr.Item("Competitor"), dr.Item("Bracket"))
                Exit Sub
            End If
        Next
        For x = 0 To DataGridView2.RowCount - 1
            If DataGridView2.Rows(x).Selected = True Then
                dr = dtG2.Rows.Find(DataGridView2.Rows(x).Cells("Competitor").Value)
                dr.Item("Bracket") = dr.Item("Bracket") + unit
                Call UpdateTeamBracket(dr.Item("Competitor"), dr.Item("Bracket"))
                Exit Sub
            End If
        Next x
    End Sub

    Private Sub butMoveDown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butMoveDown.Click
        Call DoMove("Down")
    End Sub

    Private Sub butUpBracket_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butUpBracket.Click
        txtBracket.Text = Val(txtBracket.Text) + 1
        Call FilterByBracket()
        Call ClearCompetitorGrids()
    End Sub

    Private Sub butDownBracket_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butDownBracket.Click
        txtBracket.Text = Val(txtBracket.Text) - 1
        Call FilterByBracket()
        Call ClearCompetitorGrids()
    End Sub
    Sub UpdateTeamBracket(ByVal Team As Integer, ByVal WinBracket As Integer)
        Dim dr As DataRow() : Dim dr2 As DataRow
        dr = ds.Tables("Bracket").Select("Team=" & Team & " and round=" & cboRound.SelectedValue)
        If dr.Length = 1 Then
            dr(0).Item("WinBracket") = WinBracket
        ElseIf dr.Length = 0 Then
            dr2 = ds.Tables("Bracket").NewRow
            dr2.Item("Round") = cboRound.SelectedValue
            dr2.Item("Team") = Team
            dr2.Item("WinBracket") = WinBracket
            ds.Tables("Bracket").Rows.Add(dr2)
        End If
    End Sub
    Sub Grid1Click() Handles DataGridView1.Click
        If DataGridView2.Visible = True Then Call MarkTeamConflicts(DataGridView1, DataGridView2) : Exit Sub
        Call MarkTeamConflicts(DataGridView1, DataGridView1)
    End Sub
    Sub Grid2Click() Handles DataGridView2.Click
        Call MarkTeamConflicts(DataGridView2, DataGridView1)
        butPairTeams.Focus()
    End Sub
    Sub MarkTeamConflicts(ByVal dgv1 As DataGridView, ByVal dgv2 As DataGridView)
        Dim strTime As String : strTime = Now.Second & " " & Now.Millisecond & Chr(10) & Chr(10)
        'exit if no dg1 team selected
        If dgv1.CurrentRow Is Nothing Then Exit Sub
        Dim Team1 As Integer = dgv1.CurrentRow.Cells("Competitor").Value

        'clear first grid of red markings
        strTime &= "CLEAR GRID 1: " & Now.Second & " " & Now.Millisecond & Chr(10) & Chr(10)
        For x = 0 To dgv1.Rows.Count - 1
            If dgv1.Rows(x).Selected = False Then
                'mark conflicts as nothing
                If dgv1.Item(1, x).Style.BackColor = Color.Red Then dgv1.Item(1, x).Style.BackColor = Color.White
                're-mark if debating
                If dgv1.Rows(x).Cells("InRound").Value Is System.DBNull.Value Then dgv1.Rows(x).Cells("InRound").Value = False
                If dgv1.Rows(x).Cells("InRound").Value = True Then dgv1.Item(1, x).Style.BackColor = Color.LightBlue
            End If
        Next x

        'marks teams on opposite side that can't hear the selected team
        strTime &= "PROCESS GRID 2: " & Now.Second & " " & Now.Millisecond & Chr(10) & Chr(10)
        For x = 0 To dgv2.Rows.Count - 1
            dgv2.Item(1, x).Style.BackColor = Color.White
            If dgv2.Rows(x).Cells("InRound").Value Is System.DBNull.Value Then dgv2.Rows(x).Cells("InRound").Value = False
            If dgv2.Rows(x).Cells("InRound").Value = True Then dgv2.Item(1, x).Style.BackColor = Color.LightBlue
            If CanDebate(ds, Team1, dgv2.Rows(x).Cells("Competitor").Value) <> "" Then dgv2.Item(1, x).Style.BackColor = Color.Red
        Next x
        strTime &= "END: " & Now.Second & " " & Now.Millisecond
        'MsgBox(strTime)
    End Sub

    Private Sub butDeleteBracketDebates_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butDeleteBracketDebates.Click
        'Make sure that a bracket is displayed, otherwise, exit
        If txtBracket.Text.Trim = "" Then
            MsgBox("There does not appear to be a bracket displayed; if you want to delete and entire round use the button in the lower-left beneanth the pairings box.  Otherwise, load a bracket and try again.")
            Exit Sub
        End If
        'get a confirm
        Dim q As Integer = MsgBox("This will erase ALL the debates in this bracket that have been paired.  Click YES to continue and delete them, or NO to exit.", MsgBoxStyle.YesNo)
        If q = vbNo Then Exit Sub
        'scroll through all teams displayed in the grids, pull the panels for those teams in this round, and delete
        Dim dt As DataTable : Dim drPanel, drBallot As DataRow
        For x = 0 To DataGridView1.Rows.Count - 1
            dt = PullBallotsByRound(ds, "Entry", DataGridView1.Rows(x).Cells("Competitor").Value, cboRound.SelectedValue)
            For y = 0 To dt.Rows.Count - 1
                drBallot = ds.Tables("Ballot").Rows.Find(dt.Rows(y).Item(0))
                If Not drBallot Is Nothing Then
                    drPanel = ds.Tables("Panel").Rows.Find(drBallot.Item("Panel"))
                    If Not drPanel Is Nothing Then drPanel.Delete()
                End If
            Next y
        Next x
        'clean up screen
        ds.AcceptChanges()
        Call LoadPairings()
        Call ResetActives()
        Call ClearCompetitorGrids()
    End Sub

    Private Sub butAutoHighLow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butAutoHighLow.Click
        If DataGridView2.Visible = False Then Call OddPair("HL") : Exit Sub
        Call EvenPair(DataGridView2.Rows.Count - 1, 0, -1)
    End Sub
    Sub OddPair(ByVal strPairType As String)
        'auto pairs a round with no side constraints; only really works for 2-team systems
        Dim ctr, panel, intStart, intStop, intStep As Integer
        For x = 0 To DataGridView1.Rows.Count - 1
            If DataGridView1.Rows(x).Cells("InRound").Value = False Then
                ctr = 0
                If strPairType = "HH" Then intStart = x + 1 : intStop = DataGridView1.RowCount - 1 : intStep = 1
                If strPairType = "HL" Then intStart = DataGridView1.RowCount - 1 : intStop = x + 1 : intStep = -1
                For y = intStart To intStop Step intStep
                    If DataGridView1.Rows(y).Cells("InRound").Value = False Then
                        'check to see if it's time to exit and let the user fix it
                        ctr += 1
                        If ctr >= 3 Or (ctr > 1 And y = intStop) Then
                            MsgBox("There appears to be a problem that requires manual correction.  Please pair the next team in the affirmative bracket manually and continue.", MsgBoxStyle.OkOnly)
                            Call PostPairScreenReset()
                            Exit Sub
                        End If
                        'it's not, so see if you can pair.  If not, it scrolls to the next team
                        If CanDebate(ds, DataGridView1.Rows(x).Cells("Competitor").Value, DataGridView1.Rows(y).Cells("Competitor").Value) = "" Then
                            panel = AddPanel(ds, cboRound.SelectedValue)
                            AddTeamToPanel(ds, panel, DataGridView1.Rows(x).Cells("Competitor").Value, 1)
                            AddTeamToPanel(ds, panel, DataGridView1.Rows(y).Cells("Competitor").Value, 2)
                            DataGridView1.Rows(x).Cells("InRound").Value = True
                            DataGridView1.Rows(y).Cells("InRound").Value = True
                            Exit For
                        End If
                    End If
                    If y = intStop And DataGridView1.Rows(y).Cells("InRound").Value = False Then
                        MsgBox("There appears to be a problem that requires manual correction.  Please address it before pairing the next bracket.", MsgBoxStyle.OkOnly)
                    End If
                Next y
            End If
        Next x
        Call PostPairScreenReset()
    End Sub
    Sub EvenPair(ByVal intStart, ByVal intStop, ByVal intStep)
        Dim ctr, panel As Integer
        For x = 0 To DataGridView1.Rows.Count - 1
            If DataGridView1.Rows(x).Cells("InRound").Value = False Then
                ctr = 0
                For y = intStart To intStop Step intStep
                    If DataGridView2.Rows(y).Cells("InRound").Value = False Then
                        'check to see if it's time to exit and let the user fix it
                        ctr += 1
                        If ctr >= 3 Or (ctr > 1 And y = intStop) Then
                            MsgBox("There appears to be a problem that requires manual correction.  Please pair the next team in the affirmative bracket manually and continue.", MsgBoxStyle.OkOnly)
                            Call PostPairScreenReset()
                            Exit Sub
                        End If
                        'it's not, so see if you can pair.  If not, it scrolls to the next team
                        If CanDebate(ds, DataGridView1.Rows(x).Cells("Competitor").Value, DataGridView2.Rows(y).Cells("Competitor").Value) = "" Then
                            panel = AddPanel(ds, cboRound.SelectedValue)
                            AddTeamToPanel(ds, panel, DataGridView1.Rows(x).Cells("Competitor").Value, 1)
                            AddTeamToPanel(ds, panel, DataGridView2.Rows(y).Cells("Competitor").Value, 2)
                            DataGridView1.Rows(x).Cells("InRound").Value = True
                            DataGridView2.Rows(y).Cells("InRound").Value = True
                            Exit For
                        End If
                    End If
                    If y = intStop And DataGridView2.Rows(y).Cells("InRound").Value = False Then
                        MsgBox("There appears to be a problem that requires manual correction.  Please address it before pairing the next bracket.", MsgBoxStyle.OkOnly)
                    End If
                Next y
            End If
        Next x
        Call PostPairScreenReset()
    End Sub
    Sub PostPairScreenReset()
        'reset screen
        Call LoadPairings()
        Call ResetActives()
        If chkPairedToBottom.Checked = True Then
            DataGridView1.Sort(DataGridView1.Columns("InROund"), System.ComponentModel.ListSortDirection.Ascending)
            DataGridView2.Sort(DataGridView2.Columns("InROund"), System.ComponentModel.ListSortDirection.Ascending)
        End If
        Call ClearCompetitorGrids()
    End Sub

    Private Sub butPairHighHigh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butPairHighHigh.Click
        If DataGridView2.Visible = False Then
            'check that all teams are dumped in one big bracket
            Call OddPair("HH") : Exit Sub
        End If
        'check that there are an even number of teams
        Call EvenPair(0, DataGridView2.Rows.Count - 1, 1)
    End Sub
End Class