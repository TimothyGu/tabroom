﻿'STILL TO DO ON THIS PAGE
'Get the validation thing in order; 
'Allow to place judges even if all teams aren't present

Public Class frmShowPairings
    Dim ds As New DataSet
    Dim EditMode As String
    Dim dtTeams As DataTable

    Private Sub frmShowPairings_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Load
        LoadFile(ds, "TourneyData")
        Call CalcPrefAverages(ds)
        Call LoadJudgeSettings()

        'bind round CBO
        cboRound.DataSource = ds.Tables("Round")
        cboRound.DisplayMember = "Label"
        cboRound.ValueMember = "ID"

    End Sub
    Private Sub frmShowPairings_Unload(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Disposed
        'save file on page close
        Call SaveFile(ds)
        ds.Dispose()
    End Sub

    Private Sub butLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butLoad.Click
        Call ShowThePairing()
        Call LoadTeamTable()
    End Sub
    Sub LoadTeamTable()
        dtTeams = New DataTable
        dtTeams = MakeTBTable(ds, cboRound.SelectedValue, "TEAM", "FULLNAME")
        'if it's not a preset, all the tiebreakers will be there.  Delete all but the first 2 tiebreakers
        If dtTeams.Columns.Count > 3 Then
            For x = dtTeams.Columns.Count - 1 To 5 Step -1
                dtTeams.Columns.Remove(x)
            Next
        End If
        'Add debatingnow column
        dtTeams.Columns.Add("DebatingNow", System.Type.GetType("System.Boolean"))
        dtTeams.Columns.Add("Sides", System.Type.GetType("System.String"))
        dtTeams.DefaultView.Sort = "DebatingNow ASC, seed asc"
        dtTeams.AcceptChanges()
        Call MarkTeamInAction()
        Call AddSideValues()
    End Sub
    Sub AddSideValues()
        If cboRound.SelectedIndex = -1 Then
            MsgBox("Please select a round and try again.", MsgBoxStyle.OkOnly) : Exit Sub
        End If
        Dim drRd As DataRow
        drRd = ds.Tables("Round").Rows.Find(cboRound.SelectedValue)
        If getEventSetting(ds, drRd.Item("Event"), "TeamsPerRound") = 2 Then
            For x = 0 To dtTeams.Rows.Count - 1
                dtTeams.Rows(x).Item("Sides") = GetSideString(ds, GetSideDue(ds, cboRound.SelectedValue, dtTeams.Rows(x).Item("Competitor")), drRd.Item("Event"))
            Next
        Else
            Call AddSideReport(dtTeams, ds)
        End If

    End Sub
    Sub ShowThePairing()
        Call modShowThePairing(ds, DataGridView1, cboRound.SelectedValue)
        Call AddPrefColumns()
        If chkJudgeUse.Checked = True Then Call AddJudgeUseColumn()
        Call MarkBlanks()
    End Sub
    Sub AddJudgeUseColumn()
        'Creates a column for each judge that shows their use status
        'add a column for each judge
        Dim dt As New DataTable
        dt = DataGridView1.DataSource
        Dim drJudge, drRound As DataRow : Dim JudgedAlready As Integer
        drRound = ds.Tables("Round").Rows.Find(cboRound.SelectedValue)
        For x = 1 To drRound.Item("JudgesPerPanel")
            dt.Columns.Add("JudgeUse" & x, System.Type.GetType("System.String"))
        Next x
        'populate the columns
        For z = 0 To dt.Rows.Count - 1
            For x = 1 To drRound.Item("JudgesPerPanel")
                drJudge = ds.Tables("Judge").Rows.Find(dt.Rows(z).Item("Judge" & x))
                If drJudge Is Nothing Then
                    dt.Rows(z).Item("JudgeUse" & x) = "- - -"
                Else
                    JudgedAlready = GetRoundsJudged(ds, drJudge.Item("ID"))
                    dt.Rows(z).Item("JudgeUse" & x) = drJudge.Item("Obligation") + drJudge.Item("Hired") - JudgedAlready & "/" & JudgedAlready & "/" & drJudge.Item("Obligation") + drJudge.Item("Hired")
                End If
            Next x
        Next z
    End Sub
    Sub AddPrefColumns()
        'see if prefs are in use this round, exit if not
        Dim drRound As DataRow
        drRound = ds.Tables("Round").Rows.Find(cboRound.SelectedValue)
        If drRound.Item("JudgePlaceScheme") <> "TeamRating" Then Exit Sub
        'if so, show the balance and inidividual ratings in one column
        Dim dt As New DataTable
        dt = DataGridView1.DataSource
        dt.Columns.Add("Balance", System.Type.GetType("System.String"))

        Dim nTeams, nJudges As Integer
        nTeams = getEventSetting(ds, drRound.Item("Event"), "TeamsPerRound")
        nJudges = drRound.Item("JudgesPerPanel")
        Dim ratings(nTeams) As Integer : Dim Balance As Integer
        For z = 0 To dt.Rows.Count - 1
            'reset counter variables
            Balance = 0
            For x = 0 To nTeams : ratings(x) = 0 : Next x
            'get the rating for each judge and each team
            For x = 1 To nTeams
                For y = 1 To nJudges
                    ratings(x) += GetJudgeRating(ds, dt.Rows(z).Item("Judge" & y), dt.Rows(z).Item("Team" & x), "ORDPCT")
                Next y
            Next x
            'sum for the balance & add to grid
            For x = 1 To nTeams - 1
                For y = x + 1 To nTeams
                    Balance += Math.Abs(ratings(x) - ratings(y))
                Next y
            Next x
            dt.Rows(z).Item("Balance") = Balance & " "
            'add ratings
            For x = 1 To nTeams
                dt.Rows(z).Item("Balance") &= ratings(x)
                If x <> nTeams Then dt.Rows(z).Item("Balance") &= "-"
            Next x
        Next z
    End Sub
    Sub MarkBlanks()
        Dim SkipCol As Boolean
        'mark blank entries
        For x = 0 To DataGridView1.RowCount - 2
            DataGridView1.Rows(x).Selected = False
            For y = 1 To DataGridView1.ColumnCount - 1
                SkipCol = False
                If DataGridView1.Columns(y).Name = "Balance" Then SkipCol = True
                If DataGridView1.Columns(y).Name = "ROOMNAME" Then SkipCol = True
                If InStr(DataGridView1.Columns(y).Name.ToUpper, "JUDGEUSE") > 0 Then SkipCol = True
                If DataGridView1.Columns(y).Visible = True And SkipCol = False Then
                    If DataGridView1.Rows(x).Cells(y - 1).Value = -99 Then DataGridView1.Item(y, x).Style.BackColor = Color.Red
                ElseIf DataGridView1.Columns(y).Name = "ROOMNAME" Then
                    If DataGridView1.Rows(x).Cells("Room").Value Is System.DBNull.Value Then DataGridView1.Item(y, x).Style.BackColor = Color.Red
                End If
            Next y
        Next x
    End Sub
    Private Sub Grid1Clicked() Handles DataGridView1.MouseClick
        grpJudgeSettings.Visible = False
        If DataGridView1.DataSource Is Nothing Then Exit Sub
        If InStr(DataGridView1.Columns(DataGridView1.CurrentCell.ColumnIndex).Name.ToUpper, "JUDGE") > 0 Then
            EditMode = "Judge"
            DataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing
            Call LoadJudges()
            grpJudgeSettings.Visible = True
        ElseIf InStr(DataGridView1.Columns(DataGridView1.CurrentCell.ColumnIndex).Name.ToUpper, "TEAM") > 0 Then
            DataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
            EditMode = "Team"
            Call LoadTeams()
        ElseIf InStr(DataGridView1.Columns(DataGridView1.CurrentCell.ColumnIndex).Name.ToUpper, "ROOM") > 0 Then
            EditMode = "Room"
            DataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
            Call LoadRooms()
        End If
    End Sub
    Sub LoadJudges()
        Dim str As String = ""
        str &= "Start: " & Now.Second & " " & Now.Millisecond & Chr(10) & Chr(10)

        Dim drRd, drEvent As DataRow
        drRd = ds.Tables("Round").Rows.Find(cboRound.SelectedValue)
        If drRd Is Nothing Then MsgBox("The round appears invalid; select a valid round and try again.", MsgBoxStyle.OkOnly) : Exit Sub
        drEvent = ds.Tables("Event").Rows.Find(drRd.Item("Event"))
        Dim TeamsPerRound As Integer = getEventSetting(ds, drEvent.Item("ID"), "TeamsPerRound")

        Dim dt As New DataTable
        dt.Columns.Add("ID", System.Type.GetType("System.Int64"))
        dt.Columns.Add("Name", System.Type.GetType("System.String"))
        dt.Columns.Add("Left", System.Type.GetType("System.Int16"))
        dt.Columns.Add("Pref", System.Type.GetType("System.Int16"))
        dt.Columns.Add("Mutuality", System.Type.GetType("System.Int16"))
        dt.Columns.Add("AvgPref", System.Type.GetType("System.Int16"))
        dt.Columns.Add("Assigned", System.Type.GetType("System.Boolean"))
        dt.Columns.Add("FitsCriteria", System.Type.GetType("System.Boolean"))
        For x = 1 To TeamsPerRound
            dt.Columns.Add("Rating" & x, System.Type.GetType("System.Int16"))
        Next
        dt.Columns.Add("Owed", System.Type.GetType("System.Int16"))
        dt.Columns.Add("Judged", System.Type.GetType("System.Int16"))

        Dim dr2 As DataRow
        For x = 0 To ds.Tables("Judge").Rows.Count - 1
            dr2 = dt.NewRow
            dr2.Item("ID") = ds.Tables("Judge").Rows(x).Item("ID")
            dr2.Item("Name") = ds.Tables("Judge").Rows(x).Item("Last").trim & ", " & ds.Tables("Judge").Rows(x).Item("First").trim
            dr2.Item("Owed") = ds.Tables("Judge").Rows(x).Item("Obligation") + ds.Tables("Judge").Rows(x).Item("Hired")
            dr2.Item("Judged") = GetRoundsJudged(ds, ds.Tables("Judge").Rows(x).Item("ID"))
            dr2.Item("Left") = dr2.Item("Owed") - dr2.Item("Judged")
            dr2.Item("AvgPref") = ds.Tables("Judge").Rows(x).Item("AvgPref")
            dr2.Item("Assigned") = ActiveInTimeSlot(ds, ds.Tables("Judge").Rows(x).Item("ID"), cboRound.SelectedValue, "Judge")
            For y = 1 To TeamsPerRound
                dr2.Item("Rating" & y) = GetJudgeRating(ds, ds.Tables("Judge").Rows(x).Item("ID"), DataGridView1.CurrentRow.Cells("Team" & y).Value, "ORDPCT")
            Next y
            dr2.Item("Pref") = dr2.Item("Rating2")
            If dr2.Item("Rating1") > dr2.Item("rating2") Then dr2.Item("Pref") = dr2.Item("Rating1")
            dr2.Item("Mutuality") = Math.Abs(dr2.Item("Rating1") - dr2.Item("Rating2"))
            dr2.Item("FitsCriteria") = True
            If dr2.Item("Pref") > DataGridView3.Rows(0).Cells(1).Value Then dr2.Item("FitsCriteria") = False
            If dr2.Item("Mutuality") > DataGridView3.Rows(1).Cells(1).Value Then dr2.Item("FitsCriteria") = False
            dt.Rows.Add(dr2)
        Next

        DataGridView2.Columns.Clear()
        dt.DefaultView.Sort = "Assigned, FitsCriteria desc, Left desc, Pref"
        DataGridView2.AutoGenerateColumns = True
        DataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader
        DataGridView2.DataSource = dt
        DataGridView2.Columns("ID").Visible = False

        Call MarkJudgeEligibility()
        DataGridView2.CurrentCell = Nothing

        str &= "End Loop: " & Now.Second & " " & Now.Millisecond & Chr(10) & Chr(10)
        'MsgBox(str)

    End Sub
    Sub MarkJudgeEligibility()
        Dim x As Integer
        For x = 0 To DataGridView2.RowCount - 1
            If ActiveInTimeSlot(ds, DataGridView2.Rows(x).Cells("ID").Value, cboRound.SelectedValue, "Judge") = True Then
                DataGridView2.Rows(x).DefaultCellStyle.BackColor = Color.LightBlue
            End If
            If JudgeSameSchool(ds, DataGridView2.Rows(x).Cells("ID").Value, DataGridView1.CurrentRow.Cells("Panel").Value) = True Then
                DataGridView2.Rows(x).DefaultCellStyle.BackColor = Color.Red
            End If
        Next
    End Sub
    Sub MarkTeamInAction()
        For x = 0 To dtTeams.Rows.Count - 1
            If ActiveInTimeSlot(ds, dtTeams.Rows(x).Item("Competitor"), cboRound.SelectedValue, "ENTRY") = True Then
                dtTeams.Rows(x).Item("DebatingNow") = True
            Else
                dtTeams.Rows(x).Item("DebatingNow") = False
            End If
        Next x
    End Sub
    Sub ColorTeamsInAction()
        For x = 0 To DataGridView2.RowCount - 1
            DataGridView2.Rows(x).DefaultCellStyle.BackColor = Color.White
            If DataGridView2.Rows(x).Cells("DebatingNow").Value = False Then
                DataGridView2.Rows(x).DefaultCellStyle.BackColor = Color.LightBlue
            End If
        Next
    End Sub
    Sub LoadTeams()
        'update underlying datatable
        Call MarkTeamInAction()
        'datagrid view settings
        dtTeams.DefaultView.Sort = "DebatingNow asc, seed asc"
        DataGridView2.AutoGenerateColumns = True
        DataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        DataGridView2.DataSource = dtTeams
        DataGridView2.Columns("CompetitorName").AutoSizeMode = DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader
        DataGridView2.Columns("Competitor").Visible = False
        DataGridView2.Columns("DebatingNow").HeaderText = "Debating Now"
        DataGridView2.Columns("CompetitorName").HeaderText = "Team name"
        'customize the sides column header
        Dim drRd As DataRow : drRd = ds.Tables("Round").Rows.Find(cboRound.SelectedValue)
        If getEventSetting(ds, drRd.Item("Event"), "TeamsPerRound") = 2 Then
            DataGridView2.Columns("Sides").HeaderText = "Side due"
        Else
            DataGridView2.Columns("Sides").HeaderText = "Side report"
        End If
        'repaint to mark whether they have been assigned
        Call ColorTeamsInAction()
        'clear the grid so nothing is selected
        DataGridView2.CurrentCell = Nothing
        DataGridView2.Rows(0).Selected = False
    End Sub
    Sub LoadRooms()

        DataGridView2.Columns.Clear()

        Dim dgvc As New DataGridViewTextBoxColumn
        dgvc.Name = "ID"
        dgvc.DataPropertyName = "ID"
        DataGridView2.Columns.Add(dgvc)
        DataGridView2.Columns(0).Visible = False

        dgvc = New DataGridViewTextBoxColumn
        dgvc.Name = "Name" : dgvc.DataPropertyName = "Name" : dgvc.HeaderText = "Name"
        DataGridView2.Columns.Add(dgvc)

        dgvc = New DataGridViewTextBoxColumn
        dgvc.Name = "Quality" : dgvc.DataPropertyName = "Quality" : dgvc.HeaderText = "Quality"
        DataGridView2.Columns.Add(dgvc)

        dgvc = New DataGridViewTextBoxColumn
        dgvc.Name = "Capacity" : dgvc.DataPropertyName = "Capacity" : dgvc.HeaderText = "Capacity"
        DataGridView2.Columns.Add(dgvc)

        Dim dgvc2 As New DataGridViewCheckBoxColumn
        dgvc2.Name = "Inactive" : dgvc2.DataPropertyName = "Inactive" : dgvc2.HeaderText = "Inactive"
        DataGridView2.Columns.Add(dgvc2)

        Dim drRound As DataRow
        drRound = ds.Tables("Round").Rows.Find(cboRound.SelectedValue)

        dgvc2 = New DataGridViewCheckBoxColumn
        dgvc2.Name = "DivisionAvailable" : dgvc2.DataPropertyName = "DivisionAvailable" : dgvc2.HeaderText = "Division Available"
        DataGridView2.Columns.Add(dgvc2)

        dgvc2 = New DataGridViewCheckBoxColumn
        dgvc2.Name = "TimeAvailable" : dgvc2.DataPropertyName = "TimeAvailable" : dgvc2.HeaderText = "Time Available"
        DataGridView2.Columns.Add(dgvc2)

        dgvc2 = New DataGridViewCheckBoxColumn
        dgvc2.Name = "InUse" : dgvc2.DataPropertyName = "InUse" : dgvc2.HeaderText = "In Use"
        DataGridView2.Columns.Add(dgvc2)

        DataGridView2.AutoGenerateColumns = False
        DataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        DataGridView2.Columns("Name").AutoSizeMode = DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader

        Dim dt As New DataTable
        dt.Columns.Add("ID", System.Type.GetType("System.Int64"))
        dt.Columns.Add("Name", System.Type.GetType("System.String"))
        dt.Columns.Add("Quality", System.Type.GetType("System.Int16"))
        dt.Columns.Add("Capacity", System.Type.GetType("System.Int16"))
        dt.Columns.Add("Inactive", System.Type.GetType("System.Boolean"))
        dt.Columns.Add("DivisionAvailable", System.Type.GetType("System.Boolean"))
        dt.Columns.Add("TimeAvailable", System.Type.GetType("System.Boolean"))
        dt.Columns.Add("InUse", System.Type.GetType("System.Boolean"))
        
        Dim dr2 As DataRow
        For x = 0 To ds.Tables("Room").Rows.Count - 1
            dr2 = dt.NewRow
            dr2.Item("ID") = ds.Tables("Room").Rows(x).Item("ID")
            dr2.Item("Name") = ds.Tables("Room").Rows(x).Item("Name")
            dr2.Item("Quality") = ds.Tables("Room").Rows(x).Item("Quality")
            dr2.Item("Capacity") = ds.Tables("Room").Rows(x).Item("Capacity")
            dr2.Item("Inactive") = ds.Tables("Room").Rows(x).Item("Inactive")
            dr2.Item("DivisionAvailable") = ds.Tables("Room").Rows(x).Item("Event" & drRound.Item("Event"))
            dr2.Item("TimeAvailable") = ds.Tables("Room").Rows(x).Item("TimeSlot" & drRound.Item("TimeSlot"))
            dr2.Item("InUse") = RoomActiveInTimeSlot(ds, ds.Tables("Room").Rows(x).Item("ID"), drRound.Item("ID"))
            dt.Rows.Add(dr2)
        Next

        dt.DefaultView.Sort = "Inuse asc, inactive asc, divisionavailable desc, timeavailable desc, quality asc, name asc"
        DataGridView2.DataSource = dt
        DataGridView2.CurrentCell = Nothing
        Call MarkRoomsInUse()

    End Sub
    Sub MarkRoomsInUse()
        Dim markit As Boolean
        For x = 0 To DataGridView2.RowCount - 1
            markit = False
            If DataGridView2.Rows(x).Cells("InUse").Value = True Then markit = True
            If DataGridView2.Rows(x).Cells("Inactive").Value = True Then markit = True
            If DataGridView2.Rows(x).Cells("DivisionAvailable").Value = False Then markit = True
            If DataGridView2.Rows(x).Cells("TimeAvailable").Value = False Then markit = True
            If markit = True Then DataGridView2.Rows(x).DefaultCellStyle.BackColor = Color.Red
        Next
    End Sub
    Private Sub butDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butDelete.Click
        Call Deleter()
        'load grid 2
        If EditMode = "Judge" Then Call LoadJudges()
        If EditMode = "Team" Then Call LoadTeams()
        'load grid 1
        Call ShowThePairing()
    End Sub
    Sub Deleter()
        'Find the judge or team ID to delete
        Dim DeleteId As Integer = DataGridView1.CurrentRow.Cells(DataGridView1.CurrentCell.ColumnIndex - 1).Value
        'FIRST, MAKE THE CHANGE TO THE MASTER DATASET
        Dim DT As DataTable
        Dim dr As DataRow
        If EditMode = "Judge" Then
            DT = PullBallotsByRound(ds.Copy, "JUDGE", DeleteId, cboRound.SelectedValue)
            For x = 0 To DT.Rows.Count - 1
                dr = ds.Tables("Ballot").Rows.Find(DT.Rows(x).Item("ID"))
                dr.Item("Judge") = -99
            Next
        End If
        If EditMode = "Team" Then
            DT = PullBallotsByRound(ds.Copy, "ENTRY", DeleteId, cboRound.SelectedValue)
            For x = 0 To DT.Rows.Count - 1
                dr = ds.Tables("Ballot").Rows.Find(DT.Rows(x).Item("ID"))
                dr.Item("Entry") = -99
            Next
        End If
        If EditMode = "Room" Then
            dr = ds.Tables("Panel").Rows.Find(DataGridView1.CurrentRow.Cells("Panel").Value)
            dr.Item("Room") = System.DBNull.Value
        End If
    End Sub
    Private Sub butAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butAdd.Click
        'check that one and only one cell on the pairing has been clicked
        'check that one row on the add grid has been clicked
        If EditMode = "Team" Then
            If DataGridView2.CurrentRow.Cells("DebatingNow").Value Is System.DBNull.Value Then DataGridView2.CurrentRow.Cells("DebatingNow").Value = False
            If DataGridView2.CurrentRow.Cells("DebatingNow").Value = True Then
                Label1.Text = "That team is already scheduled to debate in this time slot.  Please select a differen team and try again."
                Exit Sub
            End If
        End If
        Dim dummy As String = "OK"
        'get the panel
        Dim panel As Integer = DataGridView1.CurrentRow.Cells("Panel").Value
        'validate panel first; if poorly structured show error
        dummy = ValidatePanel(ds, panel)
        If dummy <> "OK" Then
            Label1.Text = "Change NOT made..." & dummy
            Exit Sub
        End If
        If EditMode = "Judge" Then dummy = AddJudgeToPanel(ds, panel, DataGridView2.CurrentRow.Cells("ID").Value)
        If EditMode = "Team" Then dummy = AddTeamToPanel(ds, panel, DataGridView2.CurrentRow.Cells("Competitor").Value, GetSide)
        If EditMode = "Room" Then dummy = AddRoomToPanel(ds, panel, DataGridView2.CurrentRow.Cells("ID").Value)
        If dummy <> "OK" Then
            Label1.Text = "Change NOT made..." & dummy
            Exit Sub
        End If
        Call ShowThePairing()
        If EditMode = "Judge" Then Call LoadJudges()
        If EditMode = "Team" Then Call LoadTeams()
        If EditMode = "Room" Then Call LoadRooms()
        Label1.Text = "Changes completed."
    End Sub
    Function GetSide() As Integer
        Dim str As String = DataGridView1.Columns(DataGridView1.CurrentCell.ColumnIndex).Name
        str = Mid(str, str.Length, 1)
        Return Val(str)
    End Function
    Private Sub butDeleteRow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butDeleteRow.Click
        Dim Panel As Integer = DataGridView1.CurrentRow.Cells("Panel").Value
        Dim drPanel As DataRow
        drPanel = ds.Tables("Panel").Rows.Find(Panel)
        drPanel.Delete()
        If EditMode = "Judge" Then Call LoadJudges()
        If EditMode = "Team" Then Call LoadTeams()
        Call ShowThePairing()
    End Sub
    Sub dg2Sorted() Handles DataGridView2.Sorted
        If EditMode = "Judge" Then MarkJudgeEligibility()
        If EditMode = "Team" Then ColorTeamsInAction()
        If EditMode = "Room" Then MarkRoomsInUse()
    End Sub
    Sub dg1Sorted() Handles DataGridView1.Sorted
        Call MarkBlanks()
    End Sub

    Private Sub butAddPanel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butAddPanel.Click
        Call AddPanel(ds, cboRound.SelectedValue)
        Call ShowThePairing()
        If EditMode = "Judge" Then Call LoadJudges()
        If EditMode = "Team" Then Call LoadTeams()
    End Sub
    Private Sub datagridview2_CellPainting(ByVal sender As Object, ByVal e As DataGridViewCellPaintingEventArgs) Handles DataGridView2.CellPainting
        If ((e.RowIndex = -1) AndAlso (e.ColumnIndex >= 2)) AndAlso EditMode = "Judge" Then
            e.PaintBackground(e.ClipBounds, True)
            Dim rect As Rectangle = Me.DataGridView2.GetColumnDisplayRectangle(e.ColumnIndex, True)
            Dim titleSize As Size = TextRenderer.MeasureText(e.Value.ToString, e.CellStyle.Font)
            If (Me.DataGridView2.ColumnHeadersHeight < titleSize.Width) Then
                Me.DataGridView2.ColumnHeadersHeight = titleSize.Width
            End If
            e.Graphics.TranslateTransform(0, titleSize.Width)
            e.Graphics.RotateTransform(-90.0!)
            e.Graphics.DrawString(e.Value.ToString, Me.Font, Brushes.Black, New PointF(rect.Y, rect.X))
            e.Graphics.RotateTransform(90.0!)
            e.Graphics.TranslateTransform(0, (titleSize.Width * -1))
            DataGridView2.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
            e.Handled = True
        End If
    End Sub
    Sub LoadJudgeSettings()
        Dim dt As New DataTable
        dt.Columns.Add("Criteria", System.Type.GetType("System.String"))
        dt.Columns.Add("Value", System.Type.GetType("System.Int16"))
        Dim dr As DataRow
        dr = dt.NewRow : dr.Item("Criteria") = "Max Pref" : dr.Item("Value") = 50 : dt.Rows.Add(dr)
        dr = dt.NewRow : dr.Item("Criteria") = "Max Mutuality" : dr.Item("Value") = 30 : dt.Rows.Add(dr)
        DataGridView3.DataSource = dt
    End Sub
    Sub ReLoadJudges() Handles DataGridView3.CellEndEdit
        Call LoadJudges()
    End Sub
End Class
