﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSTAJudgePlacement
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.LabelMultiJudgePrefWeight = New System.Windows.Forms.Label
        Me.LabelMultiPanelDiffWeight = New System.Windows.Forms.Label
        Me.LabelMultiIndivDiffWeight = New System.Windows.Forms.Label
        Me.dgFinishStats = New System.Windows.Forms.DataGrid
        Me.LabelMultiPanelPrefWeight = New System.Windows.Forms.Label
        Me.LabelMultiIndivPrefWeight = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.TextBoxPanelPrefWeight = New System.Windows.Forms.TextBox
        Me.Label33 = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.LabelJudgesObliged = New System.Windows.Forms.Label
        Me.LabelJudgesAvailable = New System.Windows.Forms.Label
        Me.LabLostJudgesNEW = New System.Windows.Forms.Label
        Me.Label41 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.TextBoxMaxPanelDiffAbove = New System.Windows.Forms.TextBox
        Me.TextBoxMaxPanelDiffBREAK = New System.Windows.Forms.TextBox
        Me.GroupBoxMultiTest = New System.Windows.Forms.GroupBox
        Me.Label40 = New System.Windows.Forms.Label
        Me.Label39 = New System.Windows.Forms.Label
        Me.ButtonMultiTestBegin = New System.Windows.Forms.Button
        Me.Label38 = New System.Windows.Forms.Label
        Me.Label37 = New System.Windows.Forms.Label
        Me.Label36 = New System.Windows.Forms.Label
        Me.Label35 = New System.Windows.Forms.Label
        Me.Label34 = New System.Windows.Forms.Label
        Me.TextBoxMinIndivPrefWeight = New System.Windows.Forms.TextBox
        Me.TextBoxMaxIndivPrefWeight = New System.Windows.Forms.TextBox
        Me.TextBoxIncIndivPrefWeight = New System.Windows.Forms.TextBox
        Me.TextBoxMinPanelPrefWeight = New System.Windows.Forms.TextBox
        Me.TextBoxMaxPanelPrefWeight = New System.Windows.Forms.TextBox
        Me.TextBoxIncPanelPrefWeight = New System.Windows.Forms.TextBox
        Me.TextBoxIncIndivDiffWeight = New System.Windows.Forms.TextBox
        Me.TextBoxIncPanelDiffWeight = New System.Windows.Forms.TextBox
        Me.TextBoxMaxIndivDiffWeight = New System.Windows.Forms.TextBox
        Me.TextBoxMaxPanelDiffWeight = New System.Windows.Forms.TextBox
        Me.TextBoxMaxJudgePrefWeight = New System.Windows.Forms.TextBox
        Me.TextBoxMinPanelDiffWeight = New System.Windows.Forms.TextBox
        Me.TextBoxMinINdivDiffWeight = New System.Windows.Forms.TextBox
        Me.ButtonMultiTest = New System.Windows.Forms.Button
        Me.ButtonRemoveJudges = New System.Windows.Forms.Button
        Me.ButtonRecordJudges = New System.Windows.Forms.Button
        Me.ButtonAssignJudges = New System.Windows.Forms.Button
        Me.LabelInstructions = New System.Windows.Forms.Label
        Me.LabBreakPoint = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.CheckBoxJudgeAgain = New System.Windows.Forms.CheckBox
        Me.TextBoxPanelSize = New System.Windows.Forms.TextBox
        Me.TextBoxBreakPoint = New System.Windows.Forms.TextBox
        Me.Label27 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.TextBoxNumCohorts = New System.Windows.Forms.TextBox
        Me.TextBoxMaxPanelDiffBelow = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.TextBoxMaxIndivDiffBelow = New System.Windows.Forms.TextBox
        Me.TextBoxMaxIndivDiffAbove = New System.Windows.Forms.TextBox
        Me.TextBoxMaxIndivDiffBREAK = New System.Windows.Forms.TextBox
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.LabJudgePrefBefore = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        Me.Label31 = New System.Windows.Forms.Label
        Me.TextBoxJudgePrefWeight = New System.Windows.Forms.TextBox
        Me.TextBoxIndivDiffWeight = New System.Windows.Forms.TextBox
        Me.TextBoxPanelDiffWeight = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.TextBoxIndivPrefWeight = New System.Windows.Forms.TextBox
        Me.TextBoxMaxLostRounds = New System.Windows.Forms.TextBox
        Me.LabJudgePrefAfterNEW = New System.Windows.Forms.Label
        Me.LabJudgePrefAfter = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.LabLostJudges = New System.Windows.Forms.Label
        Me.LabPanelDiffAvgBreak = New System.Windows.Forms.Label
        Me.LabPanelDiffAvgBelow = New System.Windows.Forms.Label
        Me.LabPanelDiffAvgAll = New System.Windows.Forms.Label
        Me.LabIndivDiffAvgAbove = New System.Windows.Forms.Label
        Me.LabIndivDiffAvgBreak = New System.Windows.Forms.Label
        Me.labIndivAvgBelow = New System.Windows.Forms.Label
        Me.labIndivAvgBreak = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.LabIndivDiffAvgBelow = New System.Windows.Forms.Label
        Me.LabIndivDiffAvgAll = New System.Windows.Forms.Label
        Me.LabPanelDiffAvgAbove = New System.Windows.Forms.Label
        Me.LabWorstPanelBelowNEW = New System.Windows.Forms.Label
        Me.labIndivAvgAbove = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.LabWorstPanelBelow = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.chkUseRatings = New System.Windows.Forms.CheckBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.LabWorstBelow = New System.Windows.Forms.Label
        Me.TextBoxTargetAbove = New System.Windows.Forms.TextBox
        Me.TextBoxTargetBREAK = New System.Windows.Forms.TextBox
        Me.LabWorstAbove = New System.Windows.Forms.Label
        Me.TextBoxTargetBelow = New System.Windows.Forms.TextBox
        Me.LabWorstBREAK = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.labIndivDiffAvgAllNEW = New System.Windows.Forms.Label
        Me.LabWorstPanelBreakNEW = New System.Windows.Forms.Label
        Me.LabWorstPanelAboveNEW = New System.Windows.Forms.Label
        Me.LabWorstBelowNEW = New System.Windows.Forms.Label
        Me.LabWorstBreakNEW = New System.Windows.Forms.Label
        Me.LabWorstAboveNEW = New System.Windows.Forms.Label
        Me.LabIndivAvgBreakNEW = New System.Windows.Forms.Label
        Me.LabIndivAvgBelowNEW = New System.Windows.Forms.Label
        Me.LabIndivAvgAllNEW = New System.Windows.Forms.Label
        Me.LabIndivAvgAboveNEW = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.LabWorstPanelBREAK = New System.Windows.Forms.Label
        Me.LabWorstPanelAbove = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.labPanelDiffAvgAllNEW = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.labPanelDiffAvgBelowNEW = New System.Windows.Forms.Label
        Me.LabElapsedTime = New System.Windows.Forms.Label
        Me.labPanelDiffAvgBreakNEW = New System.Windows.Forms.Label
        Me.labIndivDiffAvgBreakNEW = New System.Windows.Forms.Label
        Me.labPanelDiffAvgAboveNEW = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.labIndivAvgALL = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.labIndivDiffAvgBelowNEW = New System.Windows.Forms.Label
        Me.MPJDiagnostics = New System.Windows.Forms.GroupBox
        Me.labIndivDiffAvgAboveNEW = New System.Windows.Forms.Label
        Me.cboRound = New System.Windows.Forms.ComboBox
        Me.dgvDTTab = New System.Windows.Forms.DataGridView
        Me.butBasicInfo = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        CType(Me.dgFinishStats, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBoxMultiTest.SuspendLayout()
        Me.MPJDiagnostics.SuspendLayout()
        CType(Me.dgvDTTab, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LabelMultiJudgePrefWeight
        '
        Me.LabelMultiJudgePrefWeight.AutoSize = True
        Me.LabelMultiJudgePrefWeight.Location = New System.Drawing.Point(428, 554)
        Me.LabelMultiJudgePrefWeight.Name = "LabelMultiJudgePrefWeight"
        Me.LabelMultiJudgePrefWeight.Size = New System.Drawing.Size(32, 13)
        Me.LabelMultiJudgePrefWeight.TabIndex = 446
        Me.LabelMultiJudgePrefWeight.Text = "1.00"
        '
        'LabelMultiPanelDiffWeight
        '
        Me.LabelMultiPanelDiffWeight.AutoSize = True
        Me.LabelMultiPanelDiffWeight.Location = New System.Drawing.Point(428, 415)
        Me.LabelMultiPanelDiffWeight.Name = "LabelMultiPanelDiffWeight"
        Me.LabelMultiPanelDiffWeight.Size = New System.Drawing.Size(32, 13)
        Me.LabelMultiPanelDiffWeight.TabIndex = 445
        Me.LabelMultiPanelDiffWeight.Text = "1.00"
        '
        'LabelMultiIndivDiffWeight
        '
        Me.LabelMultiIndivDiffWeight.AutoSize = True
        Me.LabelMultiIndivDiffWeight.Location = New System.Drawing.Point(428, 323)
        Me.LabelMultiIndivDiffWeight.Name = "LabelMultiIndivDiffWeight"
        Me.LabelMultiIndivDiffWeight.Size = New System.Drawing.Size(32, 13)
        Me.LabelMultiIndivDiffWeight.TabIndex = 444
        Me.LabelMultiIndivDiffWeight.Text = "1.00"
        '
        'dgFinishStats
        '
        Me.dgFinishStats.CaptionText = "Rounds of judging need and remaining"
        Me.dgFinishStats.DataMember = ""
        Me.dgFinishStats.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgFinishStats.Location = New System.Drawing.Point(932, 338)
        Me.dgFinishStats.Name = "dgFinishStats"
        Me.dgFinishStats.PreferredColumnWidth = 60
        Me.dgFinishStats.Size = New System.Drawing.Size(326, 203)
        Me.dgFinishStats.TabIndex = 472
        '
        'LabelMultiPanelPrefWeight
        '
        Me.LabelMultiPanelPrefWeight.AutoSize = True
        Me.LabelMultiPanelPrefWeight.Location = New System.Drawing.Point(428, 83)
        Me.LabelMultiPanelPrefWeight.Name = "LabelMultiPanelPrefWeight"
        Me.LabelMultiPanelPrefWeight.Size = New System.Drawing.Size(32, 13)
        Me.LabelMultiPanelPrefWeight.TabIndex = 443
        Me.LabelMultiPanelPrefWeight.Text = "1.00"
        '
        'LabelMultiIndivPrefWeight
        '
        Me.LabelMultiIndivPrefWeight.AutoSize = True
        Me.LabelMultiIndivPrefWeight.Location = New System.Drawing.Point(428, 61)
        Me.LabelMultiIndivPrefWeight.Name = "LabelMultiIndivPrefWeight"
        Me.LabelMultiIndivPrefWeight.Size = New System.Drawing.Size(32, 13)
        Me.LabelMultiIndivPrefWeight.TabIndex = 442
        Me.LabelMultiIndivPrefWeight.Text = "1.00"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(27, 86)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(61, 13)
        Me.Label24.TabIndex = 440
        Me.Label24.Text = "Panel Total"
        '
        'TextBoxPanelPrefWeight
        '
        Me.TextBoxPanelPrefWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxPanelPrefWeight.Location = New System.Drawing.Point(89, 83)
        Me.TextBoxPanelPrefWeight.Name = "TextBoxPanelPrefWeight"
        Me.TextBoxPanelPrefWeight.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxPanelPrefWeight.TabIndex = 439
        Me.TextBoxPanelPrefWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(357, 449)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(52, 13)
        Me.Label33.TabIndex = 438
        Me.Label33.Text = "Obligated"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(295, 449)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(50, 13)
        Me.Label30.TabIndex = 437
        Me.Label30.Text = "Available"
        '
        'LabelJudgesObliged
        '
        Me.LabelJudgesObliged.BackColor = System.Drawing.Color.LightPink
        Me.LabelJudgesObliged.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabelJudgesObliged.Location = New System.Drawing.Point(357, 471)
        Me.LabelJudgesObliged.Name = "LabelJudgesObliged"
        Me.LabelJudgesObliged.Size = New System.Drawing.Size(56, 24)
        Me.LabelJudgesObliged.TabIndex = 436
        Me.LabelJudgesObliged.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelJudgesAvailable
        '
        Me.LabelJudgesAvailable.BackColor = System.Drawing.Color.LightPink
        Me.LabelJudgesAvailable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabelJudgesAvailable.Location = New System.Drawing.Point(295, 471)
        Me.LabelJudgesAvailable.Name = "LabelJudgesAvailable"
        Me.LabelJudgesAvailable.Size = New System.Drawing.Size(56, 24)
        Me.LabelJudgesAvailable.TabIndex = 435
        Me.LabelJudgesAvailable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabLostJudgesNEW
        '
        Me.LabLostJudgesNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.LabLostJudgesNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabLostJudgesNEW.Location = New System.Drawing.Point(357, 545)
        Me.LabLostJudgesNEW.Name = "LabLostJudgesNEW"
        Me.LabLostJudgesNEW.Size = New System.Drawing.Size(56, 24)
        Me.LabLostJudgesNEW.TabIndex = 434
        Me.LabLostJudgesNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(292, 24)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(54, 13)
        Me.Label41.TabIndex = 443
        Me.Label41.Text = "Increment"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(30, 364)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(117, 13)
        Me.Label23.TabIndex = 433
        Me.Label23.Text = "Max PANEL Difference"
        '
        'TextBoxMaxPanelDiffAbove
        '
        Me.TextBoxMaxPanelDiffAbove.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxMaxPanelDiffAbove.Location = New System.Drawing.Point(171, 361)
        Me.TextBoxMaxPanelDiffAbove.Name = "TextBoxMaxPanelDiffAbove"
        Me.TextBoxMaxPanelDiffAbove.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxMaxPanelDiffAbove.TabIndex = 432
        Me.TextBoxMaxPanelDiffAbove.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxMaxPanelDiffBREAK
        '
        Me.TextBoxMaxPanelDiffBREAK.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxMaxPanelDiffBREAK.Location = New System.Drawing.Point(233, 361)
        Me.TextBoxMaxPanelDiffBREAK.Name = "TextBoxMaxPanelDiffBREAK"
        Me.TextBoxMaxPanelDiffBREAK.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxMaxPanelDiffBREAK.TabIndex = 431
        Me.TextBoxMaxPanelDiffBREAK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBoxMultiTest
        '
        Me.GroupBoxMultiTest.Controls.Add(Me.Label41)
        Me.GroupBoxMultiTest.Controls.Add(Me.Label40)
        Me.GroupBoxMultiTest.Controls.Add(Me.Label39)
        Me.GroupBoxMultiTest.Controls.Add(Me.ButtonMultiTestBegin)
        Me.GroupBoxMultiTest.Controls.Add(Me.Label38)
        Me.GroupBoxMultiTest.Controls.Add(Me.Label37)
        Me.GroupBoxMultiTest.Controls.Add(Me.Label36)
        Me.GroupBoxMultiTest.Controls.Add(Me.Label35)
        Me.GroupBoxMultiTest.Controls.Add(Me.Label34)
        Me.GroupBoxMultiTest.Controls.Add(Me.TextBoxMinIndivPrefWeight)
        Me.GroupBoxMultiTest.Controls.Add(Me.TextBoxMaxIndivPrefWeight)
        Me.GroupBoxMultiTest.Controls.Add(Me.TextBoxIncIndivPrefWeight)
        Me.GroupBoxMultiTest.Controls.Add(Me.TextBoxMinPanelPrefWeight)
        Me.GroupBoxMultiTest.Controls.Add(Me.TextBoxMaxPanelPrefWeight)
        Me.GroupBoxMultiTest.Controls.Add(Me.TextBoxIncPanelPrefWeight)
        Me.GroupBoxMultiTest.Controls.Add(Me.TextBoxIncIndivDiffWeight)
        Me.GroupBoxMultiTest.Controls.Add(Me.TextBoxIncPanelDiffWeight)
        Me.GroupBoxMultiTest.Controls.Add(Me.TextBoxMaxIndivDiffWeight)
        Me.GroupBoxMultiTest.Controls.Add(Me.TextBoxMaxPanelDiffWeight)
        Me.GroupBoxMultiTest.Controls.Add(Me.TextBoxMaxJudgePrefWeight)
        Me.GroupBoxMultiTest.Controls.Add(Me.TextBoxMinPanelDiffWeight)
        Me.GroupBoxMultiTest.Controls.Add(Me.TextBoxMinINdivDiffWeight)
        Me.GroupBoxMultiTest.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBoxMultiTest.Location = New System.Drawing.Point(21, 207)
        Me.GroupBoxMultiTest.Name = "GroupBoxMultiTest"
        Me.GroupBoxMultiTest.Size = New System.Drawing.Size(384, 208)
        Me.GroupBoxMultiTest.TabIndex = 469
        Me.GroupBoxMultiTest.TabStop = False
        Me.GroupBoxMultiTest.Text = "MultiTest Parameters"
        Me.GroupBoxMultiTest.Visible = False
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(227, 24)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(51, 13)
        Me.Label40.TabIndex = 442
        Me.Label40.Text = "Maximum"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(160, 24)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(48, 13)
        Me.Label39.TabIndex = 441
        Me.Label39.Text = "Minimum"
        '
        'ButtonMultiTestBegin
        '
        Me.ButtonMultiTestBegin.BackColor = System.Drawing.Color.Cornsilk
        Me.ButtonMultiTestBegin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonMultiTestBegin.Location = New System.Drawing.Point(225, 153)
        Me.ButtonMultiTestBegin.Name = "ButtonMultiTestBegin"
        Me.ButtonMultiTestBegin.Size = New System.Drawing.Size(121, 36)
        Me.ButtonMultiTestBegin.TabIndex = 440
        Me.ButtonMultiTestBegin.Text = "Begin Testing"
        Me.ButtonMultiTestBegin.UseVisualStyleBackColor = False
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(9, 169)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(142, 13)
        Me.Label38.TabIndex = 439
        Me.Label38.Text = "Maximum Judge Pref Weight"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(9, 45)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(120, 13)
        Me.Label37.TabIndex = 438
        Me.Label37.Text = "Individual PREF Weight"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(9, 71)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(102, 13)
        Me.Label36.TabIndex = 437
        Me.Label36.Text = "Panel PREF Weight"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(9, 128)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(119, 13)
        Me.Label35.TabIndex = 436
        Me.Label35.Text = "Panel MUTUAL Wieght"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(9, 101)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(137, 13)
        Me.Label34.TabIndex = 435
        Me.Label34.Text = "Individual MUTUAL Weight"
        '
        'TextBoxMinIndivPrefWeight
        '
        Me.TextBoxMinIndivPrefWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxMinIndivPrefWeight.Location = New System.Drawing.Point(163, 42)
        Me.TextBoxMinIndivPrefWeight.Name = "TextBoxMinIndivPrefWeight"
        Me.TextBoxMinIndivPrefWeight.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxMinIndivPrefWeight.TabIndex = 434
        Me.TextBoxMinIndivPrefWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxMaxIndivPrefWeight
        '
        Me.TextBoxMaxIndivPrefWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxMaxIndivPrefWeight.Location = New System.Drawing.Point(225, 42)
        Me.TextBoxMaxIndivPrefWeight.Name = "TextBoxMaxIndivPrefWeight"
        Me.TextBoxMaxIndivPrefWeight.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxMaxIndivPrefWeight.TabIndex = 433
        Me.TextBoxMaxIndivPrefWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxIncIndivPrefWeight
        '
        Me.TextBoxIncIndivPrefWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxIncIndivPrefWeight.Location = New System.Drawing.Point(290, 42)
        Me.TextBoxIncIndivPrefWeight.Name = "TextBoxIncIndivPrefWeight"
        Me.TextBoxIncIndivPrefWeight.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxIncIndivPrefWeight.TabIndex = 432
        Me.TextBoxIncIndivPrefWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxMinPanelPrefWeight
        '
        Me.TextBoxMinPanelPrefWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxMinPanelPrefWeight.Location = New System.Drawing.Point(163, 68)
        Me.TextBoxMinPanelPrefWeight.Name = "TextBoxMinPanelPrefWeight"
        Me.TextBoxMinPanelPrefWeight.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxMinPanelPrefWeight.TabIndex = 431
        Me.TextBoxMinPanelPrefWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxMaxPanelPrefWeight
        '
        Me.TextBoxMaxPanelPrefWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxMaxPanelPrefWeight.Location = New System.Drawing.Point(225, 68)
        Me.TextBoxMaxPanelPrefWeight.Name = "TextBoxMaxPanelPrefWeight"
        Me.TextBoxMaxPanelPrefWeight.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxMaxPanelPrefWeight.TabIndex = 430
        Me.TextBoxMaxPanelPrefWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxIncPanelPrefWeight
        '
        Me.TextBoxIncPanelPrefWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxIncPanelPrefWeight.Location = New System.Drawing.Point(290, 68)
        Me.TextBoxIncPanelPrefWeight.Name = "TextBoxIncPanelPrefWeight"
        Me.TextBoxIncPanelPrefWeight.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxIncPanelPrefWeight.TabIndex = 429
        Me.TextBoxIncPanelPrefWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxIncIndivDiffWeight
        '
        Me.TextBoxIncIndivDiffWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxIncIndivDiffWeight.Location = New System.Drawing.Point(290, 98)
        Me.TextBoxIncIndivDiffWeight.Name = "TextBoxIncIndivDiffWeight"
        Me.TextBoxIncIndivDiffWeight.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxIncIndivDiffWeight.TabIndex = 428
        Me.TextBoxIncIndivDiffWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxIncPanelDiffWeight
        '
        Me.TextBoxIncPanelDiffWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxIncPanelDiffWeight.Location = New System.Drawing.Point(290, 124)
        Me.TextBoxIncPanelDiffWeight.Name = "TextBoxIncPanelDiffWeight"
        Me.TextBoxIncPanelDiffWeight.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxIncPanelDiffWeight.TabIndex = 427
        Me.TextBoxIncPanelDiffWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxMaxIndivDiffWeight
        '
        Me.TextBoxMaxIndivDiffWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxMaxIndivDiffWeight.Location = New System.Drawing.Point(225, 98)
        Me.TextBoxMaxIndivDiffWeight.Name = "TextBoxMaxIndivDiffWeight"
        Me.TextBoxMaxIndivDiffWeight.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxMaxIndivDiffWeight.TabIndex = 426
        Me.TextBoxMaxIndivDiffWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxMaxPanelDiffWeight
        '
        Me.TextBoxMaxPanelDiffWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxMaxPanelDiffWeight.Location = New System.Drawing.Point(225, 124)
        Me.TextBoxMaxPanelDiffWeight.Name = "TextBoxMaxPanelDiffWeight"
        Me.TextBoxMaxPanelDiffWeight.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxMaxPanelDiffWeight.TabIndex = 425
        Me.TextBoxMaxPanelDiffWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxMaxJudgePrefWeight
        '
        Me.TextBoxMaxJudgePrefWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxMaxJudgePrefWeight.Location = New System.Drawing.Point(163, 162)
        Me.TextBoxMaxJudgePrefWeight.Name = "TextBoxMaxJudgePrefWeight"
        Me.TextBoxMaxJudgePrefWeight.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxMaxJudgePrefWeight.TabIndex = 424
        Me.TextBoxMaxJudgePrefWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxMinPanelDiffWeight
        '
        Me.TextBoxMinPanelDiffWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxMinPanelDiffWeight.Location = New System.Drawing.Point(163, 124)
        Me.TextBoxMinPanelDiffWeight.Name = "TextBoxMinPanelDiffWeight"
        Me.TextBoxMinPanelDiffWeight.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxMinPanelDiffWeight.TabIndex = 423
        Me.TextBoxMinPanelDiffWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxMinINdivDiffWeight
        '
        Me.TextBoxMinINdivDiffWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxMinINdivDiffWeight.Location = New System.Drawing.Point(163, 98)
        Me.TextBoxMinINdivDiffWeight.Name = "TextBoxMinINdivDiffWeight"
        Me.TextBoxMinINdivDiffWeight.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxMinINdivDiffWeight.TabIndex = 422
        Me.TextBoxMinINdivDiffWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ButtonMultiTest
        '
        Me.ButtonMultiTest.Location = New System.Drawing.Point(33, 561)
        Me.ButtonMultiTest.Name = "ButtonMultiTest"
        Me.ButtonMultiTest.Size = New System.Drawing.Size(75, 23)
        Me.ButtonMultiTest.TabIndex = 468
        Me.ButtonMultiTest.Text = "Multi-Test"
        Me.ButtonMultiTest.UseVisualStyleBackColor = True
        '
        'ButtonRemoveJudges
        '
        Me.ButtonRemoveJudges.BackColor = System.Drawing.Color.LightPink
        Me.ButtonRemoveJudges.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonRemoveJudges.Location = New System.Drawing.Point(291, 446)
        Me.ButtonRemoveJudges.Name = "ButtonRemoveJudges"
        Me.ButtonRemoveJudges.Size = New System.Drawing.Size(114, 83)
        Me.ButtonRemoveJudges.TabIndex = 465
        Me.ButtonRemoveJudges.Text = "Remove Recorded Panels"
        Me.ButtonRemoveJudges.UseVisualStyleBackColor = False
        '
        'ButtonRecordJudges
        '
        Me.ButtonRecordJudges.BackColor = System.Drawing.Color.LightGreen
        Me.ButtonRecordJudges.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonRecordJudges.Location = New System.Drawing.Point(154, 446)
        Me.ButtonRecordJudges.Name = "ButtonRecordJudges"
        Me.ButtonRecordJudges.Size = New System.Drawing.Size(117, 83)
        Me.ButtonRecordJudges.TabIndex = 464
        Me.ButtonRecordJudges.Text = "Record Created Panels"
        Me.ButtonRecordJudges.UseVisualStyleBackColor = False
        '
        'ButtonAssignJudges
        '
        Me.ButtonAssignJudges.BackColor = System.Drawing.Color.Cornsilk
        Me.ButtonAssignJudges.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonAssignJudges.Location = New System.Drawing.Point(21, 446)
        Me.ButtonAssignJudges.Name = "ButtonAssignJudges"
        Me.ButtonAssignJudges.Size = New System.Drawing.Size(114, 83)
        Me.ButtonAssignJudges.TabIndex = 463
        Me.ButtonAssignJudges.Text = "Create Judge Panels"
        Me.ButtonAssignJudges.UseVisualStyleBackColor = False
        '
        'LabelInstructions
        '
        Me.LabelInstructions.AutoSize = True
        Me.LabelInstructions.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelInstructions.ForeColor = System.Drawing.Color.Red
        Me.LabelInstructions.Location = New System.Drawing.Point(30, 207)
        Me.LabelInstructions.MaximumSize = New System.Drawing.Size(390, 0)
        Me.LabelInstructions.Name = "LabelInstructions"
        Me.LabelInstructions.Size = New System.Drawing.Size(0, 17)
        Me.LabelInstructions.TabIndex = 462
        '
        'LabBreakPoint
        '
        Me.LabBreakPoint.AutoSize = True
        Me.LabBreakPoint.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabBreakPoint.Location = New System.Drawing.Point(248, 119)
        Me.LabBreakPoint.Name = "LabBreakPoint"
        Me.LabBreakPoint.Size = New System.Drawing.Size(132, 16)
        Me.LabBreakPoint.TabIndex = 461
        Me.LabBreakPoint.Text = "Break Point (Losses)"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(82, 87)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(72, 16)
        Me.Label21.TabIndex = 460
        Me.Label21.Text = "Panel Size"
        '
        'CheckBoxJudgeAgain
        '
        Me.CheckBoxJudgeAgain.Checked = True
        Me.CheckBoxJudgeAgain.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBoxJudgeAgain.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBoxJudgeAgain.Location = New System.Drawing.Point(213, 18)
        Me.CheckBoxJudgeAgain.Name = "CheckBoxJudgeAgain"
        Me.CheckBoxJudgeAgain.Size = New System.Drawing.Size(192, 55)
        Me.CheckBoxJudgeAgain.TabIndex = 458
        Me.CheckBoxJudgeAgain.Text = "Check if Judges are NOT permitted to judge a team more than once."
        '
        'TextBoxPanelSize
        '
        Me.TextBoxPanelSize.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxPanelSize.Location = New System.Drawing.Point(33, 84)
        Me.TextBoxPanelSize.Name = "TextBoxPanelSize"
        Me.TextBoxPanelSize.Size = New System.Drawing.Size(43, 26)
        Me.TextBoxPanelSize.TabIndex = 456
        Me.TextBoxPanelSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxBreakPoint
        '
        Me.TextBoxBreakPoint.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxBreakPoint.Location = New System.Drawing.Point(197, 113)
        Me.TextBoxBreakPoint.Name = "TextBoxBreakPoint"
        Me.TextBoxBreakPoint.Size = New System.Drawing.Size(43, 26)
        Me.TextBoxBreakPoint.TabIndex = 455
        Me.TextBoxBreakPoint.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(36, 63)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(52, 13)
        Me.Label27.TabIndex = 441
        Me.Label27.Text = "Individual"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(248, 87)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(119, 16)
        Me.Label20.TabIndex = 453
        Me.Label20.Text = "Number of Cohorts"
        '
        'TextBoxNumCohorts
        '
        Me.TextBoxNumCohorts.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxNumCohorts.Location = New System.Drawing.Point(197, 81)
        Me.TextBoxNumCohorts.Name = "TextBoxNumCohorts"
        Me.TextBoxNumCohorts.Size = New System.Drawing.Size(43, 26)
        Me.TextBoxNumCohorts.TabIndex = 452
        Me.TextBoxNumCohorts.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxMaxPanelDiffBelow
        '
        Me.TextBoxMaxPanelDiffBelow.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxMaxPanelDiffBelow.Location = New System.Drawing.Point(295, 361)
        Me.TextBoxMaxPanelDiffBelow.Name = "TextBoxMaxPanelDiffBelow"
        Me.TextBoxMaxPanelDiffBelow.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxMaxPanelDiffBelow.TabIndex = 430
        Me.TextBoxMaxPanelDiffBelow.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(19, 270)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(127, 13)
        Me.Label7.TabIndex = 429
        Me.Label7.Text = "Max Individual Difference"
        '
        'TextBoxMaxIndivDiffBelow
        '
        Me.TextBoxMaxIndivDiffBelow.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxMaxIndivDiffBelow.Location = New System.Drawing.Point(295, 270)
        Me.TextBoxMaxIndivDiffBelow.Name = "TextBoxMaxIndivDiffBelow"
        Me.TextBoxMaxIndivDiffBelow.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxMaxIndivDiffBelow.TabIndex = 428
        Me.TextBoxMaxIndivDiffBelow.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxMaxIndivDiffAbove
        '
        Me.TextBoxMaxIndivDiffAbove.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxMaxIndivDiffAbove.Location = New System.Drawing.Point(171, 270)
        Me.TextBoxMaxIndivDiffAbove.Name = "TextBoxMaxIndivDiffAbove"
        Me.TextBoxMaxIndivDiffAbove.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxMaxIndivDiffAbove.TabIndex = 427
        Me.TextBoxMaxIndivDiffAbove.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxMaxIndivDiffBREAK
        '
        Me.TextBoxMaxIndivDiffBREAK.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxMaxIndivDiffBREAK.Location = New System.Drawing.Point(233, 270)
        Me.TextBoxMaxIndivDiffBREAK.Name = "TextBoxMaxIndivDiffBREAK"
        Me.TextBoxMaxIndivDiffBREAK.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxMaxIndivDiffBREAK.TabIndex = 426
        Me.TextBoxMaxIndivDiffBREAK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(172, 504)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(51, 13)
        Me.Label29.TabIndex = 403
        Me.Label29.Text = "Pref After"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(168, 449)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(60, 13)
        Me.Label32.TabIndex = 404
        Me.Label32.Text = "Pref Before"
        '
        'LabJudgePrefBefore
        '
        Me.LabJudgePrefBefore.BackColor = System.Drawing.Color.LightPink
        Me.LabJudgePrefBefore.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabJudgePrefBefore.Location = New System.Drawing.Point(171, 471)
        Me.LabJudgePrefBefore.Name = "LabJudgePrefBefore"
        Me.LabJudgePrefBefore.Size = New System.Drawing.Size(56, 24)
        Me.LabJudgePrefBefore.TabIndex = 425
        Me.LabJudgePrefBefore.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(932, 85)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(221, 23)
        Me.Button1.TabIndex = 470
        Me.Button1.Text = "Show Saved Assignment Diagnostics"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(295, 527)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(50, 13)
        Me.Label31.TabIndex = 424
        Me.Label31.Text = "Max Lost"
        '
        'TextBoxJudgePrefWeight
        '
        Me.TextBoxJudgePrefWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxJudgePrefWeight.Location = New System.Drawing.Point(90, 548)
        Me.TextBoxJudgePrefWeight.Name = "TextBoxJudgePrefWeight"
        Me.TextBoxJudgePrefWeight.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxJudgePrefWeight.TabIndex = 421
        Me.TextBoxJudgePrefWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxIndivDiffWeight
        '
        Me.TextBoxIndivDiffWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxIndivDiffWeight.Location = New System.Drawing.Point(90, 317)
        Me.TextBoxIndivDiffWeight.Name = "TextBoxIndivDiffWeight"
        Me.TextBoxIndivDiffWeight.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxIndivDiffWeight.TabIndex = 421
        Me.TextBoxIndivDiffWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxPanelDiffWeight
        '
        Me.TextBoxPanelDiffWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxPanelDiffWeight.Location = New System.Drawing.Point(90, 408)
        Me.TextBoxPanelDiffWeight.Name = "TextBoxPanelDiffWeight"
        Me.TextBoxPanelDiffWeight.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxPanelDiffWeight.TabIndex = 422
        Me.TextBoxPanelDiffWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(52, 44)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(93, 13)
        Me.Label6.TabIndex = 367
        Me.Label6.Text = "PREFS Weighting"
        '
        'TextBoxIndivPrefWeight
        '
        Me.TextBoxIndivPrefWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxIndivPrefWeight.Location = New System.Drawing.Point(89, 60)
        Me.TextBoxIndivPrefWeight.Name = "TextBoxIndivPrefWeight"
        Me.TextBoxIndivPrefWeight.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxIndivPrefWeight.TabIndex = 423
        Me.TextBoxIndivPrefWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxMaxLostRounds
        '
        Me.TextBoxMaxLostRounds.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxMaxLostRounds.Location = New System.Drawing.Point(292, 547)
        Me.TextBoxMaxLostRounds.Name = "TextBoxMaxLostRounds"
        Me.TextBoxMaxLostRounds.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxMaxLostRounds.TabIndex = 420
        Me.TextBoxMaxLostRounds.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'LabJudgePrefAfterNEW
        '
        Me.LabJudgePrefAfterNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.LabJudgePrefAfterNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabJudgePrefAfterNEW.Location = New System.Drawing.Point(171, 545)
        Me.LabJudgePrefAfterNEW.Name = "LabJudgePrefAfterNEW"
        Me.LabJudgePrefAfterNEW.Size = New System.Drawing.Size(56, 24)
        Me.LabJudgePrefAfterNEW.TabIndex = 419
        Me.LabJudgePrefAfterNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabJudgePrefAfter
        '
        Me.LabJudgePrefAfter.BackColor = System.Drawing.Color.LightGreen
        Me.LabJudgePrefAfter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabJudgePrefAfter.Location = New System.Drawing.Point(171, 521)
        Me.LabJudgePrefAfter.Name = "LabJudgePrefAfter"
        Me.LabJudgePrefAfter.Size = New System.Drawing.Size(56, 24)
        Me.LabJudgePrefAfter.TabIndex = 418
        Me.LabJudgePrefAfter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(36, 527)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(111, 13)
        Me.Label28.TabIndex = 416
        Me.Label28.Text = "Remaining Judge Pref"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(357, 504)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(60, 13)
        Me.Label26.TabIndex = 414
        Me.Label26.Text = "Actual Lost"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(71, 453)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(75, 16)
        Me.Label25.TabIndex = 413
        Me.Label25.Text = "JUDGING"
        '
        'LabLostJudges
        '
        Me.LabLostJudges.BackColor = System.Drawing.Color.LightGreen
        Me.LabLostJudges.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabLostJudges.Location = New System.Drawing.Point(357, 521)
        Me.LabLostJudges.Name = "LabLostJudges"
        Me.LabLostJudges.Size = New System.Drawing.Size(56, 24)
        Me.LabLostJudges.TabIndex = 412
        Me.LabLostJudges.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabPanelDiffAvgBreak
        '
        Me.LabPanelDiffAvgBreak.BackColor = System.Drawing.Color.LightGreen
        Me.LabPanelDiffAvgBreak.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabPanelDiffAvgBreak.Location = New System.Drawing.Point(233, 384)
        Me.LabPanelDiffAvgBreak.Name = "LabPanelDiffAvgBreak"
        Me.LabPanelDiffAvgBreak.Size = New System.Drawing.Size(56, 24)
        Me.LabPanelDiffAvgBreak.TabIndex = 409
        Me.LabPanelDiffAvgBreak.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabPanelDiffAvgBelow
        '
        Me.LabPanelDiffAvgBelow.BackColor = System.Drawing.Color.LightGreen
        Me.LabPanelDiffAvgBelow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabPanelDiffAvgBelow.Location = New System.Drawing.Point(295, 384)
        Me.LabPanelDiffAvgBelow.Name = "LabPanelDiffAvgBelow"
        Me.LabPanelDiffAvgBelow.Size = New System.Drawing.Size(56, 24)
        Me.LabPanelDiffAvgBelow.TabIndex = 408
        Me.LabPanelDiffAvgBelow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabPanelDiffAvgAll
        '
        Me.LabPanelDiffAvgAll.BackColor = System.Drawing.Color.LightGreen
        Me.LabPanelDiffAvgAll.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabPanelDiffAvgAll.Location = New System.Drawing.Point(357, 384)
        Me.LabPanelDiffAvgAll.Name = "LabPanelDiffAvgAll"
        Me.LabPanelDiffAvgAll.Size = New System.Drawing.Size(56, 24)
        Me.LabPanelDiffAvgAll.TabIndex = 407
        Me.LabPanelDiffAvgAll.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabIndivDiffAvgAbove
        '
        Me.LabIndivDiffAvgAbove.BackColor = System.Drawing.Color.LightGreen
        Me.LabIndivDiffAvgAbove.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabIndivDiffAvgAbove.Location = New System.Drawing.Point(171, 293)
        Me.LabIndivDiffAvgAbove.Name = "LabIndivDiffAvgAbove"
        Me.LabIndivDiffAvgAbove.Size = New System.Drawing.Size(56, 24)
        Me.LabIndivDiffAvgAbove.TabIndex = 406
        Me.LabIndivDiffAvgAbove.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabIndivDiffAvgBreak
        '
        Me.LabIndivDiffAvgBreak.BackColor = System.Drawing.Color.LightGreen
        Me.LabIndivDiffAvgBreak.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabIndivDiffAvgBreak.Location = New System.Drawing.Point(233, 293)
        Me.LabIndivDiffAvgBreak.Name = "LabIndivDiffAvgBreak"
        Me.LabIndivDiffAvgBreak.Size = New System.Drawing.Size(56, 24)
        Me.LabIndivDiffAvgBreak.TabIndex = 405
        Me.LabIndivDiffAvgBreak.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'labIndivAvgBelow
        '
        Me.labIndivAvgBelow.BackColor = System.Drawing.Color.LightGreen
        Me.labIndivAvgBelow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.labIndivAvgBelow.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labIndivAvgBelow.Location = New System.Drawing.Point(295, 50)
        Me.labIndivAvgBelow.Name = "labIndivAvgBelow"
        Me.labIndivAvgBelow.Size = New System.Drawing.Size(56, 24)
        Me.labIndivAvgBelow.TabIndex = 341
        Me.labIndivAvgBelow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'labIndivAvgBreak
        '
        Me.labIndivAvgBreak.BackColor = System.Drawing.Color.LightGreen
        Me.labIndivAvgBreak.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.labIndivAvgBreak.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labIndivAvgBreak.Location = New System.Drawing.Point(233, 50)
        Me.labIndivAvgBreak.Name = "labIndivAvgBreak"
        Me.labIndivAvgBreak.Size = New System.Drawing.Size(56, 24)
        Me.labIndivAvgBreak.TabIndex = 340
        Me.labIndivAvgBreak.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(7, 9)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(185, 20)
        Me.Label17.TabIndex = 449
        Me.Label17.Text = "Select Round/Division"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(602, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 443
        Me.Label1.Text = "Above"
        '
        'LabIndivDiffAvgBelow
        '
        Me.LabIndivDiffAvgBelow.BackColor = System.Drawing.Color.LightGreen
        Me.LabIndivDiffAvgBelow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabIndivDiffAvgBelow.Location = New System.Drawing.Point(295, 293)
        Me.LabIndivDiffAvgBelow.Name = "LabIndivDiffAvgBelow"
        Me.LabIndivDiffAvgBelow.Size = New System.Drawing.Size(56, 24)
        Me.LabIndivDiffAvgBelow.TabIndex = 404
        Me.LabIndivDiffAvgBelow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabIndivDiffAvgAll
        '
        Me.LabIndivDiffAvgAll.BackColor = System.Drawing.Color.LightGreen
        Me.LabIndivDiffAvgAll.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabIndivDiffAvgAll.Location = New System.Drawing.Point(357, 293)
        Me.LabIndivDiffAvgAll.Name = "LabIndivDiffAvgAll"
        Me.LabIndivDiffAvgAll.Size = New System.Drawing.Size(56, 24)
        Me.LabIndivDiffAvgAll.TabIndex = 403
        Me.LabIndivDiffAvgAll.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabPanelDiffAvgAbove
        '
        Me.LabPanelDiffAvgAbove.BackColor = System.Drawing.Color.LightGreen
        Me.LabPanelDiffAvgAbove.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabPanelDiffAvgAbove.Location = New System.Drawing.Point(171, 384)
        Me.LabPanelDiffAvgAbove.Name = "LabPanelDiffAvgAbove"
        Me.LabPanelDiffAvgAbove.Size = New System.Drawing.Size(56, 24)
        Me.LabPanelDiffAvgAbove.TabIndex = 402
        Me.LabPanelDiffAvgAbove.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabWorstPanelBelowNEW
        '
        Me.LabWorstPanelBelowNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.LabWorstPanelBelowNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabWorstPanelBelowNEW.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabWorstPanelBelowNEW.Location = New System.Drawing.Point(295, 219)
        Me.LabWorstPanelBelowNEW.Name = "LabWorstPanelBelowNEW"
        Me.LabWorstPanelBelowNEW.Size = New System.Drawing.Size(56, 24)
        Me.LabWorstPanelBelowNEW.TabIndex = 401
        Me.LabWorstPanelBelowNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'labIndivAvgAbove
        '
        Me.labIndivAvgAbove.BackColor = System.Drawing.Color.LightGreen
        Me.labIndivAvgAbove.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.labIndivAvgAbove.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labIndivAvgAbove.Location = New System.Drawing.Point(171, 50)
        Me.labIndivAvgAbove.Name = "labIndivAvgAbove"
        Me.labIndivAvgAbove.Size = New System.Drawing.Size(56, 24)
        Me.labIndivAvgAbove.TabIndex = 355
        Me.labIndivAvgAbove.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(34, 146)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(112, 13)
        Me.Label12.TabIndex = 378
        Me.Label12.Text = "Worst PREF Assigned"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(20, 299)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(126, 13)
        Me.Label9.TabIndex = 380
        Me.Label9.Text = "Avg Individual Difference"
        '
        'LabWorstPanelBelow
        '
        Me.LabWorstPanelBelow.BackColor = System.Drawing.Color.LightGreen
        Me.LabWorstPanelBelow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabWorstPanelBelow.Location = New System.Drawing.Point(295, 195)
        Me.LabWorstPanelBelow.Name = "LabWorstPanelBelow"
        Me.LabWorstPanelBelow.Size = New System.Drawing.Size(56, 24)
        Me.LabWorstPanelBelow.TabIndex = 386
        Me.LabWorstPanelBelow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(30, 120)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(116, 13)
        Me.Label3.TabIndex = 372
        Me.Label3.Text = "Target Maximum PREF"
        '
        'chkUseRatings
        '
        Me.chkUseRatings.AutoSize = True
        Me.chkUseRatings.Location = New System.Drawing.Point(942, 570)
        Me.chkUseRatings.Name = "chkUseRatings"
        Me.chkUseRatings.Size = New System.Drawing.Size(190, 17)
        Me.chkUseRatings.TabIndex = 473
        Me.chkUseRatings.Text = "Use Ratings not ordinal percentiles"
        Me.chkUseRatings.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(30, 390)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(116, 13)
        Me.Label8.TabIndex = 379
        Me.Label8.Text = "Avg PANEL Difference"
        '
        'LabWorstBelow
        '
        Me.LabWorstBelow.BackColor = System.Drawing.Color.LightGreen
        Me.LabWorstBelow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabWorstBelow.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabWorstBelow.Location = New System.Drawing.Point(295, 140)
        Me.LabWorstBelow.Name = "LabWorstBelow"
        Me.LabWorstBelow.Size = New System.Drawing.Size(56, 24)
        Me.LabWorstBelow.TabIndex = 375
        Me.LabWorstBelow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBoxTargetAbove
        '
        Me.TextBoxTargetAbove.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxTargetAbove.Location = New System.Drawing.Point(171, 117)
        Me.TextBoxTargetAbove.Name = "TextBoxTargetAbove"
        Me.TextBoxTargetAbove.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxTargetAbove.TabIndex = 368
        Me.TextBoxTargetAbove.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxTargetBREAK
        '
        Me.TextBoxTargetBREAK.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxTargetBREAK.Location = New System.Drawing.Point(233, 117)
        Me.TextBoxTargetBREAK.Name = "TextBoxTargetBREAK"
        Me.TextBoxTargetBREAK.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxTargetBREAK.TabIndex = 371
        Me.TextBoxTargetBREAK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'LabWorstAbove
        '
        Me.LabWorstAbove.BackColor = System.Drawing.Color.LightGreen
        Me.LabWorstAbove.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabWorstAbove.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabWorstAbove.Location = New System.Drawing.Point(171, 140)
        Me.LabWorstAbove.Name = "LabWorstAbove"
        Me.LabWorstAbove.Size = New System.Drawing.Size(56, 24)
        Me.LabWorstAbove.TabIndex = 377
        Me.LabWorstAbove.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBoxTargetBelow
        '
        Me.TextBoxTargetBelow.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxTargetBelow.Location = New System.Drawing.Point(295, 117)
        Me.TextBoxTargetBelow.Name = "TextBoxTargetBelow"
        Me.TextBoxTargetBelow.Size = New System.Drawing.Size(56, 20)
        Me.TextBoxTargetBelow.TabIndex = 370
        Me.TextBoxTargetBelow.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'LabWorstBREAK
        '
        Me.LabWorstBREAK.BackColor = System.Drawing.Color.LightGreen
        Me.LabWorstBREAK.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabWorstBREAK.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabWorstBREAK.Location = New System.Drawing.Point(233, 140)
        Me.LabWorstBREAK.Name = "LabWorstBREAK"
        Me.LabWorstBREAK.Size = New System.Drawing.Size(56, 24)
        Me.LabWorstBREAK.TabIndex = 376
        Me.LabWorstBREAK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(354, 251)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(66, 13)
        Me.Label14.TabIndex = 384
        Me.Label14.Text = "ALL Rounds"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(303, 251)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(36, 13)
        Me.Label13.TabIndex = 383
        Me.Label13.Text = "Below"
        '
        'labIndivDiffAvgAllNEW
        '
        Me.labIndivDiffAvgAllNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.labIndivDiffAvgAllNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.labIndivDiffAvgAllNEW.Location = New System.Drawing.Point(357, 317)
        Me.labIndivDiffAvgAllNEW.Name = "labIndivDiffAvgAllNEW"
        Me.labIndivDiffAvgAllNEW.Size = New System.Drawing.Size(56, 24)
        Me.labIndivDiffAvgAllNEW.TabIndex = 348
        Me.labIndivDiffAvgAllNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabWorstPanelBreakNEW
        '
        Me.LabWorstPanelBreakNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.LabWorstPanelBreakNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabWorstPanelBreakNEW.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabWorstPanelBreakNEW.Location = New System.Drawing.Point(233, 219)
        Me.LabWorstPanelBreakNEW.Name = "LabWorstPanelBreakNEW"
        Me.LabWorstPanelBreakNEW.Size = New System.Drawing.Size(56, 24)
        Me.LabWorstPanelBreakNEW.TabIndex = 400
        Me.LabWorstPanelBreakNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabWorstPanelAboveNEW
        '
        Me.LabWorstPanelAboveNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.LabWorstPanelAboveNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabWorstPanelAboveNEW.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabWorstPanelAboveNEW.Location = New System.Drawing.Point(171, 219)
        Me.LabWorstPanelAboveNEW.Name = "LabWorstPanelAboveNEW"
        Me.LabWorstPanelAboveNEW.Size = New System.Drawing.Size(56, 24)
        Me.LabWorstPanelAboveNEW.TabIndex = 399
        Me.LabWorstPanelAboveNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabWorstBelowNEW
        '
        Me.LabWorstBelowNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.LabWorstBelowNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabWorstBelowNEW.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabWorstBelowNEW.Location = New System.Drawing.Point(295, 164)
        Me.LabWorstBelowNEW.Name = "LabWorstBelowNEW"
        Me.LabWorstBelowNEW.Size = New System.Drawing.Size(56, 24)
        Me.LabWorstBelowNEW.TabIndex = 398
        Me.LabWorstBelowNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabWorstBreakNEW
        '
        Me.LabWorstBreakNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.LabWorstBreakNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabWorstBreakNEW.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabWorstBreakNEW.Location = New System.Drawing.Point(233, 164)
        Me.LabWorstBreakNEW.Name = "LabWorstBreakNEW"
        Me.LabWorstBreakNEW.Size = New System.Drawing.Size(56, 24)
        Me.LabWorstBreakNEW.TabIndex = 397
        Me.LabWorstBreakNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabWorstAboveNEW
        '
        Me.LabWorstAboveNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.LabWorstAboveNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabWorstAboveNEW.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabWorstAboveNEW.Location = New System.Drawing.Point(171, 164)
        Me.LabWorstAboveNEW.Name = "LabWorstAboveNEW"
        Me.LabWorstAboveNEW.Size = New System.Drawing.Size(56, 24)
        Me.LabWorstAboveNEW.TabIndex = 396
        Me.LabWorstAboveNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabIndivAvgBreakNEW
        '
        Me.LabIndivAvgBreakNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.LabIndivAvgBreakNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabIndivAvgBreakNEW.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabIndivAvgBreakNEW.Location = New System.Drawing.Point(233, 74)
        Me.LabIndivAvgBreakNEW.Name = "LabIndivAvgBreakNEW"
        Me.LabIndivAvgBreakNEW.Size = New System.Drawing.Size(56, 24)
        Me.LabIndivAvgBreakNEW.TabIndex = 392
        Me.LabIndivAvgBreakNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabIndivAvgBelowNEW
        '
        Me.LabIndivAvgBelowNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.LabIndivAvgBelowNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabIndivAvgBelowNEW.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabIndivAvgBelowNEW.Location = New System.Drawing.Point(295, 74)
        Me.LabIndivAvgBelowNEW.Name = "LabIndivAvgBelowNEW"
        Me.LabIndivAvgBelowNEW.Size = New System.Drawing.Size(56, 24)
        Me.LabIndivAvgBelowNEW.TabIndex = 391
        Me.LabIndivAvgBelowNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabIndivAvgAllNEW
        '
        Me.LabIndivAvgAllNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.LabIndivAvgAllNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabIndivAvgAllNEW.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabIndivAvgAllNEW.Location = New System.Drawing.Point(357, 74)
        Me.LabIndivAvgAllNEW.Name = "LabIndivAvgAllNEW"
        Me.LabIndivAvgAllNEW.Size = New System.Drawing.Size(56, 24)
        Me.LabIndivAvgAllNEW.TabIndex = 390
        Me.LabIndivAvgAllNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabIndivAvgAboveNEW
        '
        Me.LabIndivAvgAboveNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.LabIndivAvgAboveNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabIndivAvgAboveNEW.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabIndivAvgAboveNEW.Location = New System.Drawing.Point(171, 74)
        Me.LabIndivAvgAboveNEW.Name = "LabIndivAvgAboveNEW"
        Me.LabIndivAvgAboveNEW.Size = New System.Drawing.Size(56, 24)
        Me.LabIndivAvgAboveNEW.TabIndex = 389
        Me.LabIndivAvgAboveNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(52, 251)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(94, 16)
        Me.Label16.TabIndex = 387
        Me.Label16.Text = "MUTUALITY"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(35, 22)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(110, 17)
        Me.Label15.TabIndex = 386
        Me.Label15.Text = "PREFERENCE"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(27, 201)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(119, 13)
        Me.Label18.TabIndex = 386
        Me.Label18.Text = "Worst PANEL Assigned"
        '
        'LabWorstPanelBREAK
        '
        Me.LabWorstPanelBREAK.BackColor = System.Drawing.Color.LightGreen
        Me.LabWorstPanelBREAK.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabWorstPanelBREAK.Location = New System.Drawing.Point(233, 195)
        Me.LabWorstPanelBREAK.Name = "LabWorstPanelBREAK"
        Me.LabWorstPanelBREAK.Size = New System.Drawing.Size(56, 24)
        Me.LabWorstPanelBREAK.TabIndex = 387
        Me.LabWorstPanelBREAK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabWorstPanelAbove
        '
        Me.LabWorstPanelAbove.BackColor = System.Drawing.Color.LightGreen
        Me.LabWorstPanelAbove.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabWorstPanelAbove.Location = New System.Drawing.Point(171, 195)
        Me.LabWorstPanelAbove.Name = "LabWorstPanelAbove"
        Me.LabWorstPanelAbove.Size = New System.Drawing.Size(56, 24)
        Me.LabWorstPanelAbove.TabIndex = 388
        Me.LabWorstPanelAbove.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(665, 38)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(43, 13)
        Me.Label2.TabIndex = 444
        Me.Label2.Text = "BREAK"
        '
        'labPanelDiffAvgAllNEW
        '
        Me.labPanelDiffAvgAllNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.labPanelDiffAvgAllNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.labPanelDiffAvgAllNEW.Location = New System.Drawing.Point(357, 408)
        Me.labPanelDiffAvgAllNEW.Name = "labPanelDiffAvgAllNEW"
        Me.labPanelDiffAvgAllNEW.Size = New System.Drawing.Size(56, 24)
        Me.labPanelDiffAvgAllNEW.TabIndex = 361
        Me.labPanelDiffAvgAllNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(727, 38)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(36, 13)
        Me.Label4.TabIndex = 445
        Me.Label4.Text = "Below"
        '
        'labPanelDiffAvgBelowNEW
        '
        Me.labPanelDiffAvgBelowNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.labPanelDiffAvgBelowNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.labPanelDiffAvgBelowNEW.Location = New System.Drawing.Point(295, 408)
        Me.labPanelDiffAvgBelowNEW.Name = "labPanelDiffAvgBelowNEW"
        Me.labPanelDiffAvgBelowNEW.Size = New System.Drawing.Size(56, 24)
        Me.labPanelDiffAvgBelowNEW.TabIndex = 349
        Me.labPanelDiffAvgBelowNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabElapsedTime
        '
        Me.LabElapsedTime.BackColor = System.Drawing.Color.Cornsilk
        Me.LabElapsedTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LabElapsedTime.Location = New System.Drawing.Point(324, 560)
        Me.LabElapsedTime.Name = "LabElapsedTime"
        Me.LabElapsedTime.Size = New System.Drawing.Size(56, 24)
        Me.LabElapsedTime.TabIndex = 466
        Me.LabElapsedTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'labPanelDiffAvgBreakNEW
        '
        Me.labPanelDiffAvgBreakNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.labPanelDiffAvgBreakNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.labPanelDiffAvgBreakNEW.Location = New System.Drawing.Point(233, 408)
        Me.labPanelDiffAvgBreakNEW.Name = "labPanelDiffAvgBreakNEW"
        Me.labPanelDiffAvgBreakNEW.Size = New System.Drawing.Size(56, 24)
        Me.labPanelDiffAvgBreakNEW.TabIndex = 348
        Me.labPanelDiffAvgBreakNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'labIndivDiffAvgBreakNEW
        '
        Me.labIndivDiffAvgBreakNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.labIndivDiffAvgBreakNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.labIndivDiffAvgBreakNEW.Location = New System.Drawing.Point(233, 317)
        Me.labIndivDiffAvgBreakNEW.Name = "labIndivDiffAvgBreakNEW"
        Me.labIndivDiffAvgBreakNEW.Size = New System.Drawing.Size(56, 24)
        Me.labIndivDiffAvgBreakNEW.TabIndex = 357
        Me.labIndivDiffAvgBreakNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'labPanelDiffAvgAboveNEW
        '
        Me.labPanelDiffAvgAboveNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.labPanelDiffAvgAboveNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.labPanelDiffAvgAboveNEW.Location = New System.Drawing.Point(171, 408)
        Me.labPanelDiffAvgAboveNEW.Name = "labPanelDiffAvgAboveNEW"
        Me.labPanelDiffAvgAboveNEW.Size = New System.Drawing.Size(56, 24)
        Me.labPanelDiffAvgAboveNEW.TabIndex = 347
        Me.labPanelDiffAvgAboveNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(246, 566)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(71, 13)
        Me.Label22.TabIndex = 467
        Me.Label22.Text = "Elapsed Time"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(778, 38)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(66, 13)
        Me.Label5.TabIndex = 446
        Me.Label5.Text = "ALL Rounds"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(241, 251)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(43, 13)
        Me.Label11.TabIndex = 382
        Me.Label11.Text = "BREAK"
        '
        'labIndivAvgALL
        '
        Me.labIndivAvgALL.BackColor = System.Drawing.Color.LightGreen
        Me.labIndivAvgALL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.labIndivAvgALL.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labIndivAvgALL.Location = New System.Drawing.Point(357, 50)
        Me.labIndivAvgALL.Name = "labIndivAvgALL"
        Me.labIndivAvgALL.Size = New System.Drawing.Size(56, 24)
        Me.labIndivAvgALL.TabIndex = 342
        Me.labIndivAvgALL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(178, 251)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(38, 13)
        Me.Label10.TabIndex = 381
        Me.Label10.Text = "Above"
        '
        'labIndivDiffAvgBelowNEW
        '
        Me.labIndivDiffAvgBelowNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.labIndivDiffAvgBelowNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.labIndivDiffAvgBelowNEW.Location = New System.Drawing.Point(295, 317)
        Me.labIndivDiffAvgBelowNEW.Name = "labIndivDiffAvgBelowNEW"
        Me.labIndivDiffAvgBelowNEW.Size = New System.Drawing.Size(56, 24)
        Me.labIndivDiffAvgBelowNEW.TabIndex = 349
        Me.labIndivDiffAvgBelowNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MPJDiagnostics
        '
        Me.MPJDiagnostics.Controls.Add(Me.LabelMultiJudgePrefWeight)
        Me.MPJDiagnostics.Controls.Add(Me.LabelMultiPanelDiffWeight)
        Me.MPJDiagnostics.Controls.Add(Me.LabelMultiIndivDiffWeight)
        Me.MPJDiagnostics.Controls.Add(Me.LabelMultiPanelPrefWeight)
        Me.MPJDiagnostics.Controls.Add(Me.LabelMultiIndivPrefWeight)
        Me.MPJDiagnostics.Controls.Add(Me.Label27)
        Me.MPJDiagnostics.Controls.Add(Me.Label24)
        Me.MPJDiagnostics.Controls.Add(Me.TextBoxPanelPrefWeight)
        Me.MPJDiagnostics.Controls.Add(Me.Label33)
        Me.MPJDiagnostics.Controls.Add(Me.Label30)
        Me.MPJDiagnostics.Controls.Add(Me.LabelJudgesObliged)
        Me.MPJDiagnostics.Controls.Add(Me.LabelJudgesAvailable)
        Me.MPJDiagnostics.Controls.Add(Me.LabLostJudgesNEW)
        Me.MPJDiagnostics.Controls.Add(Me.Label23)
        Me.MPJDiagnostics.Controls.Add(Me.TextBoxMaxPanelDiffAbove)
        Me.MPJDiagnostics.Controls.Add(Me.TextBoxMaxPanelDiffBREAK)
        Me.MPJDiagnostics.Controls.Add(Me.TextBoxMaxPanelDiffBelow)
        Me.MPJDiagnostics.Controls.Add(Me.Label7)
        Me.MPJDiagnostics.Controls.Add(Me.TextBoxMaxIndivDiffBelow)
        Me.MPJDiagnostics.Controls.Add(Me.TextBoxMaxIndivDiffAbove)
        Me.MPJDiagnostics.Controls.Add(Me.TextBoxMaxIndivDiffBREAK)
        Me.MPJDiagnostics.Controls.Add(Me.Label29)
        Me.MPJDiagnostics.Controls.Add(Me.Label32)
        Me.MPJDiagnostics.Controls.Add(Me.LabJudgePrefBefore)
        Me.MPJDiagnostics.Controls.Add(Me.Label31)
        Me.MPJDiagnostics.Controls.Add(Me.TextBoxJudgePrefWeight)
        Me.MPJDiagnostics.Controls.Add(Me.TextBoxIndivDiffWeight)
        Me.MPJDiagnostics.Controls.Add(Me.TextBoxPanelDiffWeight)
        Me.MPJDiagnostics.Controls.Add(Me.Label6)
        Me.MPJDiagnostics.Controls.Add(Me.TextBoxIndivPrefWeight)
        Me.MPJDiagnostics.Controls.Add(Me.TextBoxMaxLostRounds)
        Me.MPJDiagnostics.Controls.Add(Me.LabJudgePrefAfterNEW)
        Me.MPJDiagnostics.Controls.Add(Me.LabJudgePrefAfter)
        Me.MPJDiagnostics.Controls.Add(Me.Label28)
        Me.MPJDiagnostics.Controls.Add(Me.Label26)
        Me.MPJDiagnostics.Controls.Add(Me.Label25)
        Me.MPJDiagnostics.Controls.Add(Me.LabLostJudges)
        Me.MPJDiagnostics.Controls.Add(Me.LabPanelDiffAvgBreak)
        Me.MPJDiagnostics.Controls.Add(Me.LabPanelDiffAvgBelow)
        Me.MPJDiagnostics.Controls.Add(Me.LabPanelDiffAvgAll)
        Me.MPJDiagnostics.Controls.Add(Me.LabIndivDiffAvgAbove)
        Me.MPJDiagnostics.Controls.Add(Me.LabIndivDiffAvgBreak)
        Me.MPJDiagnostics.Controls.Add(Me.labIndivAvgBelow)
        Me.MPJDiagnostics.Controls.Add(Me.labIndivAvgBreak)
        Me.MPJDiagnostics.Controls.Add(Me.LabIndivDiffAvgBelow)
        Me.MPJDiagnostics.Controls.Add(Me.LabIndivDiffAvgAll)
        Me.MPJDiagnostics.Controls.Add(Me.LabPanelDiffAvgAbove)
        Me.MPJDiagnostics.Controls.Add(Me.LabWorstPanelBelowNEW)
        Me.MPJDiagnostics.Controls.Add(Me.LabWorstPanelBreakNEW)
        Me.MPJDiagnostics.Controls.Add(Me.LabWorstPanelAboveNEW)
        Me.MPJDiagnostics.Controls.Add(Me.labIndivAvgAbove)
        Me.MPJDiagnostics.Controls.Add(Me.LabWorstBelowNEW)
        Me.MPJDiagnostics.Controls.Add(Me.LabWorstBreakNEW)
        Me.MPJDiagnostics.Controls.Add(Me.LabWorstAboveNEW)
        Me.MPJDiagnostics.Controls.Add(Me.Label12)
        Me.MPJDiagnostics.Controls.Add(Me.LabIndivAvgBreakNEW)
        Me.MPJDiagnostics.Controls.Add(Me.LabIndivAvgBelowNEW)
        Me.MPJDiagnostics.Controls.Add(Me.LabIndivAvgAllNEW)
        Me.MPJDiagnostics.Controls.Add(Me.LabIndivAvgAboveNEW)
        Me.MPJDiagnostics.Controls.Add(Me.Label16)
        Me.MPJDiagnostics.Controls.Add(Me.Label15)
        Me.MPJDiagnostics.Controls.Add(Me.Label18)
        Me.MPJDiagnostics.Controls.Add(Me.Label9)
        Me.MPJDiagnostics.Controls.Add(Me.LabWorstPanelBelow)
        Me.MPJDiagnostics.Controls.Add(Me.Label3)
        Me.MPJDiagnostics.Controls.Add(Me.Label8)
        Me.MPJDiagnostics.Controls.Add(Me.LabWorstBelow)
        Me.MPJDiagnostics.Controls.Add(Me.TextBoxTargetAbove)
        Me.MPJDiagnostics.Controls.Add(Me.TextBoxTargetBREAK)
        Me.MPJDiagnostics.Controls.Add(Me.LabWorstAbove)
        Me.MPJDiagnostics.Controls.Add(Me.TextBoxTargetBelow)
        Me.MPJDiagnostics.Controls.Add(Me.LabWorstPanelBREAK)
        Me.MPJDiagnostics.Controls.Add(Me.LabWorstBREAK)
        Me.MPJDiagnostics.Controls.Add(Me.LabWorstPanelAbove)
        Me.MPJDiagnostics.Controls.Add(Me.Label14)
        Me.MPJDiagnostics.Controls.Add(Me.labPanelDiffAvgAllNEW)
        Me.MPJDiagnostics.Controls.Add(Me.Label13)
        Me.MPJDiagnostics.Controls.Add(Me.labIndivDiffAvgAllNEW)
        Me.MPJDiagnostics.Controls.Add(Me.Label11)
        Me.MPJDiagnostics.Controls.Add(Me.labPanelDiffAvgBelowNEW)
        Me.MPJDiagnostics.Controls.Add(Me.labIndivAvgALL)
        Me.MPJDiagnostics.Controls.Add(Me.Label10)
        Me.MPJDiagnostics.Controls.Add(Me.labIndivDiffAvgBelowNEW)
        Me.MPJDiagnostics.Controls.Add(Me.labPanelDiffAvgBreakNEW)
        Me.MPJDiagnostics.Controls.Add(Me.labIndivDiffAvgBreakNEW)
        Me.MPJDiagnostics.Controls.Add(Me.labPanelDiffAvgAboveNEW)
        Me.MPJDiagnostics.Controls.Add(Me.labIndivDiffAvgAboveNEW)
        Me.MPJDiagnostics.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MPJDiagnostics.Location = New System.Drawing.Point(424, 12)
        Me.MPJDiagnostics.Name = "MPJDiagnostics"
        Me.MPJDiagnostics.Size = New System.Drawing.Size(489, 591)
        Me.MPJDiagnostics.TabIndex = 447
        Me.MPJDiagnostics.TabStop = False
        Me.MPJDiagnostics.Text = "Mutual Preference Diagnostics"
        '
        'labIndivDiffAvgAboveNEW
        '
        Me.labIndivDiffAvgAboveNEW.BackColor = System.Drawing.Color.Cornsilk
        Me.labIndivDiffAvgAboveNEW.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.labIndivDiffAvgAboveNEW.Location = New System.Drawing.Point(171, 317)
        Me.labIndivDiffAvgAboveNEW.Name = "labIndivDiffAvgAboveNEW"
        Me.labIndivDiffAvgAboveNEW.Size = New System.Drawing.Size(56, 24)
        Me.labIndivDiffAvgAboveNEW.TabIndex = 347
        Me.labIndivDiffAvgAboveNEW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cboRound
        '
        Me.cboRound.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboRound.FormattingEnabled = True
        Me.cboRound.ItemHeight = 20
        Me.cboRound.Location = New System.Drawing.Point(14, 33)
        Me.cboRound.Name = "cboRound"
        Me.cboRound.Size = New System.Drawing.Size(178, 28)
        Me.cboRound.TabIndex = 474
        '
        'dgvDTTab
        '
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvDTTab.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvDTTab.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvDTTab.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgvDTTab.Location = New System.Drawing.Point(932, 117)
        Me.dgvDTTab.Name = "dgvDTTab"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvDTTab.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgvDTTab.Size = New System.Drawing.Size(326, 215)
        Me.dgvDTTab.TabIndex = 475
        '
        'butBasicInfo
        '
        Me.butBasicInfo.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.butBasicInfo.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.butBasicInfo.Location = New System.Drawing.Point(1054, 9)
        Me.butBasicInfo.Name = "butBasicInfo"
        Me.butBasicInfo.Size = New System.Drawing.Size(198, 28)
        Me.butBasicInfo.TabIndex = 476
        Me.butBasicInfo.Text = "Ordinals - the short version"
        Me.butBasicInfo.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.Button2.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(1054, 43)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(198, 28)
        Me.Button2.TabIndex = 477
        Me.Button2.Text = "Ordinals - the full theory"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'frmSTAJudgePlacement
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1264, 782)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.butBasicInfo)
        Me.Controls.Add(Me.dgvDTTab)
        Me.Controls.Add(Me.cboRound)
        Me.Controls.Add(Me.dgFinishStats)
        Me.Controls.Add(Me.GroupBoxMultiTest)
        Me.Controls.Add(Me.ButtonMultiTest)
        Me.Controls.Add(Me.ButtonRemoveJudges)
        Me.Controls.Add(Me.ButtonRecordJudges)
        Me.Controls.Add(Me.ButtonAssignJudges)
        Me.Controls.Add(Me.LabelInstructions)
        Me.Controls.Add(Me.LabBreakPoint)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.CheckBoxJudgeAgain)
        Me.Controls.Add(Me.TextBoxPanelSize)
        Me.Controls.Add(Me.TextBoxBreakPoint)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.TextBoxNumCohorts)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.chkUseRatings)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.LabElapsedTime)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.MPJDiagnostics)
        Me.Name = "frmSTAJudgePlacement"
        Me.Text = "STA Automatic Judge Placement"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.dgFinishStats, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBoxMultiTest.ResumeLayout(False)
        Me.GroupBoxMultiTest.PerformLayout()
        Me.MPJDiagnostics.ResumeLayout(False)
        Me.MPJDiagnostics.PerformLayout()
        CType(Me.dgvDTTab, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LabelMultiJudgePrefWeight As System.Windows.Forms.Label
    Friend WithEvents LabelMultiPanelDiffWeight As System.Windows.Forms.Label
    Friend WithEvents LabelMultiIndivDiffWeight As System.Windows.Forms.Label
    Friend WithEvents dgFinishStats As System.Windows.Forms.DataGrid
    Friend WithEvents LabelMultiPanelPrefWeight As System.Windows.Forms.Label
    Friend WithEvents LabelMultiIndivPrefWeight As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents TextBoxPanelPrefWeight As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents LabelJudgesObliged As System.Windows.Forms.Label
    Friend WithEvents LabelJudgesAvailable As System.Windows.Forms.Label
    Friend WithEvents LabLostJudgesNEW As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents TextBoxMaxPanelDiffAbove As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxMaxPanelDiffBREAK As System.Windows.Forms.TextBox
    Friend WithEvents GroupBoxMultiTest As System.Windows.Forms.GroupBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents ButtonMultiTestBegin As System.Windows.Forms.Button
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents TextBoxMinIndivPrefWeight As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxMaxIndivPrefWeight As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxIncIndivPrefWeight As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxMinPanelPrefWeight As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxMaxPanelPrefWeight As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxIncPanelPrefWeight As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxIncIndivDiffWeight As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxIncPanelDiffWeight As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxMaxIndivDiffWeight As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxMaxPanelDiffWeight As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxMaxJudgePrefWeight As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxMinPanelDiffWeight As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxMinINdivDiffWeight As System.Windows.Forms.TextBox
    Friend WithEvents ButtonMultiTest As System.Windows.Forms.Button
    Friend WithEvents ButtonRemoveJudges As System.Windows.Forms.Button
    Friend WithEvents ButtonRecordJudges As System.Windows.Forms.Button
    Friend WithEvents ButtonAssignJudges As System.Windows.Forms.Button
    Friend WithEvents LabelInstructions As System.Windows.Forms.Label
    Friend WithEvents LabBreakPoint As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents CheckBoxJudgeAgain As System.Windows.Forms.CheckBox
    Friend WithEvents TextBoxPanelSize As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxBreakPoint As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents TextBoxNumCohorts As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxMaxPanelDiffBelow As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TextBoxMaxIndivDiffBelow As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxMaxIndivDiffAbove As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxMaxIndivDiffBREAK As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents LabJudgePrefBefore As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents TextBoxJudgePrefWeight As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxIndivDiffWeight As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxPanelDiffWeight As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBoxIndivPrefWeight As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxMaxLostRounds As System.Windows.Forms.TextBox
    Friend WithEvents LabJudgePrefAfterNEW As System.Windows.Forms.Label
    Friend WithEvents LabJudgePrefAfter As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents LabLostJudges As System.Windows.Forms.Label
    Friend WithEvents LabPanelDiffAvgBreak As System.Windows.Forms.Label
    Friend WithEvents LabPanelDiffAvgBelow As System.Windows.Forms.Label
    Friend WithEvents LabPanelDiffAvgAll As System.Windows.Forms.Label
    Friend WithEvents LabIndivDiffAvgAbove As System.Windows.Forms.Label
    Friend WithEvents LabIndivDiffAvgBreak As System.Windows.Forms.Label
    Friend WithEvents labIndivAvgBelow As System.Windows.Forms.Label
    Friend WithEvents labIndivAvgBreak As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LabIndivDiffAvgBelow As System.Windows.Forms.Label
    Friend WithEvents LabIndivDiffAvgAll As System.Windows.Forms.Label
    Friend WithEvents LabPanelDiffAvgAbove As System.Windows.Forms.Label
    Friend WithEvents LabWorstPanelBelowNEW As System.Windows.Forms.Label
    Friend WithEvents labIndivAvgAbove As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents LabWorstPanelBelow As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents chkUseRatings As System.Windows.Forms.CheckBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents LabWorstBelow As System.Windows.Forms.Label
    Friend WithEvents TextBoxTargetAbove As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxTargetBREAK As System.Windows.Forms.TextBox
    Friend WithEvents LabWorstAbove As System.Windows.Forms.Label
    Friend WithEvents TextBoxTargetBelow As System.Windows.Forms.TextBox
    Friend WithEvents LabWorstBREAK As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents labIndivDiffAvgAllNEW As System.Windows.Forms.Label
    Friend WithEvents LabWorstPanelBreakNEW As System.Windows.Forms.Label
    Friend WithEvents LabWorstPanelAboveNEW As System.Windows.Forms.Label
    Friend WithEvents LabWorstBelowNEW As System.Windows.Forms.Label
    Friend WithEvents LabWorstBreakNEW As System.Windows.Forms.Label
    Friend WithEvents LabWorstAboveNEW As System.Windows.Forms.Label
    Friend WithEvents LabIndivAvgBreakNEW As System.Windows.Forms.Label
    Friend WithEvents LabIndivAvgBelowNEW As System.Windows.Forms.Label
    Friend WithEvents LabIndivAvgAllNEW As System.Windows.Forms.Label
    Friend WithEvents LabIndivAvgAboveNEW As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents LabWorstPanelBREAK As System.Windows.Forms.Label
    Friend WithEvents LabWorstPanelAbove As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents labPanelDiffAvgAllNEW As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents labPanelDiffAvgBelowNEW As System.Windows.Forms.Label
    Friend WithEvents LabElapsedTime As System.Windows.Forms.Label
    Friend WithEvents labPanelDiffAvgBreakNEW As System.Windows.Forms.Label
    Friend WithEvents labIndivDiffAvgBreakNEW As System.Windows.Forms.Label
    Friend WithEvents labPanelDiffAvgAboveNEW As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents labIndivAvgALL As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents labIndivDiffAvgBelowNEW As System.Windows.Forms.Label
    Friend WithEvents MPJDiagnostics As System.Windows.Forms.GroupBox
    Friend WithEvents labIndivDiffAvgAboveNEW As System.Windows.Forms.Label
    Friend WithEvents cboRound As System.Windows.Forms.ComboBox
    Friend WithEvents dgvDTTab As System.Windows.Forms.DataGridView
    Friend WithEvents butBasicInfo As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
End Class
